/* Athlete Tycoon — draw-call batching.
   Characters and the static world are merged into a few SkinnedMeshes. Every original mesh becomes one "bone" of its
   batch, so all existing code keeps working untouched: animations move the original (now invisible) meshes and the
   batch follows them; hiding, removing or re-colouring a part is detected and handled. One shared material draws every
   batch (vertex colours + per-vertex emissive / specular / unlit flag), outlines included.
   Also: cached static shadows (static casters are rendered into the shadow map only when something static changes),
   distance LOD for characters, and a hidden debug overlay (FPS, draw calls, triangles). */
(function () {
  'use strict';
  const AT = (window.AT = window.AT || {});
  const T = THREE;
  const Bt = (AT.Batch = { on: false, staticDirty: true, n: { chars: 0, cells: 0, batches: 0 } });

  const L_MAIN = 1, L_STATIC = 2, L_DYN = 4; // layer bits: 0 = main camera, 1 = static shadow casters, 2 = moving casters
  Bt.L_DYN = L_DYN;
  Bt.isBig = (o) => isBig(o);
  Bt._test = (g) => build(collect(g, []), g, { cast: true, margin: 1.4, name: 'char' }); // debug: merge one figure now
  const CELL = 11; // world batches are split into 11-unit bands along z (one per zone) so off-screen zones are culled
  const BASE_OBR = T.Object3D.prototype.onBeforeRender;
  const _v = new T.Vector3(), _w = new T.Vector3(), _m = new T.Matrix4(), _box = new T.Box3();

  // ---------- the one shared material ----------
  let MAT = null;
  function batchMat() {
    if (MAT) return MAT;
    MAT = new T.MeshPhongMaterial({ vertexColors: true, skinning: true, shininess: 30, specular: 0x2a2a2a });
    MAT.onBeforeCompile = (sh) => {
      const dec = 'varying vec3 vEmis; varying vec4 vSpec; varying float vUnlit;';
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', `#include <common>\nattribute vec3 aEmis; attribute vec4 aSpec; attribute float aUnlit;\n${dec}`)
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvEmis = aEmis; vSpec = aSpec; vUnlit = aUnlit;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', `#include <common>\n${dec}`)
        .replace('vec3 totalEmissiveRadiance = emissive;', 'vec3 totalEmissiveRadiance = vEmis;')
        .replace('#include <lights_phong_fragment>', 'BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = vSpec.rgb;\nmaterial.specularShininess = vSpec.a;\nmaterial.specularStrength = specularStrength;')
        .replace('#include <envmap_fragment>', '#include <envmap_fragment>\noutgoingLight = mix(outgoingLight, diffuseColor.rgb, vUnlit);');
    };
    MAT.customProgramCacheKey = () => 'at-batch-1';
    return MAT;
  }

  // ---------- which meshes can join a batch ----------
  function matInfo(m) {
    if (!m || Array.isArray(m) || m.map || m.alphaMap || m.transparent || m.opacity < 1 || m.wireframe || m.flatShading
      || m.vertexColors || m.envMap || m.blending !== T.NormalBlending || !m.depthWrite || !m.depthTest || m.colorWrite === false
      || m.polygonOffset || m.isShaderMaterial || m.onBeforeCompile !== T.Material.prototype.onBeforeCompile) return null;
    if (m.isMeshBasicMaterial) return { unlit: 1, e: [0, 0, 0], s: [0, 0, 0, 1] };
    const ei = m.emissiveIntensity == null ? 1 : m.emissiveIntensity, em = m.emissive;
    const e = em ? [em.r * ei, em.g * ei, em.b * ei] : [0, 0, 0];
    if (m.isMeshPhongMaterial) return { unlit: 0, e, s: [m.specular.r, m.specular.g, m.specular.b, m.shininess] };
    if (m.isMeshLambertMaterial) return { unlit: 0, e, s: [0, 0, 0, 1] };
    return null;
  }
  function eligible(o) {
    if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh || o.userData.__batch || o.userData.noBatch || o.renderOrder !== 0) return false;
    if (o.onBeforeRender !== BASE_OBR || o.layers.mask === 0) return false;
    const g = o.geometry;
    if (!g || !g.isBufferGeometry || !g.attributes.position || (g.morphAttributes && g.morphAttributes.position) || g.drawRange.start) return false;
    return !!matInfo(o.material);
  }
  // walk a subtree, not entering other characters, batches or opted-out branches
  function collect(root, out, isRootChar) {
    const walk = (o) => {
      if (o !== root && (o.userData.__batch || o.userData.noBatch || (o.userData.fx && o.userData.root))) return; // nested figure = its own batch
      if (eligible(o)) out.push(o);
      for (let i = 0; i < o.children.length; i++) walk(o.children[i]);
    };
    walk(root);
    return out;
  }
  // big enough to cast a shadow: not flat, not tiny
  function isBig(o) {
    const g = o.geometry; if (!g.boundingBox) g.computeBoundingBox();
    o.updateWorldMatrix(true, false);
    _box.copy(g.boundingBox).applyMatrix4(o.matrixWorld);
    const sx = _box.max.x - _box.min.x, sy = _box.max.y - _box.min.y, sz = _box.max.z - _box.min.z;
    return Math.max(sx, sy, sz) >= 0.55 && sy >= 0.12 && _box.max.y >= 0.35;
  }

  // ---------- building one batch ----------
  const batches = new Set();
  function build(meshes, space, opt) {
    if (!meshes.length) return null;
    space.updateWorldMatrix(true, false);
    const spaceInv = new T.Matrix4().copy(space.matrixWorld).invert();
    let nv = 0, ni = 0;
    for (const o of meshes) {
      const g = o.geometry, pc = g.attributes.position.count, k = o.material.side === T.DoubleSide ? 2 : 1;
      const ic = g.index ? Math.min(g.index.count, g.drawRange.count) : Math.min(pc, g.drawRange.count);
      nv += pc * k; ni += ic * k;
    }
    const pos = new Float32Array(nv * 3), nor = new Float32Array(nv * 3), col = new Float32Array(nv * 3), emi = new Float32Array(nv * 3);
    const spe = new Float32Array(nv * 4), unl = new Float32Array(nv), si = new Uint16Array(nv * 4), sw = new Float32Array(nv * 4);
    const idx = nv > 65535 ? new Uint32Array(ni) : new Uint16Array(ni);
    const recs = [], bones = [], inv = [];
    let vb = 0, ib = 0;
    const M = new T.Matrix4(), N = new T.Matrix3();
    meshes.forEach((o, bi) => {
      const g = o.geometry, mat = o.material, info = matInfo(mat), P = g.attributes.position, NA = g.attributes.normal, pc = P.count;
      o.updateWorldMatrix(true, false);
      M.multiplyMatrices(spaceInv, o.matrixWorld); N.getNormalMatrix(M);
      const flip0 = (M.determinant() < 0) !== (mat.side === T.BackSide);
      const c = mat.color || { r: 1, g: 1, b: 1 };
      const copies = mat.side === T.DoubleSide ? 2 : 1;
      for (let cp = 0; cp < copies; cp++) {
        const flip = cp ? !flip0 : flip0, ns = cp ? -1 : 1;
        for (let i = 0; i < pc; i++) {
          const v = vb + i;
          _v.fromBufferAttribute(P, i).applyMatrix4(M); pos[v * 3] = _v.x; pos[v * 3 + 1] = _v.y; pos[v * 3 + 2] = _v.z;
          if (NA) _w.fromBufferAttribute(NA, i).applyMatrix3(N).normalize().multiplyScalar(ns); else _w.set(0, 1, 0);
          nor[v * 3] = _w.x; nor[v * 3 + 1] = _w.y; nor[v * 3 + 2] = _w.z;
          col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b;
          emi[v * 3] = info.e[0]; emi[v * 3 + 1] = info.e[1]; emi[v * 3 + 2] = info.e[2];
          spe[v * 4] = info.s[0]; spe[v * 4 + 1] = info.s[1]; spe[v * 4 + 2] = info.s[2]; spe[v * 4 + 3] = info.s[3];
          unl[v] = info.unlit; si[v * 4] = bi; sw[v * 4] = 1;
        }
        const n = g.index ? Math.min(g.index.count, g.drawRange.count) : Math.min(pc, g.drawRange.count), I = g.index && g.index.array;
        for (let t = 0; t + 2 < n; t += 3) {
          const a = I ? I[t] : t, b = I ? I[t + 1] : t + 1, d = I ? I[t + 2] : t + 2;
          idx[ib++] = vb + a; idx[ib++] = vb + (flip ? d : b); idx[ib++] = vb + (flip ? b : d);
        }
        vb += pc;
      }
      bones.push(o); inv.push(new T.Matrix4().copy(o.matrixWorld).invert());
      recs.push({ o, mat, geo: g, cr: c.r, cg: c.g, cb: c.b, last: Float64Array.from(o.matrixWorld.elements), shown: null, layers: o.layers.mask,
        outline: mat.side === T.BackSide && mat.isMeshBasicMaterial, gone: false });
    });
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    geo.setAttribute('normal', new T.BufferAttribute(nor, 3));
    geo.setAttribute('color', new T.BufferAttribute(col, 3));
    geo.setAttribute('aEmis', new T.BufferAttribute(emi, 3));
    geo.setAttribute('aSpec', new T.BufferAttribute(spe, 4));
    geo.setAttribute('aUnlit', new T.BufferAttribute(unl, 1));
    geo.setAttribute('skinIndex', new T.Uint16BufferAttribute(si, 4));
    geo.setAttribute('skinWeight', new T.BufferAttribute(sw, 4));
    geo.setIndex(new T.BufferAttribute(ib === idx.length ? idx : idx.slice(0, ib), 1));
    geo.computeBoundingSphere();
    geo.boundingSphere.radius += opt.margin || 0.3;
    const sk = new T.SkinnedMesh(geo, batchMat());
    sk.userData.__batch = true; sk.userData.shd = 1; sk.name = opt.name || 'batch';
    space.add(sk);
    sk.updateMatrixWorld(true);
    const skel = new T.Skeleton(bones, inv);
    sk.bind(skel, sk.matrixWorld.clone());
    sk.castShadow = !!opt.cast; sk.receiveShadow = true;
    sk.layers.mask = L_MAIN | (opt.cast ? (opt.isStatic ? L_STATIC : L_DYN) : 0);
    const b = { sk, skel, recs, space, owner: opt.owner, isStatic: !!opt.isStatic, cast: !!opt.cast, far: false, farWas: false };
    skel.update = skinUpdate(b);
    for (const r of recs) { r.o.userData.__b = b; r.o.layers.mask = 0; } // originals stay in the scene graph (animation, visibility) but are not drawn
    batches.add(b);
    if (b.isStatic && b.cast) Bt.staticDirty = true;
    return b;
  }
  function unbuild(b) {
    for (const r of b.recs) if (!r.gone && r.o.userData.__b === b) { r.o.layers.mask = r.layers | (r.o.castShadow ? L_DYN : 0); delete r.o.userData.__b; }
    if (b.sk.parent) b.sk.parent.remove(b.sk);
    b.sk.geometry.dispose(); b.skel.dispose();
    batches.delete(b);
    if (b.isStatic && b.cast) Bt.staticDirty = true;
  }
  // a part that changed material / geometry / colour leaves the batch and draws on its own until the next rebake
  function release(b, r) {
    r.gone = true;
    if (r.o.userData.__b === b) { r.o.layers.mask = r.layers | (r.o.castShadow ? L_DYN : 0); delete r.o.userData.__b; }
    if (b.owner) b.owner.rebakeAt = Math.min(b.owner.rebakeAt || Infinity, now + 0.4);
    if (b.isStatic && b.cast) Bt.staticDirty = true;
  }

  // bone matrices: the original mesh's world matrix (zero = hidden). Only re-uploaded when something changed.
  const ZERO = new Float32Array(16);
  function skinUpdate(b) {
    return function () {
      const recs = b.recs, inv = this.boneInverses, arr = this.boneMatrices, root = b.space;
      let changed = false;
      const farFlip = b.far !== b.farWas; b.farWas = b.far;
      if (b.sk.material !== MAT) { b.sk.material = MAT; if (b.owner) b.owner.rebakeAt = now; } // someone re-skinned the whole group
      for (let i = 0; i < recs.length; i++) {
        const r = recs[i], o = r.o;
        let show = !r.gone;
        if (show) {
          const m = o.material;
          if (m !== r.mat || o.geometry !== r.geo || (m.color && (m.color.r !== r.cr || m.color.g !== r.cg || m.color.b !== r.cb)) || m.transparent || o.layers.mask !== 0) {
            if (o.layers.mask !== 0) r.layers = o.layers.mask; // game code changed its layers: hand it back
            release(b, r); show = false;
          } else {
            for (let p = o; p !== root; p = p.parent) if (!p || !p.visible) { show = false; break; }
            if (show && b.far && r.outline) show = false; // far LOD: no outlines
          }
        }
        const e = o.matrixWorld.elements, l = r.last;
        let moved = false;
        for (let k = 0; k < 16; k++) if (e[k] !== l[k]) { moved = true; break; }
        if (!moved && show === r.shown && !farFlip) continue;
        if (moved) {
          l.set(e);
          o.userData.__mvT = now;
          if (b.isStatic && show) { // something in a static batch moves: it joins the moving batch at the next rebake
            o.userData.__mv = true;
            if (b.owner) b.owner.rebakeAt = Math.min(b.owner.rebakeAt || Infinity, now + 0.5);
          }
        }
        if (b.isStatic && b.cast && (moved || show !== r.shown)) Bt.staticDirty = true;
        r.shown = show; changed = true;
        if (show) { _m.multiplyMatrices(o.matrixWorld, inv[i]); _m.toArray(arr, i * 16); } else arr.set(ZERO, i * 16);
      }
      if (changed && this.boneTexture) this.boneTexture.needsUpdate = true;
    };
  }

  // ---------- registry: characters and world cells ----------
  let renderer = null, scene = null, world = null, sun = null, now = 0;
  const chars = new Map(); // figure group -> entry
  const cells = new Map(); // cell index -> entry
  Bt.init = function (r, sc, w, light) {
    renderer = r; scene = sc; world = w; sun = light; Bt.info = r.info;
    let off = false; try { off = /[?&#]nobatch/.test(location.href); } catch (e) { /* ignore */ }
    Bt.on = !off && !!(r.capabilities.floatVertexTextures && r.capabilities.isWebGL2);
    if (Bt.on) { sc.autoUpdate = false; r.info.autoReset = false; }
    return Bt.on;
  };
  const connected = (o) => { while (o.parent) o = o.parent; return o === scene; };

  function bakeChar(e) {
    if (e.b) unbuild(e.b);
    e.b = null; e.rebakeAt = 0;
    const g = e.g, u = g.userData;
    const list = collect(g, []);
    e.b = build(list, g, { owner: e, cast: true, margin: 1.4, name: 'char' });
    // detail parts that are not merged (numbers, names, bibs, logos): hidden when the character is far away
    e.detail = [];
    g.traverse((o) => { if (o.isMesh && !o.userData.__b && !o.userData.__batch && o !== u.face && o.material && o.material.map) e.detail.push(o); });
    e.pending = 0;
  }
  function dropChar(e) {
    if (e.b) unbuild(e.b);
    for (const o of e.detail || []) if (o.userData.__farMask != null) { o.layers.mask = o.userData.__farMask; delete o.userData.__farMask; }
    chars.delete(e.g);
  }

  const cellOf = (o) => { o.getWorldPosition(_v); return Math.floor((_v.z + CELL / 2) / CELL); };
  function bakeCell(key) {
    let e = cells.get(key);
    if (!e) cells.set(key, (e = { key, bs: [], rebakeAt: 0 }));
    for (const b of e.bs) unbuild(b);
    e.bs = []; e.rebakeAt = 0; e.pendingSince = 0;
    const parts = { sc: [], sn: [], mc: [], mn: [] };
    for (const ch of world.children) {
      if (!staticChild(ch) || cellOf(ch) !== key) continue;
      for (const o of collect(ch, [])) {
        if (o.userData.__mv && now - (o.userData.__mvT || 0) > 20) o.userData.__mv = false; // settled down again
        const mv = !!o.userData.__mv, big = isBig(o);
        parts[(mv ? 'm' : 's') + (big ? 'c' : 'n')].push(o);
      }
    }
    const add = (list, isStatic, cast, name) => { const b = build(list, world, { owner: e, isStatic, cast, margin: isStatic ? 0.3 : 1.2, name }); if (b) e.bs.push(b); };
    add(parts.sc, true, true, 'cell-static-cast'); add(parts.sn, true, false, 'cell-static');
    add(parts.mc, false, true, 'cell-moving-cast'); add(parts.mn, false, false, 'cell-moving');
  }
  // world children that never move and hold no characters' bodies can be merged
  function staticChild(ch) {
    const d = ch.userData;
    if (d.__batch || d.ent || d.__ent || d.noBatch || ch.isSprite || ch.isLight) return false;
    if (d.fx && d.root) return false; // a bare figure is a character batch
    return (d.__quiet || 0) >= 3;
  }

  // every 0.5 s: find new characters, notice moving world children, queue cell rebakes for new / removed parts
  let scanT = 0;
  function scan() {
    // characters anywhere in the scene
    const seen = new Set();
    scene.traverse((o) => {
      if (o.userData.fx && o.userData.root && o.userData.body) {
        seen.add(o);
        if (!chars.has(o)) chars.set(o, { g: o, b: null, pending: 2, rebakeAt: 0, away: 0 });
      }
    });
    for (const e of chars.values()) {
      if (seen.has(e.g)) e.away = 0;
      else if ((e.away += 0.5) > 10) dropChar(e); // gone for a while: free the GPU copy
    }
    // world children
    for (const ch of world.children) {
      const d = ch.userData;
      if (d.__batch || ch.isSprite) continue;
      const el = ch.matrixWorld.elements;
      // whatever exists at load time is merged right away; later additions must stay still for 1.5 s first
      if (!d.__last) { d.__last = Float64Array.from(el); d.__quiet = now < 1 && !d.ent ? 3 : 0; if (!d.__quiet) continue; }
      let moved = false;
      for (let k = 0; k < 16; k++) if (el[k] !== d.__last[k]) { moved = true; break; }
      // moving in 4 scans in a row (2 s) = a moving entity for good; a one-off pop-in or tween does not count
      if (moved) { d.__last.set(el); d.__streak = now - (d.__lastMove || -99) < 1.6 ? (d.__streak || 0) + 1 : 1; d.__lastMove = now; if (d.__streak >= 4) d.__ent = true; d.__quiet = 0; } else d.__quiet = Math.min(99, (d.__quiet || 0) + 1);
      if (!staticChild(ch)) continue;
      const key = cellOf(ch);
      let fresh = 0;
      collect(ch, []).forEach((o) => { if (!o.userData.__b) fresh++; });
      if (fresh) {
        let e = cells.get(key);
        if (!e) cells.set(key, (e = { key, bs: [], rebakeAt: 0 }));
        if (!e.pendingSince) e.pendingSince = now;
      }
    }
    for (const e of cells.values()) {
      if (e.pendingSince && (now < 1 || now - e.pendingSince > 0.6)) e.rebakeAt = Math.min(e.rebakeAt || Infinity, now);
      let gone = 0, n = 0;
      for (const b of e.bs) for (const r of b.recs) { n++; if (r.gone || !connected(r.o)) gone++; }
      if (n && gone / n > 0.25) e.rebakeAt = Math.min(e.rebakeAt || Infinity, now);
      // moving parts that have been still for 20 s go back to the static batch (cached shadows)
      if (!e.rebakeAt) for (const b of e.bs) if (!b.isStatic && b.recs.every((r) => r.gone || now - (r.o.userData.__mvT || 0) > 20)) { e.rebakeAt = now; break; }
      // a world child that turned out to move: take it out of the batches
      for (const b of e.bs) if (b.recs.some((r) => !r.gone && entOf(r.o))) { e.rebakeAt = Math.min(e.rebakeAt || Infinity, now); break; }
    }
    // characters: new parts added later (carried items, props) get merged after a short while
    for (const e of chars.values()) {
      if (!e.b || e.rebakeAt) continue;
      let fresh = 0;
      collect(e.g, []).forEach((o) => { if (!o.userData.__b) fresh++; });
      if (fresh) { e.fresh = (e.fresh || 0) + 1; if (e.fresh >= 2) e.rebakeAt = now; } else e.fresh = 0;
    }
  }
  function entOf(o) { let c = o; while (c.parent && c.parent !== world) c = c.parent; return !!(c.userData.__ent || c.userData.ent); }

  // ---------- per frame: bake queue, LOD, skeletons, shadows ----------
  Bt.farDist = 30;
  let budget = 0;
  Bt.frame = function (dt, camera) {
    if (!Bt.on) return;
    now += dt;
    scene.updateMatrixWorld();
    if ((scanT -= dt) <= 0) { scanT = 0.5; scan(); }
    // a few bakes per frame at most, so a big rebake never stalls a single frame for long
    budget = now < 1 ? 99 : 3; // during loading: everything at once
    for (const e of chars.values()) {
      if (budget <= 0) break;
      if (!e.b && (e.pending-- <= 0 || now < 1) && connected(e.g)) { bakeChar(e); budget--; }
      else if (e.b && e.rebakeAt && now >= e.rebakeAt) { bakeChar(e); budget--; }
    }
    for (const e of cells.values()) {
      if (budget <= 0) break;
      if (e.rebakeAt && now >= e.rebakeAt) { bakeCell(e.key); budget -= 2; }
    }
    if (budget < 3) scene.updateMatrixWorld();
    // characters far from the camera: no shadow, no outlines, no number / name decals
    const cp = camera.position;
    let nc = 0;
    for (const e of chars.values()) {
      if (!e.b) continue;
      nc++;
      e.g.getWorldPosition(_v);
      const far = _v.distanceTo(cp) > Bt.farDist;
      e.b.far = far; e.b.sk.castShadow = !far;
      if (far !== e.farNow) {
        e.farNow = far;
        for (const o of e.detail) {
          if (far) { if (o.userData.__farMask == null) { o.userData.__farMask = o.layers.mask; o.layers.mask = 0; } }
          else if (o.userData.__farMask != null) { o.layers.mask = o.userData.__farMask; delete o.userData.__farMask; }
        }
      }
    }
    // skeletons now (the shadow passes below need them this frame; the main render then skips them)
    const fr = renderer.info.render.frame;
    for (const b of batches) { if (connected(b.sk)) { b.skel.update(); b.skel.frame = fr; } }
    Bt.n.chars = nc; Bt.n.cells = cells.size; Bt.n.batches = batches.size;
    shadows();
  };

  // ---------- cached static shadows ----------
  // Three draws the shadow map every frame, but its shadow camera only sees the moving casters (characters, moving
  // parts). The static casters (merged zone batches) are drawn into a cached depth map only when something static
  // changed or the shadow box moved, and a hook that runs first in the main pass merges that cache into the shadow map
  // with a depth-tested copy, before anything samples it.
  let cacheRT = null, quadScene = null, quadCam = null, mergeMat = null, quad = null, depthMat = null, hook = null;
  function quadSetup() {
    if (quadScene) return;
    quadScene = new T.Scene(); quadCam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    mergeMat = new T.ShaderMaterial({ uniforms: { t: { value: null } },
      vertexShader: 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }',
      fragmentShader: '#include <packing>\nuniform sampler2D t; varying vec2 vUv; void main() { vec4 c = texture2D(t, vUv); gl_FragDepthEXT = min(unpackRGBAToDepth(c), 1.0); gl_FragColor = c; }',
      depthTest: true, depthWrite: true, extensions: { fragDepth: true } });
    quad = new T.Mesh(new T.PlaneGeometry(2, 2), mergeMat); quad.frustumCulled = false; quadScene.add(quad);
    // same depth encoding and face culling as three's own shadow pass (back faces for front-sided materials)
    depthMat = new T.MeshDepthMaterial({ depthPacking: T.RGBADepthPacking, skinning: true, side: T.BackSide });
    hook = new T.Mesh(new T.BufferGeometry().setAttribute('position', new T.Float32BufferAttribute([0, 0, 0, 0, 0, 0, 0, 0, 0], 3)),
      new T.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false }));
    hook.frustumCulled = false; hook.renderOrder = -1e9; hook.userData.__batch = true; hook.name = 'shadow-merge-hook';
    hook.onBeforeRender = (r) => {
      const sh = sun.shadow;
      if (!cacheReady || !sh.map || !r.shadowMap.enabled || cacheRT.width !== sh.map.width) return;
      mergeMat.uniforms.t.value = cacheRT.texture;
      const rt = r.getRenderTarget(), ac = r.autoClear;
      r.autoClear = false; r.setRenderTarget(sh.map);
      r.render(quadScene, quadCam);
      r.setRenderTarget(rt); r.autoClear = ac;
    };
    scene.add(hook);
  }
  let cacheReady = false;
  const _bg = { c: new T.Color(), a: 1 };
  function shadows() {
    const sm = renderer.shadowMap;
    sm.autoUpdate = true;
    if (!sm.enabled || !sun.castShadow) { cacheReady = false; return; }
    quadSetup();
    const sh = sun.shadow, w = sh.mapSize.x, h = sh.mapSize.y;
    sh.camera.layers.mask = L_DYN; // three's own per-frame pass: moving casters only
    if (!cacheRT || cacheRT.width !== w || cacheRT.height !== h) {
      if (cacheRT) cacheRT.dispose();
      cacheRT = new T.WebGLRenderTarget(w, h, { minFilter: T.NearestFilter, magFilter: T.NearestFilter, format: T.RGBAFormat });
      Bt.staticDirty = true;
    }
    if (!Bt.staticDirty && cacheReady) return;
    // static pass: depth of the static casters from the light, into the cache
    sh.updateMatrices(sun);
    const cam = sh.camera, bg = scene.background, ov = scene.overrideMaterial, rt = renderer.getRenderTarget();
    renderer.getClearColor(_bg.c); _bg.a = renderer.getClearAlpha();
    cam.layers.mask = L_STATIC; scene.background = null; scene.overrideMaterial = depthMat;
    renderer.setClearColor(0xffffff, 1); sm.autoUpdate = false; hook.visible = false;
    renderer.setRenderTarget(cacheRT); renderer.clear(); renderer.render(scene, cam);
    renderer.setRenderTarget(rt); renderer.setClearColor(_bg.c, _bg.a);
    scene.background = bg; scene.overrideMaterial = ov; cam.layers.mask = L_DYN; sm.autoUpdate = true; hook.visible = true;
    Bt.staticDirty = false; cacheReady = true;
    Bt.n.staticRenders = (Bt.n.staticRenders || 0) + 1;
  }

  // ---------- debug overlay (?debug in the URL, or press ` ) ----------
  let ov = null, ovFps = 60, ovT = 0;
  Bt.overlay = function (on) {
    if (on == null) on = !ov;
    if (on && !ov) { ov = document.createElement('div'); ov.id = 'perfov'; ov.style.cssText = 'position:fixed;left:6px;top:6px;z-index:100000;font:600 11px/1.35 ui-monospace,Menlo,monospace;color:#fff;background:rgba(20,24,40,.78);padding:6px 8px;border-radius:8px;pointer-events:none;white-space:pre'; document.body.appendChild(ov); }
    else if (!on && ov) { ov.remove(); ov = null; }
  };
  Bt.stat = function (dt) {
    if (!ov) return;
    if (dt > 0) ovFps += (1 / dt - ovFps) * 0.05;
    if ((ovT -= dt) > 0) return;
    ovT = 0.25;
    const i = renderer.info;
    ov.textContent = `FPS   ${ovFps.toFixed(0)}\ncalls ${i.render.calls}\ntris  ${(i.render.triangles / 1000).toFixed(1)}k\nchars ${Bt.n.chars}  batches ${Bt.n.batches}\ngeo ${i.memory.geometries}  tex ${i.memory.textures}\npx ${renderer.getPixelRatio()}`;
  };
  try { if (/[?&#]debug/.test(location.href)) Bt.overlay(true); } catch (e) { /* ignore */ }
  window.addEventListener('keydown', (e) => { if (e.key === '`') Bt.overlay(); });
})();
