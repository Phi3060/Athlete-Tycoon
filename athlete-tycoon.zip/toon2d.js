/* Athlete Tycoon — cartoon toolkit shared by the 3D characters and the 2D minigames:
   expressive faces, a chibi 2D character rig with one shared pose library, crowds, particles,
   national-style football kits and the per-person look (hair, face, build) derived from a name. */
'use strict';
(function () {
  const AT = (window.AT = window.AT || {});
  const TAU = Math.PI * 2;
  const INK = '#1f2433';

  // ---------- colours ----------
  const css = (c) => (typeof c === 'number' ? '#' + c.toString(16).padStart(6, '0') : c);
  const _sh = {};
  function shade(c, k) { // darker (k < 1) or lighter (k > 1) version of a colour
    const key = c + '|' + k;
    if (_sh[key]) return _sh[key];
    const h = css(c).slice(1), n = parseInt(h.length === 3 ? h.replace(/./g, '$&$&') : h, 16);
    let r = (n >> 16) & 255, gg = (n >> 8) & 255, b = n & 255;
    if (k <= 1) { r *= k; gg *= k; b *= k; } else { const t = k - 1; r += (255 - r) * t; gg += (255 - gg) * t; b += (255 - b) * t; }
    return (_sh[key] = `rgb(${r | 0},${gg | 0},${b | 0})`);
  }
  const hash = (s) => { let h = 2166136261; s = String(s); for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

  // ---------- who looks how ----------
  const FEM = new Set(['Mia', 'Zoe', 'Ava', 'Ivy', 'Nia', 'Ruby', 'Luna', 'Aria', 'Noa', 'Lia', 'Tia', 'Mae', 'Cleo', 'Suki', 'Pia', 'Tara', 'Gabi', 'Cora', 'Rita', 'Marina']);
  const STYLES_M = ['short', 'spiky', 'buzz', 'afro', 'quiff', 'mohawk', 'short', 'spiky', 'braids'];
  const STYLES_F = ['ponytail', 'buns', 'long', 'afro', 'braids', 'ponytail', 'bob', 'buns'];
  const STYLES_BALL = { m: ['spiky', 'mohawk', 'quiff', 'braids', 'buzz', 'afro'], f: ['ponytail', 'braids', 'buns', 'ponytail', 'afro'] };
  const SKINS = ['#ffd6b0', '#f1c27d', '#e0ac69', '#c68642', '#8d5524'];
  const HAIRS = ['#3b2a1a', '#111111', '#e0b04a', '#8b4513', '#d9480f', '#f783ac'];
  // look: sex, hairstyle, face shape and body build, always the same for the same person
  function look(name, id, sport) {
    const first = String(name || '').split(' ')[0];
    const h = hash(first + ':' + (id == null ? '' : id));
    const sex = FEM.has(first) ? 'f' : 'm';
    const pool = sport === 'football' ? STYLES_BALL[sex] : sex === 'f' ? STYLES_F : STYLES_M;
    return {
      sex, style: pool[h % pool.length],
      face: { eye: (h >> 4) % 3, brow: (h >> 6) & 1, lash: sex === 'f', freck: ((h >> 7) % 5) === 0 },
      build: [0.93, 1, 1, 1.08][(h >> 9) & 3], h,
    };
  }

  // ---------- NATIONAL-STYLE FOOTBALL KITS: colours only (no crests, no brands, no real names) ----------
  const KITS = {
    ger: { name: 'Germany style', region: 'eu', shirt: 0xf8f9fa, shorts: 0x212529, socks: 0xf8f9fa, trim: [0x111111, 0xdd0000, 0xffce00], num: 0x212529 },
    fra: { name: 'France style', region: 'eu', shirt: 0x1d2b5a, shorts: 0xf8f9fa, socks: 0xe03131, trim: [0xf8f9fa, 0xe03131], num: 0xf8f9fa },
    ita: { name: 'Italy style', region: 'eu', shirt: 0x4d9de0, shorts: 0xf8f9fa, socks: 0x4d9de0, trim: [0xf8f9fa], num: 0xf8f9fa },
    esp: { name: 'Spain style', region: 'eu', shirt: 0xc60b1e, shorts: 0x1d2b5a, socks: 0x1d2b5a, trim: [0xffc400], num: 0xffc400 },
    bra: { name: 'Brazil style', region: 'world', shirt: 0xffdf00, shorts: 0x1c4fb8, socks: 0xf8f9fa, trim: [0x009c3b], num: 0x009c3b },
    arg: { name: 'Argentina style', region: 'world', shirt: 0x75aadb, stripes: 0xf8f9fa, shorts: 0x111111, socks: 0xf8f9fa, trim: [0x111111], num: 0x111111 },
  };

  // ======================================================================
  // FACES — drawn on a canvas; the 3D heads use the same drawing as a texture.
  // (cx, cy) = head centre, R = head radius. v = { eye: 0 round / 1 almond / 2 big, brow, lash, freck }
  // expr: smile, happy, focused, shocked, sad, proud, strain, blink, ko
  // ======================================================================
  function face(g, cx, cy, R, v, expr, tex) {
    v = v || {};
    const k = R / 100;
    g.save(); g.translate(cx, cy); g.scale(k, k);
    g.lineCap = 'round'; g.lineJoin = 'round';
    const EX = 35, EY = 6;
    const rx = [13, 15, 15][v.eye || 0], ry = [16, 12, 19][v.eye || 0];
    const ink = INK, small = R < 9 && !tex;
    // cheeks
    if (expr !== 'ko') { g.fillStyle = expr === 'strain' ? 'rgba(255,80,80,.45)' : 'rgba(255,120,150,.38)'; for (const s of [-1, 1]) { g.beginPath(); g.ellipse(s * 57, 34, 15, 9, 0, 0, TAU); g.fill(); } }
    if (v.freck) { g.fillStyle = 'rgba(150,80,40,.55)'; for (const s of [-1, 1]) for (const [fx, fy] of [[50, 26], [60, 32], [46, 36]]) { g.beginPath(); g.arc(s * fx, fy, 2.6, 0, TAU); g.fill(); } }
    const lw = small ? 9 : 6.5;
    g.strokeStyle = ink; g.fillStyle = ink; g.lineWidth = lw;
    const closedArc = (s, up) => { g.beginPath(); if (up) g.arc(s * EX, EY + 8, rx, Math.PI * 1.15, Math.PI * 1.85); else g.arc(s * EX, EY - 6, rx, Math.PI * 0.15, Math.PI * 0.85); g.stroke(); };
    const openEye = (s, sy, pr, lid, look) => {
      // sclera, iris, pupil, two highlights
      g.fillStyle = '#fff'; g.beginPath(); g.ellipse(s * EX, EY, rx, ry * sy, 0, 0, TAU); g.fill();
      g.lineWidth = lw * 0.7; g.strokeStyle = ink; g.stroke();
      g.save(); g.beginPath(); g.ellipse(s * EX, EY, rx, ry * sy, 0, 0, TAU); g.clip();
      const ix = s * EX + (look || 0) * 3, iy = EY + 2;
      g.fillStyle = v.iris || '#3d2b1f'; g.beginPath(); g.ellipse(ix, iy, rx * 0.78 * pr, ry * sy * 0.82 * pr, 0, 0, TAU); g.fill();
      g.fillStyle = ink; g.beginPath(); g.ellipse(ix, iy + 1, rx * 0.42 * pr, ry * sy * 0.45 * pr, 0, 0, TAU); g.fill();
      if (!small) { g.fillStyle = '#fff'; g.beginPath(); g.arc(ix - rx * 0.32, iy - ry * sy * 0.34, rx * 0.3, 0, TAU); g.fill(); g.beginPath(); g.arc(ix + rx * 0.3, iy + ry * sy * 0.3, rx * 0.14, 0, TAU); g.fill(); }
      if (lid) { g.fillStyle = v.skinLid || 'rgba(0,0,0,0)'; } // (lids are drawn as lines below)
      g.restore();
      if (v.lash && !small) { g.lineWidth = lw * 0.55; for (const a of [-0.35, 0, 0.35]) { const ax = s * EX + s * Math.sin(a + 0.9) * rx, ay = EY - Math.cos(a + 0.9) * ry * sy; g.beginPath(); g.moveTo(ax, ay); g.lineTo(ax + s * 5, ay - 4); g.stroke(); } }
    };
    const lidLine = (s, ang) => { g.lineWidth = lw; g.beginPath(); g.moveTo(s * (EX - rx - 3), EY - ry * 0.35 - s * ang * 0); g.lineTo(s * (EX + rx + 3), EY - ry * 0.35 + ang); g.stroke(); };
    // eyes
    for (const s of [-1, 1]) {
      switch (expr) {
        case 'blink': g.lineWidth = lw; g.beginPath(); g.moveTo(s * EX - rx, EY + 2); g.quadraticCurveTo(s * EX, EY + 8, s * EX + rx, EY + 2); g.stroke(); break;
        case 'proud': case 'happy2': closedArc(s, true); break;
        case 'strain': g.lineWidth = lw; g.beginPath(); g.moveTo(s * (EX + rx), EY - 9); g.lineTo(s * (EX - rx * 0.6), EY); g.lineTo(s * (EX + rx), EY + 9); g.stroke(); break;
        case 'ko': g.lineWidth = lw; g.beginPath(); g.moveTo(s * EX - 10, EY - 10); g.lineTo(s * EX + 10, EY + 10); g.moveTo(s * EX + 10, EY - 10); g.lineTo(s * EX - 10, EY + 10); g.stroke(); break;
        case 'shocked': openEye(s, 1.18, 0.55); break;
        case 'focused': {
          openEye(s, 0.82, 0.95, true, 0);
          // half-closed top lid
          g.save(); g.fillStyle = v.lidCol || 'rgba(0,0,0,0)'; g.restore();
          g.lineWidth = lw; g.beginPath(); g.moveTo(s * (EX + rx + 2), EY - ry * 0.45); g.lineTo(s * (EX - rx - 2), EY - ry * 0.05); g.stroke();
          break;
        }
        case 'sad': openEye(s, 0.92, 0.9, false, 0); g.lineWidth = lw; g.beginPath(); g.moveTo(s * (EX - rx), EY - ry * 0.5); g.lineTo(s * (EX + rx + 2), EY - ry * 0.1); g.stroke(); break;
        default: openEye(s, 1, 1, false, 0);
      }
    }
    // brows
    const bw = v.brow ? 8 : 5.5, by = EY - ry - 9;
    g.lineWidth = bw; g.strokeStyle = v.browCol || ink;
    for (const s of [-1, 1]) {
      g.beginPath();
      if (expr === 'focused' || expr === 'strain') { g.moveTo(s * (EX + 14), by - 3); g.lineTo(s * (EX - 12), by + 6); }
      else if (expr === 'sad') { g.moveTo(s * (EX + 14), by + 5); g.lineTo(s * (EX - 12), by - 5); }
      else if (expr === 'shocked') { g.moveTo(s * (EX + 14), by - 2); g.quadraticCurveTo(s * EX, by - 14, s * (EX - 12), by - 3); }
      else if (expr === 'ko') { g.moveTo(s * (EX + 12), by); g.lineTo(s * (EX - 12), by); }
      else { g.moveTo(s * (EX + 14), by + 2); g.quadraticCurveTo(s * EX, by - 7, s * (EX - 12), by + 1); }
      g.stroke();
    }
    // mouth
    const my = 44;
    g.lineWidth = lw; g.strokeStyle = ink;
    const openMouth = (w, h, tongue) => {
      g.fillStyle = '#7a1f2b'; g.beginPath(); g.moveTo(-w, my - 4); g.quadraticCurveTo(0, my - 2, w, my - 4); g.quadraticCurveTo(w * 0.8, my + h, 0, my + h); g.quadraticCurveTo(-w * 0.8, my + h, -w, my - 4); g.fill(); g.stroke();
      if (tongue) { g.save(); g.clip(); g.fillStyle = '#ff6b81'; g.beginPath(); g.ellipse(0, my + h, w * 0.6, h * 0.45, 0, 0, TAU); g.fill(); g.restore(); }
      if (!small) { g.fillStyle = '#fff'; g.fillRect(-w * 0.55, my - 3.5, w * 1.1, 4); }
    };
    switch (expr) {
      case 'happy': case 'happy2': openMouth(17, 20, true); break;
      case 'proud': openMouth(22, 16, true); break;
      case 'shocked': g.fillStyle = '#7a1f2b'; g.beginPath(); g.ellipse(0, my + 4, 9, 12, 0, 0, TAU); g.fill(); g.stroke(); break;
      case 'sad': g.beginPath(); g.moveTo(-14, my + 8); g.quadraticCurveTo(0, my - 6, 14, my + 8); g.stroke(); if (!small) { g.fillStyle = '#74c0fc'; g.beginPath(); g.moveTo(-EX - 6, EY + ry); g.quadraticCurveTo(-EX - 13, EY + ry + 16, -EX - 6, EY + ry + 19); g.quadraticCurveTo(-EX + 1, EY + ry + 16, -EX - 6, EY + ry); g.fill(); } break;
      case 'focused': g.beginPath(); g.moveTo(-10, my + 2); g.lineTo(10, my); g.stroke(); break;
      case 'strain': g.fillStyle = '#fff'; g.beginPath(); g.rect(-16, my - 6, 32, 13); g.fill(); g.stroke(); g.beginPath(); g.moveTo(-16, my); g.lineTo(16, my); g.stroke(); break;
      case 'ko': g.beginPath(); for (let i = 0; i <= 6; i++) g.lineTo(-15 + i * 5, my + (i % 2 ? 5 : -1)); g.stroke(); break;
      default: g.beginPath(); g.moveTo(-14, my - 2); g.quadraticCurveTo(0, my + 12, 14, my - 2); g.stroke();
    }
    g.restore();
  }

  // ======================================================================
  // 2D CHIBI CHARACTER — big head, compact rounded body, short limbs (about 3 heads tall),
  // thin dark outline and a soft gloss. One rig, one pose library for everyone.
  // L (look): { skin, hair, style, face, sex, build, kit: { shirt, shorts, socks, boots, trim[], stripes, num, numCol, name },
  //            sleeves ('short'|'none'|'long'), gloves, cap, band, swim, gold, crown }
  // P (pose): { view front|back|side, dir, bx, by, rot, lean, sq, head, aL/aR/lL/lR: [angle, bend, toward-camera],
  //            expr, blur, gs (glove scale) }
  // ======================================================================
  const HR = 12.5, BH = 16, BW = 19, HIP = 14;
  const SH_Y = -HIP - BH + 4; // shoulder height
  function rrect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function limb(g, px, py, A, l1, l2, w, sx, c1, c2, split, c3) {
    A = A || [0, 0, 0];
    const a = A[0] || 0, b = A[1] || 0, f = 1 - (A[2] || 0) * 0.55;
    const x1 = px + Math.sin(a) * l1 * f * sx, y1 = py + Math.cos(a) * l1 * f;
    const x2 = x1 + Math.sin(a + b) * l2 * f * sx, y2 = y1 + Math.cos(a + b) * l2 * f;
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = INK; g.lineWidth = w + 2.6; g.beginPath(); g.moveTo(px, py); g.lineTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    g.lineWidth = w;
    g.strokeStyle = c2; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    if (c3) { g.strokeStyle = c3; g.beginPath(); g.moveTo(x1 + (x2 - x1) * 0.3, y1 + (y2 - y1) * 0.3); g.lineTo(x2, y2); g.stroke(); }
    g.strokeStyle = c1; g.beginPath(); g.moveTo(px, py); g.lineTo(x1, y1); g.stroke();
    if (split != null) { g.strokeStyle = split; g.beginPath(); g.moveTo(px, py); g.lineTo(px + (x1 - px) * 0.5, py + (y1 - py) * 0.5); g.stroke(); }
    return [x2, y2, a + b, x1, y1];
  }
  function ball(g, x, y, r, col, lw) { g.beginPath(); g.arc(x, y, r, 0, TAU); g.fillStyle = col; g.fill(); g.lineWidth = lw || 1.6; g.strokeStyle = INK; g.stroke(); }

  function hairBack(g, L, hy, view) {
    const c = L.hair, st = L.style;
    g.fillStyle = c; g.strokeStyle = INK; g.lineWidth = 1.6;
    if (st === 'afro') { g.beginPath(); g.arc(0, hy - 3, HR * 1.32, 0, TAU); g.fill(); g.stroke(); }
    else if (st === 'long' || st === 'bob') { rrect(g, -HR * 1.08, hy - HR * 0.6, HR * 2.16, HR * (st === 'bob' ? 1.45 : 2.0), HR * 0.7); g.fill(); g.stroke(); }
    else if (st === 'ponytail') { const sx = view === 'back' ? 0 : HR * 0.9; g.beginPath(); g.ellipse(sx, hy + HR * 0.55, HR * 0.38, HR * 0.85, view === 'back' ? 0 : 0.35, 0, TAU); g.fill(); g.stroke(); }
    else if (st === 'braids') { for (const s of [-1, 1]) for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(s * HR * 0.86, hy + HR * 0.35 + i * 4.2, 2.6, 0, TAU); g.fill(); g.stroke(); } }
  }
  function hairFront(g, L, hy, view, d) {
    const c = L.hair, st = L.style;
    if (st === 'bald' || L.swim || L.capOn) return;
    g.fillStyle = c; g.strokeStyle = INK; g.lineWidth = 1.6;
    const top = (lo) => { g.beginPath(); g.arc(0, hy, HR * 1.04, Math.PI + lo, -lo); g.quadraticCurveTo(HR * 0.4, hy - HR * 0.35, 0, hy - HR * 0.48); g.quadraticCurveTo(-HR * 0.5, hy - HR * 0.3, -HR * 1.0, hy - HR * 0.05 - lo * 3); g.closePath(); g.fill(); g.stroke(); };
    if (view === 'back') { // from behind the hair covers most of the head
      if (st === 'buzz') { g.fillStyle = shade(c, 1.15); g.globalAlpha = 0.85; }
      g.beginPath(); g.arc(0, hy, HR * 1.04, Math.PI * 0.92, Math.PI * 2.08); g.closePath(); g.fill(); g.globalAlpha = 1; g.stroke();
      if (st === 'buns') for (const s of [-1, 1]) ball(g, s * HR * 0.62, hy - HR * 0.92, HR * 0.38, c);
      if (st === 'mohawk' || st === 'spiky') { g.beginPath(); for (let i = -2; i <= 2; i++) { g.moveTo(i * 4 - 3, hy - HR * 0.85); g.lineTo(i * 4, hy - HR * 1.35); g.lineTo(i * 4 + 3, hy - HR * 0.85); } g.fill(); }
      return;
    }
    switch (st) {
      case 'buzz': g.globalAlpha = 0.75; g.beginPath(); g.arc(0, hy, HR * 1.0, Math.PI + 0.35, -0.35); g.quadraticCurveTo(0, hy - HR * 0.55, -HR * 0.94, hy - HR * 0.34); g.fill(); g.globalAlpha = 1; break;
      case 'spiky': top(0.3); g.beginPath(); for (let i = -2; i <= 2; i++) { const x = i * 4.6; g.moveTo(x - 3.4, hy - HR * 0.8); g.lineTo(x + i * 0.8, hy - HR * 1.45 + Math.abs(i) * 1.6); g.lineTo(x + 3.4, hy - HR * 0.8); } g.fill(); g.stroke(); break;
      case 'mohawk': g.globalAlpha = 0.7; top(0.6); g.globalAlpha = 1; rrect(g, -3.2, hy - HR * 1.5, 6.4, HR * 0.9, 3); g.fill(); g.stroke(); break;
      case 'quiff': top(0.3); g.beginPath(); g.ellipse(-HR * 0.15 + d * 2, hy - HR * 0.92, HR * 0.72, HR * 0.38, -0.25, 0, TAU); g.fill(); g.stroke(); break;
      case 'afro': g.beginPath(); g.arc(0, hy - 2, HR * 1.12, Math.PI + 0.2, -0.2); g.quadraticCurveTo(0, hy - HR * 0.4, -HR * 1.08, hy - HR * 0.25); g.fill(); break;
      case 'buns': top(0.3); for (const s of [-1, 1]) ball(g, s * HR * 0.66, hy - HR * 0.95, HR * 0.38, c); break;
      case 'long': case 'bob': top(0.15); break;
      default: top(0.3); // short, ponytail, braids
    }
    if (L.sex === 'f' && (st === 'ponytail' || st === 'buns')) { g.fillStyle = '#ff6b9a'; g.beginPath(); g.arc(st === 'buns' ? HR * 0.4 : HR * 0.82, hy - HR * (st === 'buns' ? 0.7 : 0.35), 2, 0, TAU); g.fill(); }
  }

  function char(g, x, y, s, L, P) {
    P = P || {};
    const view = P.view || 'front', d = P.dir || 1, kit = L.kit || {};
    const skin = L.skin || SKINS[1];
    const shirt = L.gold ? '#fcc419' : css(kit.shirt || '#ffa94d'), shorts = L.gold ? '#f59f00' : css(kit.shorts || '#343a40');
    const sleeve = L.sleeves === 'none' || L.swim ? skin : shirt;
    const sockC = kit.socks != null ? css(kit.socks) : null, boots = L.gold ? '#fcc419' : css(kit.boots || '#2b2d42');
    const bw = BW * (L.build || 1);
    g.save(); g.translate(x, y); g.scale(s, s);
    if (!P.noShadow) { g.fillStyle = 'rgba(0,0,0,.2)'; g.beginPath(); g.ellipse(P.bx || 0, 0, 14 * (1 + Math.min(0, P.by || 0) / -80), 4.2, 0, 0, TAU); g.fill(); }
    if (L.aura) { const gl = g.createRadialGradient(0, -24, 4, 0, -24, 38); gl.addColorStop(0, L.aura); gl.addColorStop(1, 'rgba(255,236,153,0)'); g.fillStyle = gl; g.beginPath(); g.arc(0, -24, 38, 0, TAU); g.fill(); }
    g.translate(P.bx || 0, P.by || 0);
    const mid = -HIP - BH / 2;
    if (P.rot) { g.translate(0, mid); g.rotate(P.rot); g.translate(0, -mid); }
    if (P.sq) g.scale(1 - P.sq * 0.6, 1 + P.sq);
    if (P.flip) g.scale(-1, 1);
    const lean = (P.lean || 0) * (view === 'side' ? d : 1);
    const upper = (fn) => { g.save(); g.translate(0, -HIP); g.rotate(lean); g.translate(0, HIP); fn(); g.restore(); };
    // limbs
    const legC = (side) => limb(g, side * 4.6 * (L.build || 1), -HIP + 2, side < 0 ? P.lL : P.lR, 7.5, 7, 6.6, view === 'side' ? d : side, skin, skin, shorts, sockC);
    const foot = (e, side) => { // shoe pointing forward (side view) or slightly out
      const fx = view === 'side' ? d * 2.6 : side * 1.4;
      g.fillStyle = boots; g.strokeStyle = INK; g.lineWidth = 1.5; g.beginPath(); g.ellipse(e[0] + fx, e[1] + 0.6, view === 'side' ? 5 : 4.3, 3, 0, 0, TAU); g.fill(); g.stroke();
      if (kit.studs && view === 'side') { g.fillStyle = '#dee2e6'; g.fillRect(e[0] + fx - 3, e[1] + 3, 6, 1.2); }
    };
    const armC = (side) => {
      const sh = [side * (bw / 2 - 1.5), SH_Y];
      const e = limb(g, sh[0], sh[1], side < 0 ? P.aL : P.aR, 6.6, 6.4, 5.6, view === 'side' ? d : side, skin, skin, sleeve);
      if (L.sleeves !== 'none' && !L.swim && kit.trim && kit.trim.length) { // sleeve trim stripes
        const tx = sh[0] + (e[3] - sh[0]) * 0.52, ty = sh[1] + (e[4] - sh[1]) * 0.52;
        kit.trim.slice(0, 3).forEach((c, i) => { g.fillStyle = css(c); g.beginPath(); g.arc(tx, ty + (i - 1) * 1.1, 2.9, 0, TAU); g.fill(); });
      }
      if (L.gloves) { const gs = 6.4 * ((side < 0 ? P.gsL : P.gsR) || 1); ball(g, e[0], e[1], gs, css(L.gloves), 1.8); g.fillStyle = 'rgba(255,255,255,.45)'; g.beginPath(); g.arc(e[0] - gs * 0.35, e[1] - gs * 0.35, gs * 0.3, 0, TAU); g.fill(); }
      else ball(g, e[0], e[1], L.hands ? 4 : 3.1, L.hands ? css(L.hands) : L.chalk ? '#f8f9fa' : skin, 1.4);
      if (P.thumb && side > 0) { g.fillStyle = skin; g.strokeStyle = INK; g.lineWidth = 1.2; rrect(g, e[0] - 1, e[1] - 6, 2.4, 5, 1.2); g.fill(); g.stroke(); }
      return e;
    };
    const blurLeg = P.blur && P.blur.leg;
    if (blurLeg) { g.save(); for (let i = 1; i <= 3; i++) { g.globalAlpha = 0.16 / i; const A = P.lR.slice(); A[0] -= P.blur.dA * i * 0.4; limb(g, 4.6, -HIP + 2, A, 7.5, 7, 6.6, view === 'side' ? d : 1, skin, skin); } g.restore(); }
    const body = () => {
      // shorts
      rrect(g, -bw / 2 + 0.5, -HIP - 4.5, bw - 1, 9.5, 4); g.fillStyle = shorts; g.fill(); g.lineWidth = 1.7; g.strokeStyle = INK; g.stroke();
      // torso (shirt or bare for swimmers)
      const tc = L.swim ? skin : shirt;
      rrect(g, -bw / 2, -HIP - BH, bw, BH + 1, 8); g.fillStyle = tc; g.fill();
      if (kit.stripes != null && !L.gold) { g.save(); rrect(g, -bw / 2, -HIP - BH, bw, BH + 1, 8); g.clip(); g.fillStyle = css(kit.stripes); for (let sx = -bw / 2 + 2.5; sx < bw / 2; sx += 6.4) g.fillRect(sx, -HIP - BH, 3.2, BH + 1); g.restore(); }
      if (L.tank && !L.swim) { g.fillStyle = skin; for (const sd of [-1, 1]) { g.beginPath(); g.ellipse(sd * bw / 2, -HIP - BH + 3, 3.4, 5.5, 0, 0, TAU); g.fill(); } }
      g.lineWidth = 1.7; g.strokeStyle = INK; rrect(g, -bw / 2, -HIP - BH, bw, BH + 1, 8); g.stroke();
      // gloss
      g.fillStyle = 'rgba(255,255,255,.28)'; g.beginPath(); g.ellipse(-bw * 0.22, -HIP - BH + 4.5, bw * 0.18, 2.6, -0.3, 0, TAU); g.fill();
      // kit details: number (back), small number (front), name
      if (kit.num && !L.swim) {
        const nc = L.gold ? '#7a4b00' : css(kit.numCol || '#fff');
        g.fillStyle = nc; g.textAlign = 'center'; g.textBaseline = 'middle';
        if (view === 'back') {
          if (kit.name) { g.font = '900 3.6px system-ui,sans-serif'; g.fillText(String(kit.name).toUpperCase().slice(0, 8), 0, -HIP - BH + 3.6); }
          g.font = '900 9.5px system-ui,sans-serif'; g.fillText(String(kit.num), 0, -HIP - BH / 2 + 2.2);
        } else if (view === 'front') { g.font = '900 5px system-ui,sans-serif'; g.fillText(String(kit.num), bw * 0.18, -HIP - BH + 6.5); }
      }
      if (L.logo && view === 'front') { ball(g, -bw * 0.22, -HIP - BH + 6.5, 2.6, L.logo, 1); }
      if (L.belt) { g.fillStyle = css(L.belt); g.fillRect(-bw / 2, -HIP - 3.5, bw, 3.4); g.fillStyle = '#ffd43b'; g.fillRect(-2.2, -HIP - 3.5, 4.4, 3.4); }
      if (L.whistle && view !== 'back') { g.strokeStyle = '#495057'; g.lineWidth = 0.9; g.beginPath(); g.moveTo(-4, -HIP - BH + 1); g.lineTo(0, -HIP - BH + 8); g.lineTo(4, -HIP - BH + 1); g.stroke(); ball(g, 0, -HIP - BH + 8.5, 1.6, L.whistle === 'gold' ? '#fcc419' : '#ced4da', 0.8); }
    };
    const head = () => {
      const hy = -HIP - BH - HR * 0.72 + (P.head ? 0 : 0);
      g.save();
      if (P.head) { g.translate(0, hy + HR); g.rotate(P.head); g.translate(0, -hy - HR); }
      hairBack(g, L, hy, view);
      g.beginPath(); g.arc(0, hy, HR, 0, TAU); g.fillStyle = skin; g.fill(); g.lineWidth = 1.8; g.strokeStyle = INK; g.stroke();
      if (L.swim) { g.fillStyle = css(L.swim); g.beginPath(); g.arc(0, hy, HR * 1.03, Math.PI * 0.95, Math.PI * 2.05); g.closePath(); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.3)'; g.beginPath(); g.ellipse(-HR * 0.35, hy - HR * 0.7, HR * 0.3, HR * 0.14, -0.4, 0, TAU); g.fill(); }
      if (view !== 'back') {
        g.save();
        if (view === 'side') { g.translate(d * HR * 0.3, 0); g.scale(0.72, 1); }
        face(g, 0, hy, HR, L.face, P.expr || 'smile');
        g.restore();
      }
      // gloss on the head
      g.fillStyle = 'rgba(255,255,255,.25)'; g.beginPath(); g.ellipse(-HR * 0.42, hy - HR * 0.5, HR * 0.28, HR * 0.16, -0.5, 0, TAU); g.fill();
      hairFront(g, L, hy, view, d);
      if (L.swim && L.goggles && view !== 'back') { g.strokeStyle = INK; g.lineWidth = 1.2; g.beginPath(); g.moveTo(-HR, hy - 1); g.lineTo(HR, hy - 1); g.stroke(); for (const sd of [-1, 1]) { g.beginPath(); g.ellipse(sd * HR * 0.38, hy - HR * 0.42, HR * 0.24, HR * 0.17, 0, 0, TAU); g.fillStyle = css(L.goggles); g.fill(); g.stroke(); } }
      if (L.band) { g.fillStyle = css(L.band); g.strokeStyle = INK; g.lineWidth = 1.2; g.beginPath(); g.rect(-HR * 1.02, hy - HR * 0.62, HR * 2.04, HR * 0.3); g.fill(); g.stroke(); }
      if (L.cap) {
        g.fillStyle = css(L.cap); g.strokeStyle = INK; g.lineWidth = 1.6;
        g.beginPath(); g.arc(0, hy - 1, HR * 1.05, Math.PI * 1.02, Math.PI * 1.98); g.closePath(); g.fill(); g.stroke();
        if (view !== 'back') { g.beginPath(); g.ellipse(view === 'side' ? d * HR * 0.85 : 0, hy - HR * 0.42, HR * (view === 'side' ? 0.7 : 0.95), HR * 0.2, 0, 0, TAU); g.fillStyle = css(L.capBrim || L.cap); g.fill(); g.stroke(); }
      }
      if (L.headgear) { g.strokeStyle = css(L.headgear); g.lineWidth = 4; g.beginPath(); g.arc(0, hy, HR * 1.0, Math.PI * 0.85, Math.PI * 2.15); g.stroke(); }
      if (L.crown) { g.fillStyle = '#fcc419'; g.strokeStyle = INK; g.lineWidth = 1.2; g.beginPath(); g.moveTo(-7, hy - HR - 1); g.lineTo(-8, hy - HR - 9); g.lineTo(-3.5, hy - HR - 5); g.lineTo(0, hy - HR - 11); g.lineTo(3.5, hy - HR - 5); g.lineTo(8, hy - HR - 9); g.lineTo(7, hy - HR - 1); g.closePath(); g.fill(); g.stroke(); }
      if (P.sweat) { g.fillStyle = '#74c0fc'; for (const sd of [-1, 1]) { const ty = hy - HR * 0.4 + ((P.sweat * 30 + sd * 7) % 10); g.beginPath(); g.arc(sd * (HR + 2), ty, 1.7, 0, TAU); g.fill(); } }
      g.restore();
    };
    if (view === 'side') { // far limbs first, darker
      g.save(); g.filter = 'none'; g.globalAlpha = 1;
      const near = d > 0 ? 1 : -1, far = -near;
      const farLeg = limb(g, 0, -HIP + 2, far < 0 ? P.lL : P.lR, 7.5, 7, 6.6, d, shade(skin, 0.82), shade(skin, 0.82), shade(shorts, 0.82), sockC ? shade(sockC, 0.82) : null); foot(farLeg, far);
      upper(() => { const sh = [0, SH_Y]; const e = limb(g, sh[0], sh[1], far < 0 ? P.aL : P.aR, 6.6, 6.4, 5.6, d, shade(skin, 0.82), shade(skin, 0.82), shade(sleeve, 0.82)); if (L.gloves) ball(g, e[0], e[1], 6.2, shade(css(L.gloves), 0.8), 1.8); else ball(g, e[0], e[1], 3, shade(skin, 0.82), 1.3); });
      const nearLeg = limb(g, 0, -HIP + 2, near < 0 ? P.lL : P.lR, 7.5, 7, 6.6, d, skin, skin, shorts, sockC); foot(nearLeg, near);
      upper(() => { body(); head(); const sh = [0, SH_Y]; const e = limb(g, sh[0], sh[1], near < 0 ? P.aL : P.aR, 6.6, 6.4, 5.6, d, skin, skin, sleeve); if (L.gloves) ball(g, e[0], e[1], 6.4, css(L.gloves), 1.8); else ball(g, e[0], e[1], 3.1, skin, 1.4); });
      g.restore();
    } else {
      foot(legC(-1), -1); foot(legC(1), 1);
      upper(() => { body(); if (view === 'back') { armC(-1); armC(1); head(); } else { head(); armC(-1); armC(1); } });
    }
    if (P.stars) { // knocked out: stars circle the head
      const hy = -HIP - BH - HR * 1.6;
      for (let i = 0; i < 4; i++) { const a = P.stars + (i * TAU) / 4; star(g, Math.cos(a) * 14, hy + Math.sin(a) * 4, 3.4, '#ffd43b'); }
    }
    g.restore();
  }
  function star(g, x, y, r, col) {
    g.beginPath();
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5, rr2 = i % 2 ? r * 0.45 : r; g.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
    g.closePath(); g.fillStyle = col; g.fill(); g.lineWidth = 0.8; g.strokeStyle = INK; g.stroke();
  }

  // ======================================================================
  // POSE LIBRARY — every character uses these. t = time, k = 0..1 progress.
  // ======================================================================
  const sin = Math.sin, abs = Math.abs;
  const P = {
    stand: (t = 0) => ({ by: sin(t * 2.2) * 0.4, aL: [0.14, -0.15], aR: [0.14, -0.15], lL: [0.05, 0], lR: [0.05, 0] }),
    wave: (t) => ({ by: sin(t * 2) * 0.4, aL: [0.14, -0.15], aR: [2.55 + sin(t * 11) * 0.3, 0.35], lL: [0.05, 0], lR: [0.05, 0], expr: 'happy' }),
    cheer: (t) => { const j = abs(sin(t * 6.5)); return { by: -j * 9, sq: j > 0.85 ? 0.08 : j < 0.15 ? -0.1 : 0.02, aL: [2.75 + sin(t * 13) * 0.15, 0.2], aR: [2.75 - sin(t * 13) * 0.15, 0.2], lL: [0.12, 0, j * 0.4], lR: [0.12, 0, j * 0.4], expr: 'happy' }; },
    clap: (t) => { const c = abs(sin(t * 9)); return { by: sin(t * 2) * 0.4, aL: [0.75, -1.65 + c * 0.45], aR: [0.75, -1.65 + c * 0.45], lL: [0.05, 0], lR: [0.05, 0], expr: 'smile' }; },
    sad: (t) => ({ by: 1.5, head: 0.28, aL: [0.04, 0], aR: [0.04, 0], lL: [0.04, 0], lR: [0.04, 0], expr: 'sad', lean: sin(t) * 0.03 }),
    kickGround: (t) => { const k = Math.max(0, sin(t * 4)); return { by: 0.8, head: 0.25, aL: [0.1, 0], aR: [0.1, 0], lL: [0.04, 0], lR: [0.3 * k, 0, k * 0.6], expr: 'sad' }; },
    handOnKnees: () => ({ by: 3, lean: 0.35, aL: [0.4, -0.2], aR: [0.4, -0.2], lL: [0.12, -0.15], lR: [0.12, -0.15], expr: 'sad' }),
    shake: (t, d) => ({ view: 'side', dir: d, by: 0, aL: [0.1, 0], aR: [1.25 + sin(t * 16) * 0.12, 0.25], lL: [0.05, 0], lR: [-0.05, 0], expr: 'smile' }),
    // running (side view and from behind)
    run: (t, k = 1, d = 1) => { const s = sin(t); return { view: 'side', dir: d, lean: 0.22 * k, by: -abs(s) * 2.6 * k, aL: [-s * 1.05 * k, 1.5], aR: [s * 1.05 * k, 1.5], lL: [s * 0.95 * k, -0.25 - Math.max(0, -s) * 1.1 * k], lR: [-s * 0.95 * k, -0.25 - Math.max(0, s) * 1.1 * k], expr: 'focused' }; },
    runBack: (t, k = 1) => { const s = sin(t); return { view: 'back', by: -abs(s) * 2.4 * k, bx: s * 0.6, aL: [0.3, -0.9, Math.max(0, s) * k], aR: [0.3, -0.9, Math.max(0, -s) * k], lL: [0.04, 0, Math.max(0, -s) * 0.9 * k], lR: [0.04, 0, Math.max(0, s) * 0.9 * k] }; },
    crouch: (d = 1) => ({ view: 'side', dir: d, lean: 1.05, by: 5, aL: [-0.15, 0], aR: [0.05, 0], lL: [0.85, -1.9], lR: [-0.45, -0.7], expr: 'focused' }),
    crouchBack: () => ({ view: 'back', by: 6, lean: 0, aL: [0.35, 0], aR: [0.35, 0], lL: [0.3, -0.6, 0.4], lR: [0.2, -0.3, 0.6] }),
    chestLean: (d = 1) => ({ view: 'side', dir: d, lean: 0.75, by: -1, aL: [-1.25, 0.4], aR: [-1.4, 0.2], lL: [0.5, -0.4], lR: [-0.75, -0.3], expr: 'strain' }),
    // football
    keeper: (t) => ({ by: 3 + sin(t * 6) * 0.6, aL: [1.05, 0.45], aR: [1.05, 0.45], lL: [0.32, -0.2], lR: [0.32, -0.2], expr: 'focused' }),
    dive: (k, dir) => ({ rot: dir * k * 1.25, by: -sin(Math.min(1, k) * Math.PI * 0.8) * 9, aL: [2.85, 0], aR: [2.85, 0], lL: [0.15, 0], lR: [0.15, 0], expr: 'shocked' }),
    kickBack: (k) => { // shooter seen from behind: wind up, strike
      const w = k < 0.5 ? k / 0.5 : 1 - (k - 0.5) / 0.5;
      return { view: 'back', lean: 0.08, by: -abs(sin(k * Math.PI)) * 2, aL: [1.1, 0.2], aR: [0.5 + w * 0.4, 0], lL: [0.06, 0], lR: [k < 0.5 ? -0.3 * w : 0.55 * (1 - w) + 0.2, k < 0.5 ? 0.9 * w : 0, k < 0.5 ? 0.2 : 0.75] };
    },
    plane: (t) => ({ by: -abs(sin(t * 9)) * 2, rot: sin(t * 3) * 0.28, aL: [1.57, 0], aR: [1.57, 0], lL: [0.1, 0, Math.max(0, sin(t * 9)) * 0.7], lR: [0.1, 0, Math.max(0, -sin(t * 9)) * 0.7], expr: 'happy' }),
    kneeSlide: (t) => ({ by: 7, lean: -0.25, aL: [2.55 + sin(t * 8) * 0.12, 0.2], aR: [2.55 - sin(t * 8) * 0.12, 0.2], lL: [0.35, 0, 0.95], lR: [0.35, 0, 0.95], expr: 'proud' }),
    backflip: (k) => ({ rot: -TAU * Math.min(1, Math.max(0, (k - 0.15) / 0.7)), by: -sin(Math.min(1, k) * Math.PI) * 30, sq: k < 0.15 ? -0.12 : k > 0.88 ? -0.1 : 0.06, aL: [2.4, 0.4], aR: [2.4, 0.4], lL: [0.1, 0, k > 0.2 && k < 0.8 ? 0.8 : 0], lR: [0.1, 0, k > 0.2 && k < 0.8 ? 0.8 : 0], expr: 'proud' }),
    // boxing (opponent faces the camera)
    guard: (t, f = 1) => ({ by: -abs(sin(t * 5)) * 2.4 * f, bx: sin(t * 2.5) * 1.6 * f, aL: [0.35, -2.55], aR: [0.35, -2.55], lL: [0.14, 0], lR: [0.14, 0], expr: 'focused' }),
    jab: (k, side) => { const p = sin(Math.min(1, k) * Math.PI); const A = [0.5 + p * 0.4, -2.4 + p * 2.2, p * 0.8]; return { by: 0, aL: side < 0 ? A : [0.35, -2.55], aR: side > 0 ? A : [0.35, -2.55], gsL: side < 0 ? 1 + p * 0.6 : 1, gsR: side > 0 ? 1 + p * 0.6 : 1, lL: [0.14, 0], lR: [0.14, 0], expr: 'focused', lean: side * p * 0.08 }; },
    hook: (k, side) => { const p = sin(Math.min(1, k) * Math.PI); const A = [1.6 - p * 0.3, -0.4 - p * 1.4]; return { aL: side < 0 ? A : [0.35, -2.55], aR: side > 0 ? A : [0.35, -2.55], lL: [0.14, 0], lR: [0.14, 0], lean: -side * p * 0.2, expr: 'strain' }; },
    hit: (k) => ({ lean: 0, rot: -0.18 * (1 - k), bx: 3 * (1 - k), sq: -0.12 * (1 - k), aL: [0.9, -1.4], aR: [0.9, -1.4], lL: [0.18, 0], lR: [0.18, 0], expr: 'shocked', head: -0.25 * (1 - k) }),
    stumble: (t) => ({ rot: sin(t * 3) * 0.2, bx: sin(t * 3) * 4, aL: [2.0 + sin(t * 7) * 0.4, 0.3], aR: [1.6 - sin(t * 7) * 0.4, 0.3], lL: [0.2, 0], lR: [0.05, 0, 0.3], expr: 'shocked' }),
    ko: (k) => ({ rot: -1.45 * Math.min(1, k), by: Math.min(1, k) * 8, aL: [2.4, 0.3], aR: [2.6, 0.2], lL: [0.25, 0], lR: [0.1, 0, 0.4], expr: 'ko' }),
    // gym
    chalk: (t) => { const c = abs(sin(t * 10)); return { aL: [0.5, -1.45 + c * 0.35], aR: [0.5, -1.45 + c * 0.35], lL: [0.1, 0], lR: [0.1, 0], expr: 'focused' }; },
    grab: () => ({ by: 6, lean: 0.12, aL: [0.28, 0], aR: [0.28, 0], lL: [0.45, -0.8], lR: [0.45, -0.8], expr: 'focused' }),
    strain: (t, k) => ({ by: 4 - k * 4, bx: sin(t * 46) * (0.6 + k * 1.2), aL: [0.75 + k * 1.95, -0.2 * (1 - k)], aR: [0.75 + k * 1.95, -0.2 * (1 - k)], lL: [0.35 - k * 0.15, -0.5 * (1 - k)], lR: [0.35 - k * 0.15, -0.5 * (1 - k)], expr: 'strain', sweat: t }),
    lockout: (t) => ({ by: -abs(sin(t * 5)) * 1.2, aL: [2.72, 0], aR: [2.72, 0], lL: [0.3, 0], lR: [0.3, 0], expr: 'proud' }),
    fallSit: () => ({ by: 9, lean: -0.2, aL: [1.2, 0.4], aR: [1.2, 0.4], lL: [0.5, 0, 0.9], lR: [0.4, 0, 0.9], expr: 'shocked' }),
    flex: (t) => ({ by: -abs(sin(t * 4)) * 1, aL: [1.6, 1.6 + sin(t * 8) * 0.08], aR: [1.6, 1.6 - sin(t * 8) * 0.08], lL: [0.22, 0], lR: [0.22, 0], expr: 'proud' }),
    // basketball (shooter seen from behind)
    dribble: (t) => ({ view: 'back', by: -abs(sin(t * 7)) * 1, aL: [0.25, -0.3], aR: [0.35 + abs(sin(t * 7)) * 0.2, -0.4], lL: [0.18, -0.2], lR: [0.18, -0.2] }),
    jumpShot: (k) => { const j = sin(Math.min(1, k) * Math.PI); return { view: 'back', by: -j * 16, sq: k < 0.1 ? -0.1 : 0.05, aL: [2.75, -0.5], aR: [2.9 - (k > 0.45 ? 0.3 : 0), k > 0.45 ? 0 : -0.7], lL: [0.12, 0, j * 0.3], lR: [0.12, 0, j * 0.3] }; },
    dunk: (k) => { const j = sin(Math.min(1, k) * Math.PI); return { view: 'back', by: -j * 40, sq: k < 0.08 ? -0.15 : k > 0.9 ? -0.08 : 0.08, aL: [2.95, 0], aR: [2.95 - (k > 0.62 ? 0.9 : 0), 0], lL: [0.2, -0.6, 0.4], lR: [0.1, -0.2, 0.2] }; },
    // swim start (on the block, from behind)
    block: () => ({ view: 'back', by: 5, lean: 0.4, aL: [0.1, 0], aR: [0.1, 0], lL: [0.12, -0.4, 0.3], lR: [0.12, -0.4, 0.3] }),
  };
  // sport-specific victory pose (winner) and how the others react (by rank)
  P.victory = (sport, t, L) => {
    switch (sport) {
      case 'football': return L && L.tier >= 5 ? P.backflip((t * 0.7) % 1.3) : L && (L.h || 0) % 2 ? P.kneeSlide(t) : P.plane(t);
      case 'gym': return P.flex(t);
      case 'boxing': return Object.assign(P.cheer(t * 0.8), { aL: [2.6, 0.2], aR: [2.6, 0.2] });
      case 'swim': return { by: -abs(sin(t * 5)) * 3, aL: [0.2, -0.3], aR: [2.9, -1.3 + sin(t * 10) * 0.2], lL: [0.05, 0], lR: [0.05, 0], expr: 'proud' };
      case 'hoops': return { by: -abs(sin(t * 5)) * 4, aL: [0.3, -0.4], aR: [3.0, 0], lL: [0.1, 0], lR: [0.1, 0], expr: 'proud' };
      default: return Object.assign(P.cheer(t), { expr: 'proud' });
    }
  };
  P.react = (rank, t) => (rank === 1 ? P.clap(t) : rank === 2 ? P.sad(t) : P.kickGround(t));

  // swimmer seen from above (pool lanes): head with cap, shoulders, alternating arm strokes, kicking splash
  function swimmer(g, x, y, s, L, ph, ang, under) {
    g.save(); g.translate(x, y); g.rotate(ang || 0); g.scale(s, s);
    const skin = L.skin || SKINS[1];
    if (!under) { g.fillStyle = 'rgba(255,255,255,.55)'; for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(sin(ph * 2 + i) * 4, 14 + i * 4, 2.6 - i * 0.5, 0, TAU); g.fill(); } }
    g.globalAlpha = under ? 0.55 : 1;
    const A = (side, p) => { const k = sin(p); g.strokeStyle = INK; g.lineWidth = 6.4; g.lineCap = 'round'; const ex = side * (8 + Math.max(0, -k) * 4), ey = -2 - k * 12; g.beginPath(); g.moveTo(side * 6, 0); g.lineTo(ex, ey); g.stroke(); g.strokeStyle = skin; g.lineWidth = 4.2; g.stroke(); };
    A(-1, ph); A(1, ph + Math.PI);
    g.fillStyle = css(L.kit && L.kit.shorts || '#1c7ed6'); g.beginPath(); g.ellipse(0, 9, 6, 4, 0, 0, TAU); g.fill();
    g.fillStyle = skin; g.strokeStyle = INK; g.lineWidth = 1.5; g.beginPath(); g.ellipse(0, 3, 9.5, 6.5, 0, 0, TAU); g.fill(); g.stroke();
    g.beginPath(); g.arc(0, -5, 6.4, 0, TAU); g.fillStyle = css(L.swim || '#ffa94d'); g.fill(); g.stroke();
    g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(-2, -7.5, 2.4, 1.3, -0.5, 0, TAU); g.fill();
    g.globalAlpha = 1;
    g.restore();
  }

  // ======================================================================
  // CROWD — rows of fans that bob, cheer and stand up; density drops on slow phones
  // ======================================================================
  const crowdCache = {};
  const FAN_COLS = ['#ff6b6b', '#4dabf7', '#51cf66', '#ffd43b', '#cc5de8', '#ff922b', '#f8f9fa', '#20c997'];
  function crowd(g, x, y, w, h, t, excite, dens, flags, bg) {
    const key = `${Math.round(w)}x${Math.round(h)}`;
    let fans = crowdCache[key];
    if (!fans) {
      fans = []; const rows = Math.max(1, Math.floor(h / 13));
      let seed = 7;
      const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      for (let r = 0; r < rows; r++) for (let fx = 5 + (r % 2) * 6; fx < w; fx += 12) fans.push({ x: fx + rnd() * 3, r, c: FAN_COLS[(rnd() * FAN_COLS.length) | 0], s: SKINS[(rnd() * 5) | 0], hc: HAIRS[(rnd() * 4) | 0], ph: rnd() * TAU, sp: 5 + rnd() * 4, a: rnd(), keep: rnd(), flag: rnd() < 0.12 });
      crowdCache[key] = fans;
    }
    g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
    g.fillStyle = bg || '#3b3f5c'; g.fillRect(x, y, w, h);
    const rows = Math.max(1, Math.floor(h / 13));
    for (let r = 0; r < rows; r++) { g.fillStyle = r % 2 ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.08)'; g.fillRect(x, y + r * 13, w, 13); }
    for (const f of fans) {
      if (f.keep > dens) continue;
      const stand = excite > 0.6 && f.a < excite;
      const bob = abs(sin(t * f.sp + f.ph)) * (1 + excite * 4) + (stand ? 3 : 0);
      const fx = x + f.x, fy = y + f.r * 13 + 12 - bob;
      g.fillStyle = f.c; rrect(g, fx - 4.5, fy - 4, 9, 9, 3.5); g.fill();
      if (excite > 0.3 && f.a < excite) { g.strokeStyle = f.s; g.lineWidth = 2.2; g.lineCap = 'round'; g.beginPath(); g.moveTo(fx - 3.5, fy - 2); g.lineTo(fx - 6, fy - 9 - sin(t * 9 + f.ph) * 2); g.moveTo(fx + 3.5, fy - 2); g.lineTo(fx + 6, fy - 9 + sin(t * 9 + f.ph) * 2); g.stroke(); }
      g.fillStyle = f.s; g.beginPath(); g.arc(fx, fy - 7, 3.6, 0, TAU); g.fill();
      g.fillStyle = f.hc; g.beginPath(); g.arc(fx, fy - 8.2, 3.6, Math.PI, TAU); g.fill();
      if (f.flag && flags && flags.length) { const fc = flags[(f.ph * 10 | 0) % flags.length]; g.strokeStyle = '#dee2e6'; g.lineWidth = 1; g.beginPath(); g.moveTo(fx + 5, fy); g.lineTo(fx + 5, fy - 16); g.stroke(); g.fillStyle = fc; g.beginPath(); g.moveTo(fx + 5, fy - 16); g.lineTo(fx + 13 + sin(t * 6 + f.ph) * 1.5, fy - 13); g.lineTo(fx + 5, fy - 10); g.fill(); }
    }
    g.restore();
  }

  // ======================================================================
  // PARTICLES (impact sparks, dust, splashes, confetti, chalk, sweat); the cap shrinks on slow phones
  // ======================================================================
  const FX = { list: [], cap: 220 };
  const CONF = ['#ff6b6b', '#ffd43b', '#51cf66', '#4dabf7', '#cc5de8', '#ff922b'];
  FX.add = function (kind, x, y, n, o = {}) {
    for (let i = 0; i < n && FX.list.length < FX.cap; i++) {
      const a = o.ang != null ? o.ang + (Math.random() - 0.5) * (o.spread || 1) : Math.random() * TAU;
      const sp = (o.speed || 120) * (0.4 + Math.random() * 0.8);
      const p = { kind, x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, t: 0, life: (o.life || 0.6) * (0.7 + Math.random() * 0.6), r: (o.size || 3) * (0.6 + Math.random() * 0.8), c: o.col || null, rot: Math.random() * TAU, vr: (Math.random() - 0.5) * 12 };
      if (kind === 'confetti') { p.c = CONF[(Math.random() * CONF.length) | 0]; p.vy -= 60; }
      FX.list.push(p);
    }
  };
  FX.ring = (x, y, r, col) => { if (FX.list.length < FX.cap) FX.list.push({ kind: 'ring', x, y, r, c: col || '#fff', t: 0, life: 0.35, vx: 0, vy: 0 }); };
  FX.update = function (dt) {
    for (const p of FX.list) {
      p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += (p.vr || 0) * dt;
      if (p.kind === 'splash' || p.kind === 'sweat') p.vy += 520 * dt;
      else if (p.kind === 'confetti') { p.vy += 140 * dt; p.vx *= 0.985; p.vy = Math.min(p.vy, 90); p.x += sin(p.t * 9 + p.rot) * 0.6; }
      else if (p.kind === 'dust' || p.kind === 'chalk') { p.vx *= 0.92; p.vy *= 0.92; p.vy -= 10 * dt; }
      else { p.vx *= 0.9; p.vy *= 0.9; }
    }
    FX.list = FX.list.filter((p) => p.t < p.life);
  };
  FX.draw = function (g) {
    for (const p of FX.list) {
      const k = p.t / p.life, al = 1 - k;
      g.globalAlpha = Math.max(0, al);
      switch (p.kind) {
        case 'spark': g.strokeStyle = p.c || '#fff3bf'; g.lineWidth = 2.6 * al + 0.5; g.lineCap = 'round'; g.beginPath(); g.moveTo(p.x, p.y); g.lineTo(p.x - p.vx * 0.05, p.y - p.vy * 0.05); g.stroke(); break;
        case 'dust': g.fillStyle = p.c || 'rgba(222,226,230,.9)'; g.beginPath(); g.arc(p.x, p.y, p.r * (1 + k * 2), 0, TAU); g.fill(); break;
        case 'chalk': g.fillStyle = '#fff'; g.beginPath(); g.arc(p.x, p.y, p.r * (1 + k * 2.4), 0, TAU); g.fill(); break;
        case 'splash': g.fillStyle = p.c || '#e7f5ff'; g.beginPath(); g.arc(p.x, p.y, p.r, 0, TAU); g.fill(); break;
        case 'sweat': g.fillStyle = '#74c0fc'; g.beginPath(); g.arc(p.x, p.y, p.r * 0.7, 0, TAU); g.fill(); break;
        case 'confetti': g.save(); g.translate(p.x, p.y); g.rotate(p.rot); g.fillStyle = p.c; g.fillRect(-p.r, -p.r * 0.45, p.r * 2, p.r * 0.9); g.restore(); break;
        case 'ring': g.strokeStyle = p.c; g.lineWidth = 4 * al; g.beginPath(); g.arc(p.x, p.y, p.r * (0.4 + k * 1.4), 0, TAU); g.stroke(); break;
        case 'star': star(g, p.x, p.y, p.r * (1 - k * 0.4), p.c || '#ffd43b'); break;
      }
    }
    g.globalAlpha = 1;
  };
  FX.clear = () => { FX.list.length = 0; };
  // a comic impact burst: white flash + spikes
  function impact(g, x, y, r, k) {
    g.save(); g.translate(x, y); g.globalAlpha = Math.max(0, 1 - k);
    g.fillStyle = '#fff'; g.beginPath();
    for (let i = 0; i < 16; i++) { const a = (i * TAU) / 16, rr2 = (i % 2 ? 0.45 : 1) * r * (0.6 + k * 0.7); g.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); }
    g.closePath(); g.fill(); g.lineWidth = 2; g.strokeStyle = '#ffd43b'; g.stroke();
    g.restore();
  }

  AT.Toon = { css, shade, hash, look, KITS, SKINS, HAIRS, face, char, P, swimmer, crowd, FX, impact, star, rrect, INK };
})();
