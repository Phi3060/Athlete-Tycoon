/* Athlete Tycoon — all audio is synthesized with WebAudio (no sound files).
   Two music loops (relaxed academy theme, energetic tournament theme) and the sound effects,
   on separate gain buses so music and effects can be switched off independently. */
'use strict';
(function () {
  const AT = (window.AT = window.AT || {});
  const A = {
    ctx: null, sfxOn: true, musicOn: true, ytOn: true, paused: false, last: {},
    master: null, sfxBus: null, musBus: null, noiseBuf: null,
    track: null, want: 'academy', nextT: 0, step: 0, timer: 0,
  };

  A.unlock = function () {
    if (!A.ctx) {
      try { A.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
      const c = A.ctx;
      A.master = c.createGain(); A.master.connect(c.destination);
      A.sfxBus = c.createGain(); A.sfxBus.connect(A.master);
      A.musBus = c.createGain(); A.musBus.gain.value = 0; A.musBus.connect(A.master);
      // one shared second of white noise for hats, snares, whooshes and the crowd
      A.noiseBuf = c.createBuffer(1, c.sampleRate, c.sampleRate);
      const d = A.noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      A.timer = setInterval(schedule, 90);
      A.apply();
    }
    if (A.ctx.state === 'suspended' && !A.paused) A.ctx.resume();
  };
  // pause / resume everything (music, effects, scheduled notes)
  A.setPaused = function (p) {
    A.paused = p;
    if (!A.ctx) return;
    if (p) A.ctx.suspend(); else { A.ctx.resume(); A.nextT = Math.max(A.nextT, A.ctx.currentTime + 0.05); }
  };
  // re-read the on/off switches
  A.apply = function () {
    if (!A.ctx) return;
    const t = A.ctx.currentTime;
    A.sfxBus.gain.setTargetAtTime(A.sfxOn && A.ytOn ? 1 : 0, t, 0.02);
    A.musBus.gain.setTargetAtTime(A.musicOn && A.ytOn && A.want ? 0.55 : 0, t, 0.4);
  };
  A.music = function (name) {
    if (A.want === name) return;
    A.want = name;
    if (!A.ctx) return;
    // quick fade, then the new theme starts on a fresh bar
    const t = A.ctx.currentTime;
    A.musBus.gain.setTargetAtTime(0, t, 0.12);
    setTimeout(() => { A.track = null; A.apply(); }, 450);
  };

  // ---------- low-level voices ----------
  function osc(bus, f, t, d, type, v, f2, attack) {
    const c = A.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    const a = attack || 0.005;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(v, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(bus);
    o.start(t); o.stop(t + d + 0.05);
  }
  function noise(bus, t, d, v, type, freq, q) {
    const c = A.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = A.noiseBuf; s.loop = true;
    f.type = type || 'highpass'; f.frequency.value = freq || 6000; f.Q.value = q || 0.7;
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(f); f.connect(g); g.connect(bus);
    s.start(t, Math.random() * 0.5); s.stop(t + d + 0.05);
  }
  const hz = (n) => 440 * Math.pow(2, (n - 69) / 12); // MIDI note -> Hz

  // ---------- music ----------
  // 8 steps per bar (eighth notes); chords as MIDI roots + triad
  const THEMES = {
    academy: {
      bpm: 98,
      chords: [[60, 64, 67], [57, 60, 64], [53, 57, 60], [55, 59, 62]],            // C  Am  F  G
      // melody per 4 bars (32 eighths), null = rest — C major pentatonic, easy-going
      mel: [76, null, 74, 72, null, 67, 69, null, 72, null, 69, 67, null, 64, 67, null,
        69, null, 72, 74, null, 72, 69, null, 67, null, 69, 72, 74, null, 72, null],
      play(st, t, d) {
        const bar = Math.floor(st / 8) % 4, s = st % 8, ch = this.chords[bar], b = A.musBus;
        if (s === 0) ch.forEach((n) => osc(b, hz(n), t, d * 7.6, 'triangle', 0.035, null, 0.25));    // soft pad
        if (s === 0 || s === 4) osc(b, hz(ch[0] - 24), t, d * 3.4, 'sine', 0.16, null, 0.01);        // bass
        if (s === 6) osc(b, hz(ch[2] - 24), t, d * 1.6, 'sine', 0.1);
        const m = this.mel[st % 32];
        if (m && (Math.floor(st / 32) % 2 === 0 || st % 4 !== 3)) osc(b, hz(m), t, d * 1.8, 'sine', 0.06, null, 0.008); // pluck
        if (s % 2 === 1) noise(b, t, 0.03, 0.025, 'highpass', 8000);                                  // light hat
      },
    },
    tourney: {
      bpm: 136,
      chords: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]],            // Am  F  C  G
      arp: [0, 1, 2, 1, 0, 2, 1, 2],
      play(st, t, d) {
        const bar = Math.floor(st / 8) % 4, s = st % 8, ch = this.chords[bar], b = A.musBus;
        if (s % 2 === 0) osc(b, 150, t, 0.16, 'sine', 0.3, 45);                                       // kick
        if (s === 2 || s === 6) noise(b, t, 0.12, 0.09, 'bandpass', 1800, 0.8);                      // snare
        noise(b, t, 0.025, s % 2 ? 0.035 : 0.02, 'highpass', 9000);                                   // hats
        osc(b, hz(ch[0] - 24), t, d * 0.9, 'sawtooth', 0.045);                                        // driving bass
        osc(b, hz(ch[this.arp[s]] + 12), t, d * 0.8, 'square', 0.022);                               // arpeggio
        if (s === 0 && bar % 2 === 0) osc(b, hz(ch[2] + 12), t, d * 3, 'triangle', 0.04, null, 0.02);
      },
    },
  };
  function schedule() {
    const c = A.ctx;
    if (!c || A.paused || c.state !== 'running' || !A.want || !A.musicOn || !A.ytOn) { if (c) A.nextT = c.currentTime + 0.05; return; }
    const th = THEMES[A.want];
    if (A.track !== A.want) { A.track = A.want; A.step = 0; A.nextT = c.currentTime + 0.08; A.apply(); }
    const d = 60 / th.bpm / 2;
    if (A.nextT < c.currentTime - 0.2) A.nextT = c.currentTime + 0.05; // after a hiccup, don't burst-play missed notes
    while (A.nextT < c.currentTime + 0.3) {
      th.play(A.step, A.nextT, d);
      A.nextT += d; A.step++;
    }
  }

  // ---------- sound effects ----------
  A.play = function (n, minGap) {
    const c = A.ctx;
    if (!c || !A.sfxOn || !A.ytOn || A.paused || c.state !== 'running') return;
    const now = performance.now();
    if (minGap && A.last[n] && now - A.last[n] < minGap) return;
    A.last[n] = now;
    const t = c.currentTime, b = A.sfxBus;
    const seq = (notes, step, d, type, v) => notes.forEach((f, i) => osc(b, f, t + i * step, d, type, v));
    switch (n) {
      case 'coin': osc(b, 1320, t, 0.07, 'square', 0.035); osc(b, 1980, t + 0.05, 0.12, 'square', 0.03); break;
      case 'pick': osc(b, 500, t, 0.08, 'triangle', 0.12, 820); break;
      case 'drop': osc(b, 760, t, 0.09, 'triangle', 0.12, 380); break;
      case 'tick': osc(b, 880 + Math.random() * 200, t, 0.03, 'square', 0.025); break;
      case 'buy': seq([523, 659, 784, 1046], 0.07, 0.16, 'triangle', 0.11); break;
      case 'level': seq([784, 988, 1318], 0.08, 0.12, 'sine', 0.1); break;
      case 'tier':
        osc(b, 300, t, 0.5, 'sine', 0.08, 1200);
        [659, 784, 988, 1318, 1568].forEach((f, i) => osc(b, f, t + 0.35 + i * 0.08, 0.18, 'triangle', 0.1));
        break;
      case 'legend': seq([523, 659, 784, 1046, 784, 1046, 1318], 0.1, 0.22, 'square', 0.06); break;
      case 'whistle': osc(b, 2300, t, 0.12, 'sine', 0.07, 2500); osc(b, 2300, t + 0.16, 0.3, 'sine', 0.07, 2600); break;
      case 'tap': osc(b, 620, t, 0.05, 'square', 0.05); break;
      case 'good': osc(b, 740, t, 0.08, 'square', 0.045); osc(b, 988, t + 0.06, 0.1, 'square', 0.045); break;
      case 'perfect': seq([880, 1175, 1568], 0.05, 0.1, 'square', 0.05); break;
      case 'miss': osc(b, 300, t, 0.25, 'sawtooth', 0.05, 140); break;
      case 'win': seq([523, 659, 784, 659, 784, 1046], 0.11, 0.18, 'triangle', 0.12); break;
      case 'lose': seq([440, 392, 330], 0.14, 0.22, 'triangle', 0.1); break;
      case 'punch': osc(b, 160, t, 0.12, 'square', 0.08, 60); break;
      case 'trash': osc(b, 260 + Math.random() * 60, t, 0.07, 'square', 0.05, 120); noise(b, t, 0.06, 0.05, 'bandpass', 900, 1.2); break;
      case 'full': osc(b, 520, t, 0.08, 'triangle', 0.08); osc(b, 390, t + 0.08, 0.12, 'triangle', 0.08); break;
      case 'crowd': {
        // swelling cheer: band-passed noise plus a scatter of claps
        const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
        s.buffer = A.noiseBuf; s.loop = true; f.type = 'bandpass'; f.frequency.value = 1400; f.Q.value = 0.6;
        g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.13, t + 0.35); g.gain.linearRampToValueAtTime(0.09, t + 1.3); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.4);
        s.connect(f); f.connect(g); g.connect(b); s.start(t); s.stop(t + 2.5);
        for (let i = 0; i < 22; i++) noise(b, t + 0.1 + Math.random() * 1.8, 0.04, 0.05 + Math.random() * 0.05, 'bandpass', 2200 + Math.random() * 1500, 1.5);
        osc(b, 1600, t + 0.2, 0.25, 'sine', 0.03, 2200); // a whistle in the crowd
        break;
      }
      case 'scout': // the scout is back: whoosh + bright fanfare
        noise(b, t, 0.35, 0.08, 'bandpass', 900, 0.7);
        seq([659, 880, 1109, 1319], 0.09, 0.2, 'triangle', 0.1);
        osc(b, 1760, t + 0.4, 0.4, 'sine', 0.06);
        break;
      case 'sign': seq([784, 988, 1175, 1568], 0.06, 0.2, 'square', 0.05); break;
      case 'chest': noise(b, t, 0.2, 0.06, 'lowpass', 600); seq([523, 784, 1046, 1318, 1568], 0.07, 0.25, 'triangle', 0.1); break;
      case 'release': seq([523, 440, 349], 0.1, 0.18, 'sine', 0.08); break;
      // minigame show
      case 'count': osc(b, 660, t, 0.14, 'square', 0.06); break;
      case 'go': osc(b, 1046, t, 0.32, 'square', 0.07); osc(b, 1318, t, 0.32, 'triangle', 0.05); break;
      case 'fanfare': seq([523, 523, 523, 659, 784, 659, 784, 1046], 0.12, 0.24, 'square', 0.055); seq([262, 330, 392, 523], 0.24, 0.4, 'triangle', 0.07); break;
      case 'kick': osc(b, 180, t, 0.1, 'sine', 0.22, 60); noise(b, t, 0.05, 0.08, 'lowpass', 1200); break;
      case 'net': noise(b, t, 0.3, 0.07, 'bandpass', 2400, 0.6); break;
      case 'swish': noise(b, t, 0.22, 0.06, 'highpass', 3500); break;
      case 'splash': noise(b, t, 0.4, 0.1, 'lowpass', 1800); noise(b, t + 0.05, 0.25, 0.05, 'highpass', 4000); break;
      case 'whoosh': noise(b, t, 0.28, 0.07, 'bandpass', 700, 0.5); break;
      case 'dunk': osc(b, 110, t, 0.25, 'sine', 0.25, 50); noise(b, t, 0.18, 0.08, 'bandpass', 1500, 0.9); break;
      case 'thud': osc(b, 90, t, 0.22, 'sine', 0.25, 40); noise(b, t, 0.12, 0.06, 'lowpass', 500); break;
      case 'ko': osc(b, 140, t, 0.3, 'square', 0.09, 50); seq([988, 784, 659, 523], 0.09, 0.14, 'triangle', 0.06); break;
    }
  };

  AT.Audio = A;
})();
