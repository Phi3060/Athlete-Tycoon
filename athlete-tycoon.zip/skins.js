/* Athlete Tycoon — character builder, star-tier skins, zone legends, idle poses, and 3D portrait thumbnails. */
'use strict';
(function () {
  const AT = (window.AT = window.AT || {});

  const TIERS = [
    { name: 'Rookie', icon: 'star', desc: 'Grey tee, simple sneakers' },
    { name: 'Amateur', icon: 'star', desc: 'Club jersey and headband' },
    { name: 'Pro', icon: 'star', desc: 'Numbered kit, wristbands and shades' },
    { name: 'Star', icon: 'star', desc: 'Shiny striped kit, cape and golden shoes' },
    { name: 'Legend', icon: 'crown', desc: 'All gold, glowing aura and crown' },
  ];
  // One fictional legend per zone (same order as ZONES in game.js)
  const LEGENDS = [
    { name: 'Lightning Leo', sig: 'bolt', trail: 'lightning', aura: 0x74c0fc, desc: 'Fastest sprinter alive' },
    { name: 'Titan Tara', sig: 'dumbbell', trail: 'lightning', aura: 0xffd43b, desc: 'Lifts a giant golden dumbbell' },
    { name: 'Golden Boot Gabi', sig: 'ball', trail: 'lightning', aura: 0xffe066, desc: 'A golden ball spins above her head' },
    { name: 'Shark Sami', sig: 'fin', trail: 'wave', aura: 0x3bc9db, desc: 'Leaves a wave behind him' },
    { name: 'Iron Ivan', sig: 'gloves', trail: 'lightning', aura: 0xff6b6b, desc: 'Glowing red gloves' },
    { name: 'Comet Cora', sig: 'comet', trail: 'comet', aura: 0xffa94d, desc: 'Leaves a blazing comet tail' },
    { name: 'Sky King Kofi', sig: 'basketball', trail: 'comet', aura: 0xff922b, desc: 'Dunks with a trail of fire' },
  ];
  const ACADEMY = 0xffa94d;

  // ---------- caches ----------
  const _m = {}, _g = {};
  function M(color, kind = 'flat') {
    const k = color + kind;
    if (_m[k]) return _m[k];
    let m;
    switch (kind) {
      case 'basic': m = new THREE.MeshBasicMaterial({ color }); break;
      case 'shiny': m = new THREE.MeshPhongMaterial({ color, shininess: 90, specular: 0x8a8a8a }); break;
      case 'gold': m = new THREE.MeshPhongMaterial({ color: 0xffd43b, emissive: 0x6b4500, shininess: 110, specular: 0xfff3bf }); break;
      case 'glow': m = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending, depthWrite: false }); break;
      case 'hot': m = new THREE.MeshPhongMaterial({ color, emissive: color, emissiveIntensity: 0.7, shininess: 60 }); break;
      case 'double': m = new THREE.MeshPhongMaterial({ color, shininess: 30, specular: 0x262626, side: THREE.DoubleSide }); break;
      default: m = new THREE.MeshPhongMaterial({ color, shininess: 30, specular: 0x2a2a2a }); // soft glossy toy look
    }
    return (_m[k] = m);
  }
  const GEO = (k, make) => _g[k] || (_g[k] = make());
  const boxG = (w, h, d) => GEO(`b${w},${h},${d}`, () => new THREE.BoxGeometry(w, h, d));
  const sphG = (r, ws = 8, hs = 6) => GEO(`s${r},${ws},${hs}`, () => new THREE.SphereGeometry(r, ws, hs));
  const cylG = (rt, rb, h, s = 8) => GEO(`c${rt},${rb},${h},${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
  const mesh = (geo, mat, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return m; };
  const hairGeo = new THREE.SphereGeometry(0.37, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.48);
  const shadowGeo = new THREE.CircleGeometry(0.5, 16);
  const shadowMat = new THREE.MeshBasicMaterial({ color: 0x1b2a3a, transparent: true, opacity: 0.2, depthWrite: false });
  const blob = (r) => { const m = new THREE.Mesh(shadowGeo, shadowMat); m.rotation.x = -Math.PI / 2; m.position.y = 0.025; m.scale.setScalar(r * 2); return m; };

  // small canvas textures (numbers, names, faces, logo) are drawn large and use trilinear mipmaps + anisotropy
  const crisp = (t) => {
    t.minFilter = THREE.LinearMipmapLinearFilter; t.magFilter = THREE.LinearFilter; t.generateMipmaps = true;
    t.anisotropy = AT.renderer ? Math.min(8, AT.renderer.capabilities.getMaxAnisotropy()) : 4;
    return t;
  };
  const numTex = {};
  const hexCss = (c) => '#' + (c == null ? 0xffffff : c).toString(16).padStart(6, '0');
  function numberTexture(n, col) {
    const key = n + '|' + col;
    if (numTex[key]) return numTex[key];
    const c = document.createElement('canvas'); c.width = 256; c.height = 256;
    const g = c.getContext('2d'); g.scale(4, 4);
    g.fillStyle = hexCss(col); g.font = '900 46px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(n), 32, 35);
    const t = crisp(new THREE.CanvasTexture(c));
    return (numTex[key] = t);
  }
  // football shirt back: short name above a big number, on a curved strip that follows the torso
  const backGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.42, 14, 1, true, Math.PI - 0.62, 1.24);
  function backTexture(name, n, col) {
    const key = `bk${name}|${n}|${col}`;
    if (numTex[key]) return numTex[key];
    const c = document.createElement('canvas'); c.width = 640; c.height = 600;
    const g = c.getContext('2d'); g.scale(4, 4);
    g.fillStyle = hexCss(col); g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = '900 24px system-ui, sans-serif'; g.fillText(String(name).split(' ')[0].toUpperCase().slice(0, 9), 80, 22, 150);
    g.font = '900 92px system-ui, sans-serif'; g.fillText(String(n), 80, 92);
    const t = crisp(new THREE.CanvasTexture(c));
    return (numTex[key] = t);
  }
  // vertical-striped shirt (e.g. the Argentina-style kit)
  const _stripe = {};
  function stripeMat(a, b) {
    const k = a + '|' + b;
    if (_stripe[k]) return _stripe[k];
    const c = document.createElement('canvas'); c.width = 128; c.height = 8;
    const g = c.getContext('2d');
    for (let i = 0; i < 16; i++) { g.fillStyle = hexCss(i % 2 ? b : a); g.fillRect(i * 8, 0, 8, 8); }
    const t = crisp(new THREE.CanvasTexture(c));
    return (_stripe[k] = new THREE.MeshPhongMaterial({ map: t, shininess: 30, specular: 0x2a2a2a }));
  }
  const texOf = {};
  function textTexture(key, w, h, draw) {
    if (texOf[key]) return texOf[key];
    const c = document.createElement('canvas'); c.width = w * 4; c.height = h * 4;
    const g = c.getContext('2d'); g.scale(4, 4); draw(g, w, h);
    const t = crisp(new THREE.CanvasTexture(c));
    return (texOf[key] = t);
  }
  // race bib: dark number on a white card
  const bibTexture = (n) => textTexture('bib' + n, 64, 52, (g, w, h) => {
    g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.strokeStyle = '#ced4da'; g.lineWidth = 3; g.strokeRect(1.5, 1.5, w - 3, h - 3);
    g.fillStyle = '#e03131'; g.beginPath(); g.arc(8, 8, 3, 0, 7); g.arc(w - 8, 8, 3, 0, 7); g.fill();
    g.fillStyle = '#212529'; g.font = '900 30px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(n), w / 2, h / 2 + 3);
  });
  // boxing waistband name
  const bandTexture = (name, col) => textTexture('wb' + name + col, 128, 24, (g, w, h) => {
    g.fillStyle = col; g.font = '900 19px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(name).toUpperCase(), w / 2, h / 2 + 1, w - 8);
  });
  const boltGeo = (() => {
    const s = new THREE.Shape();
    s.moveTo(0.04, 0.16); s.lineTo(-0.08, -0.01); s.lineTo(0.0, -0.01); s.lineTo(-0.05, -0.16); s.lineTo(0.09, 0.03); s.lineTo(0.01, 0.03); s.lineTo(0.06, 0.16);
    return new THREE.ShapeGeometry(s);
  })();

  // ======================================================================
  // TOON LOOK: thin dark outline (inverted hull), expressive face textures, hairstyles, body builds
  // ======================================================================
  const TOON = AT.Toon;
  const OUTL = new THREE.MeshBasicMaterial({ color: 0x1f2433, side: THREE.BackSide });
  function outl(m, kx = 1.06, ky = kx, kz = kx) { const o = new THREE.Mesh(m.geometry, OUTL); o.scale.set(kx, ky, kz); o.userData.shd = 1; m.add(o); return o; }
  // the face is a texture on a slice of sphere in front of the head; same drawing as the 2D minigames
  const faceGeo = new THREE.SphereGeometry(0.357, 24, 14, Math.PI / 2 - 0.95, 1.9, 0.95, 1.1);
  const faceTex = {};
  function faceTexture(v, expr) {
    const key = `${v.eye | 0}${v.brow | 0}${v.lash ? 1 : 0}${v.freck ? 1 : 0}${expr}`;
    if (faceTex[key]) return faceTex[key];
    const c = document.createElement('canvas'); c.width = 384; c.height = 224;
    const fg = c.getContext('2d'); fg.scale(2, 2);
    TOON.face(fg, 96, 63, 99, v, expr, true);
    const t = crisp(new THREE.CanvasTexture(c));
    return (faceTex[key] = t);
  }
  function setExpr(u, e) {
    if (!u.face || u.exprNow === e) return;
    u.exprNow = e; u.face.material.map = faceTexture(u.fv, e);
  }
  const coneG = (r, h) => GEO(`cn${r},${h}`, () => new THREE.ConeGeometry(r, h, 7));
  const longGeo = new THREE.CylinderGeometry(0.37, 0.41, 0.55, 16, 1, true, Math.PI / 2, Math.PI);
  function addHair(head, st, col, kind, capped) {
    const hm = M(col, kind), add = (m) => { head.add(m); return m; };
    const capMesh = (k = 1) => { const h = mesh(hairGeo, hm, 0, 0.04, -0.04); h.rotation.x = -0.35; h.scale.setScalar(k); add(h); outl(h, 1.05); return h; };
    const back = () => {
      if (st === 'ponytail') { const t = add(mesh(sphG(0.12, 12, 8), hm, 0, 0.08, -0.43)); t.scale.set(0.9, 1.9, 0.9); t.rotation.x = 0.55; outl(t, 1.1); add(mesh(sphG(0.06, 8, 6), M(0xff6b9a), 0, 0.22, -0.38)); }
      if (st === 'long' || st === 'bob') { const b = add(mesh(longGeo, M(col, 'double'), 0, st === 'bob' ? 0.0 : -0.08, -0.03)); b.scale.y = st === 'bob' ? 0.75 : 1.1; }
      if (st === 'braids') for (const x of [-0.27, 0.27]) for (let k = 0; k < 3; k++) add(mesh(sphG(0.066, 8, 6), hm, x, -0.06 - k * 0.11, -0.13));
    };
    if (capped) { back(); return; }
    switch (st) {
      case 'bald': return;
      case 'buzz': { const h = add(mesh(hairGeo, hm, 0, 0.02, -0.02)); h.rotation.x = -0.25; h.scale.setScalar(0.975); return; }
      case 'spiky': capMesh(); for (let i = 0; i < 7; i++) { const a = (i / 7) * Math.PI * 2; const c = add(mesh(coneG(0.09, 0.26), hm, Math.sin(a) * 0.17, 0.34, Math.cos(a) * 0.14 - 0.06)); c.rotation.set(Math.cos(a) * 0.65, 0, -Math.sin(a) * 0.65); } add(mesh(coneG(0.1, 0.3), hm, 0, 0.44, -0.04)); return;
      case 'afro': { const a = add(mesh(sphG(0.46, 18, 14), hm, 0, 0.15, -0.07)); a.scale.set(1, 0.86, 1); outl(a, 1.04); return; }
      case 'mohawk': { capMesh(0.97); const m = add(mesh(boxG(0.1, 0.22, 0.64), hm, 0, 0.37, -0.07)); outl(m, 1.18, 1.08, 1.04); return; }
      case 'quiff': { capMesh(); const q = add(mesh(sphG(0.2, 14, 10), hm, 0.03, 0.32, 0.15)); q.scale.set(1.35, 0.75, 1); outl(q, 1.06); return; }
      case 'buns': capMesh(); for (const x of [-0.23, 0.23]) outl(add(mesh(sphG(0.13, 12, 8), hm, x, 0.33, -0.05)), 1.08); back(); return;
      default: { // short with a fringe (also under ponytail / long / braids)
        capMesh();
        const f = add(mesh(sphG(0.17, 12, 8), hm, -0.07, 0.27, 0.22)); f.scale.set(1.45, 0.55, 0.8); f.rotation.z = 0.15;
        back();
      }
    }
  }

  // ======================================================================
  // BASE FIGURE (used by the player's coach, helpers, athletes and rivals)
  // chibi proportions: big head, compact rounded body, short limbs
  // ======================================================================
  function figure(o) {
    const g = new THREE.Group();
    const sc = o.scale || 1, lk = o.look || {}, build = lk.build || 1;
    const root = new THREE.Group(); root.scale.setScalar(sc); g.add(root);
    g.add(blob(0.42 * sc));
    const body = new THREE.Group(); body.scale.set(build, 1, build); root.add(body);
    const skinM = M(o.skin || 0xffd6b0);
    const torso = mesh(sphG(0.4, 20, 14), M(o.shirt, o.shirtKind), 0, 0.8, 0); torso.scale.set(1, 1.08, 0.85); body.add(torso); outl(torso, 1.055);
    body.add(mesh(cylG(0.33, 0.37, 0.22, 16), M(o.shorts || 0x343a40, o.shortsKind), 0, 0.5, 0));
    const head = new THREE.Group(); head.position.y = 1.42; head.scale.set(1.12 / build, 1.12, 1.12 / build); body.add(head);
    const hm = mesh(sphG(0.35, 24, 16), skinM); head.add(hm); outl(hm, 1.06);
    head.add(mesh(sphG(0.07, 8, 6), skinM, -0.345, -0.02, 0.0), mesh(sphG(0.07, 8, 6), skinM, 0.345, -0.02, 0.0)); // ears
    const fv = Object.assign({}, lk.face || { eye: 0 });
    const face = new THREE.Mesh(faceGeo, new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, map: faceTexture(fv, 'smile') }));
    face.renderOrder = 2; head.add(face);
    if (o.cap) {
      const cap = mesh(hairGeo, M(o.cap, o.capKind), 0, 0.06, -0.02); cap.scale.set(1.04, o.flatCap ? 0.62 : 0.9, 1.04); head.add(cap); outl(cap, 1.04);
      head.add(mesh(boxG(0.42, 0.05, 0.3), M(o.capBrim || o.cap, o.capKind), 0, o.flatCap ? 0.15 : 0.2, 0.34));
      if (!o.bald) addHair(head, lk.style || 'short', o.hair || 0x3b2a1a, o.hairKind, true);
    } else if (!o.bald) addHair(head, lk.style || 'short', o.hair || 0x3b2a1a, o.hairKind, false);
    if (o.whistle) body.add(mesh(sphG(0.06, 10, 8), M(o.whistle === 'gold' ? GOLD : 0xced4da, o.whistle === 'gold' ? 'gold' : 'shiny'), 0, 1.0, 0.37));
    const limb = (x, y, len, col, kind, endCol, endKind, isLeg) => {
      const p = new THREE.Group(); p.position.set(x, y, 0);
      p.add(mesh(cylG(0.095, 0.085, len, 12), M(col, kind), 0, -len / 2, 0));
      const end = isLeg ? mesh(sphG(0.13, 14, 10), M(endCol, endKind), 0, -len - 0.03, 0.06)
        : mesh(sphG(0.12, 14, 10), M(endCol, endKind), 0, -len, 0.02);
      if (isLeg) end.scale.set(0.78, 0.55, 1.25);
      p.add(end); body.add(p); p.userData.end = end; return p;
    };
    // swappable parts: sleeve (arm) colour, hands (e.g. chalk), legs (socks, leggings, suits), shoes
    const armL = limb(-0.42, 1.02, 0.34, o.sleeve || o.shirt, o.sleeveKind || o.shirtKind, o.hands || o.skin || 0xffd6b0, o.handsKind);
    const armR = limb(0.42, 1.02, 0.34, o.sleeve || o.shirt, o.sleeveKind || o.shirtKind, o.hands || o.skin || 0xffd6b0, o.handsKind);
    const legL = limb(-0.16, 0.45, 0.28, o.legs || o.skin || 0xffd6b0, o.legsKind, o.shoes || 0xffffff, o.shoesKind, true);
    const legR = limb(0.16, 0.45, 0.28, o.legs || o.skin || 0xffd6b0, o.legsKind, o.shoes || 0xffffff, o.shoesKind, true);
    g.userData = { root, body, head, torso, armL, armR, legL, legR, skinM, face, fv, sc, ph: Math.random() * 6, fx: { spin: [] } };
    return g;
  }

  // ======================================================================
  // ATHLETE SKINS
  // ======================================================================
  function crown() {
    const c = new THREE.Group();
    c.add(mesh(cylG(0.2, 0.22, 0.12, 10), M(0, 'gold')));
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const s = mesh(GEO('spike', () => new THREE.ConeGeometry(0.05, 0.14, 4)), M(0, 'gold'), Math.sin(a) * 0.19, 0.12, Math.cos(a) * 0.19);
      c.add(s);
    }
    c.add(mesh(sphG(0.04, 6, 4), M(0xff6b6b, 'hot'), 0, 0.03, 0.21));
    return c;
  }

  // ======================================================================
  // SPORT OUTFITS — every athlete is the same base figure with swappable parts and colours.
  // Each sport has its own kit; the star level (1-5) upgrades the look inside that sport's style.
  // ======================================================================
  const ZONE_SPORT = ['track', 'gym', 'football', 'swim', 'boxing', 'track', 'hoops']; // stadium relay runners wear track kit
  const GOLD = 0, WHITE = 0xffffff, INKC = 0x212529;
  const shade = (c, k) => new THREE.Color(c).multiplyScalar(k).getHex();
  // small reusable parts
  const P = {
    bib(u, n) { const b = mesh(GEO('bibg', () => new THREE.PlaneGeometry(0.34, 0.27)), new THREE.MeshBasicMaterial({ map: bibTexture(n) }), 0, 0.84, 0.352); u.body.add(b); },
    number(u, n, col, k = 1) { const m = mesh(GEO('plate', () => new THREE.PlaneGeometry(0.3, 0.3)), new THREE.MeshBasicMaterial({ map: numberTexture(n, col), transparent: true }), k < 1 ? 0.13 : 0, k < 1 ? 0.93 : 0.84, k < 1 ? 0.31 : 0.35); m.scale.setScalar(k); if (k < 1) m.rotation.set(-0.25, 0.3, 0); u.body.add(m); },
    backName(u, name, n, col) { const m = mesh(backGeo, new THREE.MeshBasicMaterial({ map: backTexture(name, n, col), transparent: true }), 0, 0.84, 0); m.scale.set(1.13, 1, 0.97); u.body.add(m); },
    sideStripes(u, col, kind) { for (const x of [-0.37, 0.37]) u.body.add(mesh(boxG(0.05, 0.62, 0.3), M(col, kind), x, 0.74, 0)); },
    frontStripes(u, col, kind) { for (const x of [-0.2, 0.2]) u.body.add(mesh(boxG(0.06, 0.6, 0.06), M(col, kind), x, 0.8, 0.3)); },
    shortSleeves(u, col, kind) { for (const a of [u.armL, u.armR]) a.add(mesh(cylG(0.13, 0.12, 0.17, 8), M(col, kind), 0, -0.07, 0)); },
    wrist(u, col, kind) { for (const a of [u.armL, u.armR]) a.add(mesh(cylG(0.1, 0.1, 0.08, 8), M(col, kind), 0, -0.28, 0)); },
    shades(u, col, kind) {
      u.head.add(mesh(boxG(0.52, 0.06, 0.05), M(INKC), 0, 0.06, 0.37));
      u.head.add(mesh(boxG(0.17, 0.12, 0.04), M(col, kind), -0.12, 0.05, 0.385), mesh(boxG(0.17, 0.12, 0.04), M(col, kind), 0.12, 0.05, 0.385));
    },
    goggles(u, col, kind, up) {
      const y = up ? 0.2 : 0.05, z = up ? 0.31 : 0.37;
      const st = mesh(GEO('gstrap', () => new THREE.TorusGeometry(0.352, 0.025, 4, 16)), M(INKC), 0, y, 0); st.rotation.x = Math.PI / 2 - (up ? 0.45 : 0.05); u.head.add(st);
      for (const x of [-0.12, 0.12]) { const l = mesh(cylG(0.075, 0.075, 0.05, 10), M(col, kind), x, y, z); l.rotation.x = Math.PI / 2 - (up ? 0.5 : 0); u.head.add(l); }
    },
    swimCap(u, col, kind) { const c = mesh(GEO('scap', () => new THREE.SphereGeometry(0.37, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.52)), M(col, kind), 0, 0.03, -0.01); c.rotation.x = -0.2; u.head.add(c); },
    headband(u, col, kind) { const b = mesh(GEO('band', () => new THREE.TorusGeometry(0.352, 0.045, 4, 14)), M(col, kind), 0, 0.14, 0); b.rotation.x = Math.PI / 2 - 0.25; u.head.add(b); },
    gloves(u, col, kind, glow) {
      for (const a of [u.armL, u.armR]) {
        a.userData.end.visible = false;
        const gl = mesh(sphG(0.18, 8, 6), M(col, kind), 0, -0.4, 0.04); gl.scale.set(1, 1, 1.15); a.add(gl);
        a.add(mesh(cylG(0.12, 0.12, 0.1, 8), M(WHITE), 0, -0.26, 0));
        if (glow) a.add(mesh(sphG(0.3, 8, 6), M(glow, 'glow'), 0, -0.4, 0.04));
      }
    },
    wraps(u) { for (const a of [u.armL, u.armR]) { a.add(mesh(cylG(0.1, 0.1, 0.12, 8), M(WHITE), 0, -0.29, 0)); a.userData.end.material = M(0xf1f3f5); } },
    headgear(u, col) {
      const r = mesh(GEO('hgear', () => new THREE.TorusGeometry(0.34, 0.07, 5, 14)), M(col), 0, 0.04, 0); r.rotation.y = Math.PI / 2; r.scale.set(1, 1.1, 0.9); u.head.add(r);
      u.head.add(mesh(boxG(0.12, 0.26, 0.5), M(col), 0, 0.3, -0.02));
    },
    waistband(u, col, kind, name, txt) {
      u.body.add(mesh(cylG(0.38, 0.38, 0.11, 10), M(col, kind), 0, 0.6, 0));
      if (name) u.body.add(mesh(GEO('wbp', () => new THREE.PlaneGeometry(0.46, 0.09)), new THREE.MeshBasicMaterial({ map: bandTexture(name, txt), transparent: true }), 0, 0.6, 0.385));
    },
    shins(u, col) { for (const l of [u.legL, u.legR]) l.add(mesh(boxG(0.13, 0.17, 0.05), M(col), 0, -0.15, 0.085)); },
    studs(u) { for (const l of [u.legL, u.legR]) for (const z of [-0.05, 0.12]) l.add(mesh(boxG(0.13, 0.03, 0.03), M(0xadb5bd), 0, -0.36, z)); },
    spikes(u) { for (const l of [u.legL, u.legR]) for (const x of [-0.05, 0.05]) l.add(mesh(GEO('spk', () => new THREE.ConeGeometry(0.018, 0.05, 4)), M(0xdee2e6), x, -0.37, 0.15)); },
    boots(u, col, kind) { for (const l of [u.legL, u.legR]) l.add(mesh(cylG(0.11, 0.1, 0.16, 8), M(col, kind), 0, -0.22, 0)); },
    belt(u, col, kind, thick) {
      u.body.add(mesh(cylG(0.405, 0.4, thick ? 0.17 : 0.09, 10), M(col, kind), 0, 0.6, 0));
    },
    buckle(u, col, kind) { u.body.add(mesh(boxG(0.16, 0.12, 0.05), M(col, kind), 0, 0.6, 0.41)); },
    towel(u) {
      const t = new THREE.Group(); t.position.set(-0.3, 1.13, 0);
      const a = mesh(boxG(0.22, 0.05, 0.62), M(WHITE)); t.add(a);
      t.add(mesh(boxG(0.22, 0.35, 0.05), M(WHITE), 0, -0.18, 0.3), mesh(boxG(0.22, 0.42, 0.05), M(WHITE), 0, -0.22, -0.3));
      t.add(mesh(boxG(0.23, 0.06, 0.055), M(0x4dabf7), 0, -0.3, 0.3));
      t.rotation.z = 0.25; u.body.add(t); return t;
    },
    robe(u, col, kind, hood) {
      const r = new THREE.Group();
      r.visible = false; // only worn while walking (see anim)
      r.add(mesh(cylG(0.43, 0.55, 0.95, 10), M(col, kind === 'gold' ? 'gold' : kind || 'double'), 0, 0.62, 0));
      for (const x of [-0.1, 0.1]) r.add(mesh(boxG(0.06, 0.9, 0.04), M(shade(col || 0xffd43b, 0.75), kind), x, 0.64, 0.45));
      if (hood) { const h = mesh(GEO('hood', () => new THREE.SphereGeometry(0.4, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.55)), M(col, kind), 0, 1.36, -0.12); h.rotation.x = -0.9; r.add(h); }
      u.body.add(r); return r;
    },
    champBelt(u) {
      const b = new THREE.Group(); b.position.set(0, 0.86, 0); b.rotation.z = 0.75;
      b.add(mesh(boxG(1.0, 0.13, 0.05), M(INKC), 0, 0, 0.36), mesh(boxG(1.0, 0.13, 0.05), M(INKC), 0, 0, -0.36));
      const plate = mesh(cylG(0.13, 0.13, 0.05, 10), M(GOLD, 'gold'), 0.05, 0, 0.39); plate.rotation.x = Math.PI / 2; b.add(plate);
      u.body.add(b);
    },
    aura(u, col) { const a = mesh(sphG(0.95, 12, 8), M(col, 'glow'), 0, 0.85, 0); a.scale.set(1, 1.15, 1); u.root.add(a); return a; },
    laurel(u) {
      const w = new THREE.Group(); w.position.y = 0.62;
      const ring = mesh(GEO('laurel', () => new THREE.TorusGeometry(0.26, 0.025, 4, 16)), M(GOLD, 'gold')); ring.rotation.x = Math.PI / 2; w.add(ring);
      for (let i = 0; i < 12; i++) { if (i === 3) continue; const a = (i / 12) * Math.PI * 2; const l = mesh(GEO('leaf', () => new THREE.SphereGeometry(0.055, 5, 3)), M(GOLD, 'gold'), Math.sin(a) * 0.27, 0.02, Math.cos(a) * 0.27); l.scale.set(0.6, 0.6, 1.4); l.rotation.y = a + 0.6; w.add(l); }
      u.head.add(w); return w;
    },
    trident(u) {
      const t = new THREE.Group(); t.position.y = 0.95;
      t.add(mesh(cylG(0.025, 0.025, 0.5, 6), M(GOLD, 'gold'), 0, -0.05, 0));
      t.add(mesh(boxG(0.32, 0.04, 0.04), M(GOLD, 'gold'), 0, 0.2, 0));
      for (const x of [-0.15, 0, 0.15]) t.add(mesh(GEO('prong', () => new THREE.ConeGeometry(0.04, 0.2, 4)), M(GOLD, 'gold'), x, 0.32 + (x ? 0 : 0.04), 0));
      u.head.add(t); return t;
    },
    bigDumbbell(u) {
      const d = new THREE.Group(); d.position.y = 1.0;
      const bar = mesh(cylG(0.035, 0.035, 0.8, 6), M(GOLD, 'gold')); bar.rotation.z = Math.PI / 2; d.add(bar);
      for (const x of [-0.36, 0.36]) { const p = mesh(cylG(0.16, 0.16, 0.12, 10), M(GOLD, 'gold'), x, 0, 0); p.rotation.z = Math.PI / 2; d.add(p); }
      u.head.add(d); return d;
    },
    goldBall(u) { const b = mesh(GEO('gball', () => new THREE.IcosahedronGeometry(0.2, 0)), M(GOLD, 'gold'), 0, 0.95, 0); u.head.add(b); return b; },
    wideShorts(u, col, kind) { const m = mesh(cylG(0.4, 0.46, 0.36, 10), M(col, kind), 0, 0.44, 0); m.scale.z = 0.9; u.body.add(m); },
    hightops(u, col, kind) { for (const l of [u.legL, u.legR]) { l.add(mesh(cylG(0.11, 0.11, 0.2, 8), M(col, kind), 0, -0.24, 0)); l.add(mesh(cylG(0.115, 0.115, 0.04, 8), M(WHITE), 0, -0.15, 0)); } },
    armSleeve(u, col, kind) { u.armR.add(mesh(cylG(0.1, 0.095, 0.3, 8), M(col, kind), 0, -0.2, 0)); },
    bball(u) { const b = bballMesh(0.13); b.position.set(0.42, 0.2, 0.25); u.root.add(b); return b; },
    goldBBall(u) { const b = bballMesh(0.19, true); b.position.set(0, 0.95, 0); u.head.add(b); return b; },
    ball(u) {
      const b = new THREE.Group();
      b.add(mesh(GEO('ico', () => new THREE.IcosahedronGeometry(0.13, 0)), M(WHITE)));
      b.add(mesh(GEO('ico2b', () => new THREE.DodecahedronGeometry(0.12, 0)), M(INKC)));
      b.position.set(0.2, 0.1, 0.4); u.root.add(b); return b;
    },
  };

  // basketball: orange ball with dark seams (gold for the legend)
  function bballMesh(r, gold) {
    const b = new THREE.Group();
    b.add(mesh(sphG(r, 10, 8), gold ? M(GOLD, 'gold') : M(0xff922b)));
    const seam = M(gold ? 0x7a4b00 : INKC);
    const t1 = mesh(GEO('bs' + r, () => new THREE.TorusGeometry(r * 1.01, r * 0.07, 3, 18)), seam); b.add(t1);
    const t2 = t1.clone(); t2.rotation.y = Math.PI / 2; b.add(t2);
    const t3 = t1.clone(); t3.rotation.x = Math.PI / 2; b.add(t3);
    return b;
  }

  function athlete(o) {
    const tier = Math.max(1, Math.min(5, o.tier | 0)), z = o.zone || 0;
    const sport = ZONE_SPORT[z] || 'track';
    // kit colour: your academy wears each sport's own colour with orange academy trim;
    // rivals (o.team) wear their academy colour with the sport colour as trim
    const sportCol = o.shirt != null ? o.shirt : 0x4dabf7;
    const team = o.team != null ? o.team : sportCol;
    const acc = o.team != null ? sportCol : ACADEMY;
    const dk = shade(team, 0.68), sk = o.skin || 0xffd6b0;
    const gold = tier >= 5, shiny = tier === 4 ? 'shiny' : null;
    const look = o.look || TOON.look(o.name, o.seed, sport);
    const spec = { skin: sk, hair: o.hair, scale: o.scale || 0.9, look };
    const add = [];   // parts applied after the base figure is built
    const fxo = { sport };
    const G = (c) => (gold ? GOLD : c), GK = (k) => (gold ? 'gold' : k);

    if (sport === 'track') {
      // singlet + short shorts + spikes, bib on the chest
      Object.assign(spec, { shirt: tier === 1 ? 0xadb5bd : G(team), shirtKind: GK(shiny), sleeve: sk, shorts: tier === 1 ? 0x495057 : G(tier >= 3 ? team : dk), shortsKind: GK(shiny),
        shoes: tier === 1 ? 0xdee2e6 : gold ? GOLD : tier === 4 ? 0x94d82d : tier === 3 ? INKC : 0xfa5252, shoesKind: gold ? 'gold' : tier === 4 ? 'hot' : null });
      if (tier >= 3) { spec.legs = G(team); spec.legsKind = GK(shiny); }      // tight one-piece racing suit
      add.push((u) => P.bib(u, o.num || 7));
      if (tier >= 2) add.push((u) => P.spikes(u));
      if (tier >= 3) add.push((u) => { P.sideStripes(u, gold ? 0xfff3bf : WHITE, gold ? 'gold' : null); P.wrist(u, gold ? GOLD : WHITE, gold ? 'gold' : null); });
      if (tier === 3 || tier === 4) add.push((u) => P.shades(u, tier === 4 ? 0xff922b : 0x339af0, 'shiny'));
      if (tier === 4) fxo.trail = 'speed';
      if (gold) { fxo.trail = z === 5 ? 'comet' : 'lightning'; add.push((u) => { fxo.halo = P.laurel(u); }); }
    } else if (sport === 'football') {
      // jersey with number and short name on the back, shorts, long striped socks, shin guards, coloured boots.
      // o.kit = a national-style kit (colours only) for rivals or the player's unlocked alternative kits
      const K = o.kit && TOON.KITS[o.kit];
      const shirt = K ? K.shirt : tier === 1 ? 0xced4da : G(team);
      const shorts = K ? K.shorts : tier === 1 ? 0x495057 : G(tier >= 3 ? dk : WHITE);
      const sock = K ? K.socks : tier === 1 ? 0xf1f3f5 : G(team);
      const trim = K ? K.trim : [tier === 1 ? 0xadb5bd : gold ? 0xfff3bf : acc];
      const boots = gold ? GOLD : [INKC, 0xfa5252, 0x339af0, 0xffd43b][tier - 1];
      const sk2 = K ? (gold ? 'shiny' : shiny) : GK(shiny);
      Object.assign(spec, { shirt, shirtKind: sk2, sleeve: sk, shorts, shortsKind: sk2, legs: sock, legsKind: K ? null : GK(shiny),
        shoes: boots, shoesKind: gold ? 'gold' : tier === 4 ? 'hot' : 'shiny' });
      add.push((u) => {
        P.shortSleeves(u, shirt, sk2);
        for (const a of [u.armL, u.armR]) trim.forEach((c, i) => a.add(mesh(cylG(0.128, 0.128, 0.022, 10), M(c), 0, -0.135 - i * 0.026, 0)));       // sleeve trim
        for (const l of [u.legL, u.legR]) trim.forEach((c, i) => l.add(mesh(cylG(0.1, 0.1, 0.024, 10), M(c), 0, -0.05 - i * 0.03, 0)));          // sock stripes
        P.shins(u, 0xf8f9fa); P.studs(u);
        if (K && K.stripes != null) u.torso.material = stripeMat(K.shirt, K.stripes);
      });
      if (tier === 1 && !K) add.push((u) => { const v = mesh(cylG(0.38, 0.42, 0.55, 16), M(0xc0eb75), 0, 0.78, 0); v.scale.z = 0.92; u.body.add(v); }); // training bib
      else add.push((u) => { P.number(u, o.num || 7, K ? K.num : null, 0.6); P.backName(u, o.name || '', o.num || 7, K ? K.num : gold ? 0x7a4b00 : WHITE); });
      if (tier >= 3) add.push((u) => u.armL.add(mesh(cylG(0.135, 0.135, 0.07, 10), M(gold ? WHITE : 0xffd43b), 0, -0.2, 0))); // captain armband
      if (tier === 4 && !K) add.push((u) => P.frontStripes(u, acc, 'hot'));
      if (tier >= 2) fxo.ball = true;
      if (gold) { fxo.trail = 'sparkle'; add.push((u) => { const b = P.goldBall(u); fxo.spin.push(b); fxo.bobBall = b; }); }
      if (tier === 4) fxo.trail = 'sparkle';
      fxo.celeb = gold ? 'flip' : look.h % 2 ? 'slide' : 'plane'; // goal celebration style
    } else if (sport === 'swim') {
      // trunks / suit, cap, goggles, barefoot, towel when walking
      Object.assign(spec, { shirt: sk, sleeve: sk, shorts: tier === 1 ? 0x343a40 : G(team), shortsKind: GK(shiny), shoes: sk });
      if (tier >= 3) Object.assign(spec, { shirt: G(tier === 3 ? dk : team), shirtKind: GK(shiny), legs: G(tier === 3 ? dk : team), legsKind: GK(shiny), shorts: G(tier === 3 ? dk : team) });
      if (tier >= 2) { spec.bald = true; add.push((u) => P.swimCap(u, G(team), GK(shiny))); }
      add.push((u) => P.goggles(u, tier === 4 ? 0x66d9e8 : tier === 3 ? 0xced4da : gold ? GOLD : 0x339af0, tier === 4 ? 'hot' : tier >= 3 ? 'shiny' : gold ? 'gold' : null, tier < 3));
      if (tier === 4 || gold) add.push((u) => { for (const y of [0.66, 0.86, 1.04]) { const w = mesh(GEO('wv' + y, () => new THREE.TorusGeometry(0.4, 0.02, 3, 16, Math.PI)), M(gold ? 0xfff3bf : 0x99e9f2, gold ? 'gold' : 'hot'), 0, y, 0); w.rotation.set(0, 0, 0); w.scale.set(1, 0.35, 0.86); u.body.add(w); } });
      add.push((u) => { fxo.towel = P.towel(u); });
      if (tier === 4) fxo.trail = 'wave';
      if (gold) { fxo.trail = 'wave'; add.push((u) => { fxo.halo = P.trident(u); }); }
    } else if (sport === 'boxing') {
      // wide-waistband shorts, tank top, gloves + wraps, boxing boots
      Object.assign(spec, { shirt: tier === 1 ? 0xf1f3f5 : G(tier >= 3 ? sk : WHITE), shirtKind: GK(null), sleeve: sk, shorts: tier === 1 ? 0x868e96 : G(team), shortsKind: tier >= 3 ? GK('shiny') : null,
        shoes: G(tier === 1 ? 0x495057 : team), shoesKind: GK(shiny) });
      add.push((u) => { P.boots(u, G(tier === 1 ? 0x495057 : team), GK(shiny)); P.waistband(u, tier === 1 ? 0xadb5bd : G(WHITE), GK(tier >= 3 ? 'shiny' : null), tier >= 3 ? o.name || 'PRO' : null, tier >= 5 ? '#7a4b00' : '#c92a2a'); });
      if (tier === 1) add.push((u) => P.wraps(u));
      else add.push((u) => P.gloves(u, gold ? GOLD : team, gold ? 'gold' : tier === 4 ? 'hot' : null, tier === 4 ? 0xff6b6b : gold ? 0xff4d4d : 0));
      if (tier === 2) add.push((u) => P.headgear(u, team));
      if (tier >= 3) add.push((u) => { fxo.robe = P.robe(u, gold ? GOLD : tier === 4 ? team : dk, gold ? 'gold' : tier === 4 ? 'shiny' : 'double', tier >= 4); });
      if (gold) { add.push((u) => { fxo.aura = P.aura(u, 0xff3b3b); P.champBelt(u); }); fxo.trail = 'lightning'; }
    } else if (sport === 'hoops') {
      // tank jersey with number, wide shorts, high-top sneakers, headband; 5★: golden jersey and sneakers, golden ball, fire when dunking
      const shorts = tier === 1 ? 0x868e96 : G(tier >= 3 ? team : dk), shoes = gold ? GOLD : tier === 4 ? 0xff6b6b : tier === 3 ? WHITE : tier === 2 ? INKC : 0xdee2e6;
      Object.assign(spec, { shirt: tier === 1 ? 0xadb5bd : G(team), shirtKind: GK(shiny), sleeve: sk, shorts, shortsKind: GK(shiny), shoes, shoesKind: gold ? 'gold' : tier === 4 ? 'hot' : null });
      add.push((u) => { P.wideShorts(u, shorts, GK(shiny)); P.hightops(u, shoes, gold ? 'gold' : tier === 4 ? 'hot' : null); });
      if (tier >= 2) add.push((u) => { P.number(u, o.num || 23); P.headband(u, tier === 2 ? WHITE : G(acc), GK(tier === 4 ? 'hot' : null)); });
      if (tier >= 3) add.push((u) => { P.wrist(u, gold ? GOLD : WHITE, gold ? 'gold' : null); P.sideStripes(u, gold ? 0xfff3bf : acc, gold ? 'gold' : null); });
      if (tier === 4) { add.push((u) => P.armSleeve(u, INKC)); fxo.trail = 'sparkle'; }
      fxo.bball = true;
      if (gold) { fxo.fire = true; fxo.trail = 'comet'; add.push((u) => { const b = P.goldBBall(u); fxo.spin.push(b); fxo.bobBall = b; fxo.aura = P.aura(u, 0xff922b); }); }
    } else { // gym
      // tank top, shorts / leggings, lifting belt, lifting shoes, chalk on the hands
      Object.assign(spec, { shirt: tier === 1 ? 0xadb5bd : G(team), shirtKind: GK(shiny), sleeve: tier === 1 ? 0xadb5bd : sk, shorts: tier === 1 ? 0x495057 : G(dk), shortsKind: GK(shiny),
        hands: 0xf8f9fa, shoes: gold ? GOLD : tier >= 3 ? INKC : 0x5c7cfa, shoesKind: gold ? 'gold' : null });
      if (tier >= 3) Object.assign(spec, { sleeve: G(dk), sleeveKind: GK(shiny), legs: G(dk), legsKind: GK(shiny) }); // compression outfit
      if (tier === 2) add.push((u) => P.belt(u, 0x8d5524, null, false));
      if (tier >= 3) add.push((u) => { P.belt(u, gold ? GOLD : INKC, gold ? 'gold' : null, true); P.wrist(u, gold ? GOLD : acc, gold ? 'gold' : null); });
      if (tier >= 4) add.push((u) => P.buckle(u, 0xffd43b, 'hot'));
      if (tier === 4) fxo.trail = 'sparkle';
      if (gold) { fxo.trail = 'lightning'; add.push((u) => { fxo.halo = P.bigDumbbell(u); fxo.spin.push(fxo.halo); fxo.aura = P.aura(u, 0xffd43b); }); }
    }

    if (tier >= 2 && tier <= 4 && sport !== 'boxing') add.push((u) => u.body.add(mesh(cylG(0.375, 0.375, 0.05, 10), M(acc, shiny), 0, 0.6, 0))); // academy trim
    const ch = figure(spec);
    const u = ch.userData, fx = u.fx;
    Object.assign(fx, fxo, { spin: fx.spin.concat(fxo.spin || []) });
    fxo.spin = fx.spin;
    for (const f of add) f(u);
    fx.spin = fxo.spin;
    if (fxo.aura) fx.aura = fxo.aura;
    if (fxo.towel) fx.towel = fxo.towel;
    if (fxo.robe) fx.robe = fxo.robe;
    if (fxo.halo) fx.halo = fxo.halo;
    if (fxo.bobBall) fx.bobBall = fxo.bobBall;
    if (fx.ball) fx.ball = P.ball(u);
    if (fx.bball) fx.bball = P.bball(u);
    fx.tier = tier;
    fx.nervous = tier === 1;
    fx.confident = tier >= 3;
    fx.victory = gold;
    return ch;
  }

  // ======================================================================
  // COACHES (hired helpers): one per sport, all built from the same base figure with swappable parts.
  // lvl 1 assistant -> 2 head coach (badge, sharper kit) -> 3 legendary coach (golden details, small aura)
  // ======================================================================
  const COACHES = {
    track: { name: 'Coach Rita', carry: 'stack', style: 'ponytail' },
    gym: { name: 'Big Brutus', carry: 'shoulder', style: 'bald', shouts: ['Light weight!', 'One more rep!', 'Feel the burn!', 'You got this!', 'No pain, no gain!', 'Squeeze it!'] },
    football: { name: 'Mister Tactico', carry: 'net', style: 'quiff' },
    swim: { name: 'Coach Marina', carry: 'stack', style: 'long' },
    boxing: { name: 'Old Mick', carry: 'stack', style: 'short' },
    stadium: { name: 'Coach Ray', carry: 'stack', style: 'buzz' },
    hoops: { name: 'Coach Dwayne', carry: 'net', style: 'buzz' },
  };
  const RANKS = ['Assistant', 'Head Coach', 'Legendary Coach'];
  const coachSport = (zone) => (zone === 5 ? 'stadium' : ZONE_SPORT[zone] || 'track');
  function clipboard() {
    const c = new THREE.Group();
    c.add(mesh(boxG(0.3, 0.38, 0.03), M(0x8d5524)), mesh(boxG(0.25, 0.3, 0.035), M(WHITE), 0, -0.02, 0));
    c.add(mesh(boxG(0.1, 0.04, 0.04), M(0xadb5bd), 0, 0.18, 0));
    for (const y of [0.06, -0.02, -0.1]) c.add(mesh(boxG(0.16, 0.015, 0.04), M(0x339af0), -0.02, y, 0));
    return c;
  }
  function coach(o) {
    const sport = coachSport(o.zone), lvl = Math.max(1, Math.min(3, o.lvl || 1)), gold = lvl >= 3;
    const info = COACHES[sport], nm = info.name.split(' ').pop();
    const look = Object.assign(TOON.look(nm, 'coach'), { style: info.style, build: sport === 'gym' ? 1.1 : 1 });
    const sk = o.skin || 0xf1c27d, spec = { skin: sk, hair: o.hair || 0x3b2a1a, scale: 0.95 + (lvl - 1) * 0.04, whistle: gold ? 'gold' : false, look };
    const add = [], fxo = {};
    const shoes = gold ? GOLD : null, shoesKind = gold ? 'gold' : null;
    switch (sport) {
      case 'track': case 'stadium': { // tracksuit, cap, whistle, stopwatch around the neck
        const c = sport === 'track' ? 0xe03131 : 0xf59f00;
        Object.assign(spec, { shirt: c, sleeve: c, legs: c, shorts: c, shoes: shoes || WHITE, shoesKind, cap: lvl >= 2 ? INKC : 0x495057, capBrim: gold ? GOLD : null, whistle: spec.whistle || true });
        add.push((u) => {
          P.sideStripes(u, WHITE); for (const l of [u.legL, u.legR]) l.add(mesh(boxG(0.04, 0.26, 0.19), M(WHITE), 0, -0.13, 0));
          const sw = new THREE.Group(); sw.position.set(0.15, 0.9, 0.35);
          sw.add(mesh(cylG(0.08, 0.08, 0.04, 12), M(gold ? GOLD : 0xdee2e6, gold ? 'gold' : 'shiny')));
          sw.children[0].rotation.x = Math.PI / 2; sw.add(mesh(boxG(0.03, 0.05, 0.03), M(INKC), 0, 0.09, 0));
          u.body.add(sw);
        });
        break;
      }
      case 'football': // smart dark coat over a sweater, tactics clipboard
        Object.assign(spec, { shirt: 0x495057, sleeve: 0x343a40, legs: 0x212529, shorts: 0x212529, shoes: shoes || INKC, shoesKind });
        add.push((u) => {
          const coat = mesh(cylG(0.43, 0.5, 0.78, 10), M(0x212529, 'double'), 0, 0.62, -0.02); u.body.add(coat);
          for (const x of [-0.11, 0.11]) u.body.add(mesh(boxG(0.07, 0.75, 0.04), M(0x343a40), x, 0.65, 0.42));
          if (lvl >= 2) { const sc = mesh(GEO('scarf', () => new THREE.TorusGeometry(0.26, 0.07, 5, 12)), M(gold ? GOLD : 0x37b24d, gold ? 'gold' : null), 0, 1.1, 0); sc.rotation.x = Math.PI / 2; u.body.add(sc); }
          const cb = clipboard(); cb.position.set(0, -0.44, 0.12); cb.rotation.x = -0.6; u.armL.add(cb);
        });
        break;
      case 'swim': // polo, shorts, towel over the shoulder, sunglasses, whistle
        Object.assign(spec, { shirt: 0x15aabf, sleeve: sk, shorts: WHITE, shoes: shoes || 0xf1f3f5, shoesKind, hair: o.hair || 0xe0b04a, whistle: spec.whistle || true });
        add.push((u) => { P.shortSleeves(u, 0x15aabf); P.shades(u, gold ? GOLD : INKC, gold ? 'gold' : 'shiny'); const c = mesh(GEO('collar', () => new THREE.TorusGeometry(0.22, 0.05, 4, 12)), M(WHITE), 0, 1.13, 0.02); c.rotation.x = Math.PI / 2; u.body.add(c); P.towel(u); });
        break;
      case 'boxing': // flat cap, sweatshirt, focus pads, towel around the neck
        Object.assign(spec, { shirt: 0x868e96, sleeve: 0x868e96, legs: 0x495057, shorts: 0x495057, shoes: shoes || INKC, shoesKind, cap: 0x5c4a3d, flatCap: true, hair: 0xced4da, hands: INKC });
        add.push((u) => {
          u.head.add(mesh(boxG(0.24, 0.06, 0.05), M(0xdee2e6), 0, -0.07, 0.37)); // moustache
          const tw = mesh(GEO('ntowel', () => new THREE.TorusGeometry(0.25, 0.08, 5, 12)), M(WHITE), 0, 1.12, 0); tw.rotation.x = Math.PI / 2 - 0.2; u.body.add(tw);
          for (const a of [u.armL, u.armR]) { const pad = mesh(cylG(0.17, 0.15, 0.08, 10), M(INKC), 0, -0.44, 0.07); pad.rotation.x = Math.PI / 2; a.add(pad); a.add(mesh(cylG(0.09, 0.09, 0.02, 10), M(gold ? GOLD : 0xfa5252, gold ? 'gold' : null), 0, -0.44, 0.12)); a.children[a.children.length - 1].rotation.x = Math.PI / 2; }
        });
        break;
      case 'gym': // huge muscles, tank top, lifting belt, wrist wraps
        Object.assign(spec, { shirt: INKC, sleeve: sk, shorts: 0x343a40, shoes: shoes || INKC, shoesKind, bald: true });
        add.push((u) => {
          u.torso.scale.set(1.32, 1.12, 1.0);
          for (const a of [u.armL, u.armR]) { a.scale.set(1.75, 1.05, 1.75); a.position.x *= 1.22; }
          for (const l of [u.legL, u.legR]) l.scale.set(1.3, 1, 1.3);
          u.head.add(mesh(boxG(0.3, 0.12, 0.12), M(0x3b2a1a), 0, -0.25, 0.25)); // beard
          P.belt(u, gold ? GOLD : 0x8d5524, gold ? 'gold' : null, true); P.wrist(u, WHITE);
        });
        break;
      case 'hoops': // polo, whistle, clipboard and a basketball
        Object.assign(spec, { shirt: 0x7048e8, sleeve: sk, legs: 0x343a40, shorts: 0x343a40, shoes: shoes || WHITE, shoesKind, whistle: spec.whistle || true });
        add.push((u) => {
          P.shortSleeves(u, 0x7048e8);
          const c = mesh(GEO('collar', () => new THREE.TorusGeometry(0.22, 0.05, 4, 12)), M(WHITE), 0, 1.13, 0.02); c.rotation.x = Math.PI / 2; u.body.add(c);
          const cb = clipboard(); cb.position.set(-0.47, 0.5, 0.14); cb.rotation.set(0, 0.4, 0.2); u.body.add(cb);
          fxo.cball = bballMesh(0.14, gold); u.root.add(fxo.cball);
        });
        break;
    }
    if (lvl >= 2) add.push((u) => { // head coach badge
      const b = mesh(cylG(0.08, 0.08, 0.03, 10), M(gold ? GOLD : 0xffd43b, gold ? 'gold' : 'shiny'), -0.2, 0.98, 0.35); b.rotation.x = Math.PI / 2; u.body.add(b);
    });
    if (gold) add.push((u) => { fxo.aura = P.aura(u, 0xffd43b); fxo.auraK = 0.78; P.wrist(u, GOLD, 'gold'); });
    const ch = figure(spec);
    const u = ch.userData;
    for (const fn of add) fn(u);
    Object.assign(u.fx, fxo, { coach: sport, lvl });
    return ch;
  }

  // ======================================================================
  // THE PLAYER'S COACH — the most detailed character: fitted tracksuit jacket in academy colours with the
  // academy logo, whistle on a cord, cap or headband. o.look = { sex, skin, hair (style), hairCol, hat }
  // tier: 1 simple tracksuit -> 2 premium jacket -> 3 golden coach jacket (grows with the academy)
  // ======================================================================
  let logoTex = null;
  function academyLogo() {
    if (logoTex) return logoTex;
    const c = document.createElement('canvas'); c.width = c.height = 384;
    const g = c.getContext('2d'); g.scale(4, 4);
    g.beginPath(); g.arc(48, 48, 44, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill();
    g.beginPath(); g.arc(48, 48, 36, 0, Math.PI * 2); g.fillStyle = '#ff922b'; g.fill();
    if (AT.Icon && AT.Icon.draw) AT.Icon.draw(g, 'star', 48, 49, 52, '#fff');
    logoTex = crisp(new THREE.CanvasTexture(c));
    return logoTex;
  }
  const PLAYER_SKINS = [0xffd6b0, 0xf1c27d, 0xe0ac69, 0xc68642, 0x8d5524];
  const PLAYER_HAIRS = [0x3b2a1a, 0x111111, 0xe0b04a, 0x8b4513, 0xd9480f, 0xf783ac, 0xadb5bd];
  function player(o) {
    const L = o.look || {}, tier = Math.max(1, Math.min(3, o.tier || 1)), gold = tier === 3, prem = tier === 2;
    const look = { sex: L.sex || 'm', style: L.hair || 'short', face: { eye: L.sex === 'f' ? 2 : 0, brow: L.sex === 'f' ? 0 : 1, lash: L.sex === 'f' }, build: 1 };
    const jacket = gold ? GOLD : prem ? 0xff922b : 0xffa94d, pants = gold ? 0x343a40 : prem ? 0x1d2b5a : 0x364fc7;
    const jk = gold ? 'gold' : prem ? 'shiny' : null, trimC = gold ? WHITE : prem ? 0x1d2b5a : WHITE;
    const capC = gold ? GOLD : prem ? 0x1d2b5a : 0xe03131;
    const spec = { skin: PLAYER_SKINS[L.skin | 0] || PLAYER_SKINS[0], hair: PLAYER_HAIRS[L.hairCol | 0] || PLAYER_HAIRS[0], look, scale: 1.08,
      shirt: jacket, shirtKind: jk, sleeve: jacket, sleeveKind: jk, shorts: pants, legs: pants, shoes: gold ? GOLD : WHITE, shoesKind: gold ? 'gold' : null,
      whistle: gold ? 'gold' : true, cap: L.hat === 'cap' ? capC : null, capKind: gold ? 'gold' : null, capBrim: L.hat === 'cap' ? (gold ? WHITE : 0xff922b) : null };
    const ch = figure(spec), u = ch.userData, fx = u.fx;
    // zip, collar, stripes down the sleeves and trouser legs
    u.body.add(mesh(boxG(0.03, 0.5, 0.02), M(gold ? 0xfff3bf : 0xdee2e6, 'shiny'), 0, 0.8, 0.342));
    const col = mesh(GEO('pcollar', () => new THREE.TorusGeometry(0.22, 0.055, 6, 16)), M(prem ? 0x1d2b5a : jacket, jk), 0, 1.15, 0.02); col.rotation.x = Math.PI / 2; u.body.add(col);
    for (const a of [u.armL, u.armR]) a.add(mesh(boxG(0.04, 0.3, 0.19), M(trimC, gold ? null : jk), a === u.armL ? -0.08 : 0.08, -0.17, 0));
    for (const l of [u.legL, u.legR]) l.add(mesh(boxG(0.04, 0.26, 0.19), M(gold ? GOLD : WHITE, gold ? 'gold' : null), l === u.legL ? -0.08 : 0.08, -0.13, 0));
    if (prem || gold) { // premium: contrast shoulder panels and cuffs
      for (const x of [-0.3, 0.3]) { const sh = mesh(sphG(0.16, 12, 8), M(trimC, jk), x, 1.08, 0); sh.scale.set(1.1, 0.6, 1.2); u.body.add(sh); }
      for (const a of [u.armL, u.armR]) a.add(mesh(cylG(0.1, 0.1, 0.06, 12), M(trimC, jk), 0, -0.3, 0));
    }
    // academy logo on the chest
    const logo = mesh(GEO('plogo', () => new THREE.PlaneGeometry(0.15, 0.15)), new THREE.MeshBasicMaterial({ map: academyLogo(), transparent: true }), -0.17, 0.95, 0.3);
    logo.rotation.set(-0.2, -0.36, 0); u.body.add(logo);
    // whistle on a cord
    const cord = mesh(GEO('pcord', () => new THREE.TorusGeometry(0.2, 0.012, 4, 20)), M(0x343a40), 0, 1.1, 0.16); cord.rotation.x = Math.PI / 2 - 0.62; cord.scale.set(1, 1.25, 1); u.body.add(cord);
    if (L.hat === 'band') P.headband(u, gold ? GOLD : 0xff922b, gold ? 'gold' : null);
    if (gold) { fx.aura = P.aura(u, 0xffd43b); fx.auraK = 0.7; }
    // props for idle moves and emotes
    const cb = clipboard(); cb.position.set(0, -0.4, 0.14); cb.rotation.x = -0.9; cb.visible = false; u.armL.add(cb); fx.clip = cb;
    const th = mesh(boxG(0.06, 0.13, 0.06), M(spec.skin), 0, -0.4, 0.06); th.visible = false; u.armR.add(th); fx.thumb = th;
    fx.player = true; fx.tier = tier;
    return ch;
  }
  // one-off reactions: 'cheer' (jumps), 'facepalm', 'thumbs' (thumbs up), 'sad', 'shock'
  function emote(ch, kind, dur = 1.6) { const fx = ch.userData.fx; fx.emote = kind; fx.emoteT = dur; fx.emoteP = 0; }

  // ======================================================================
  // ANIMATION
  // ======================================================================
  const ease = (o, k, v, f) => { o[k] += (v - o[k]) * f; };
  function anim(ch, dt, mode, kind) {
    const u = ch.userData, fx = u.fx, sport = fx.sport;
    u.ph += dt * (mode === 'walk' ? 12 : mode === 'train' ? 13 : mode === 'cheer' ? 9 : 3);
    const s = Math.sin(u.ph), f = Math.min(1, dt * 10);
    u.head.rotation.y *= 0.9; u.head.rotation.x *= 0.85;
    u.body.position.x *= 0.8;
    if (mode !== 'train') { u.body.position.z *= 0.8; if (Math.abs(u.body.rotation.x) > 0.6) u.body.rotation.x *= 0.8; }
    if (mode !== 'idle') { u.body.rotation.x *= 0.8; u.body.rotation.y *= 0.8; }
    u.body.rotation.z *= 0.8;
    if (mode !== 'cheer' && fx.celebP) { fx.celebP = 0; u.body.position.z = 0; u.body.rotation.x = 0; }
    let sq = 0; // squash (-) and stretch (+) of the whole character
    if (mode === 'walk') {
      // bouncy chibi steps: up on each stride, a little squash when the foot lands
      const big = fx.player ? 1.25 : 1;
      u.legL.rotation.x = s * 0.8; u.legR.rotation.x = -s * 0.8;
      u.armL.rotation.x = -s * 0.7 * big; u.armR.rotation.x = s * 0.7 * big; u.armL.rotation.z = -0.08; u.armR.rotation.z = 0.08;
      u.body.position.y = Math.abs(s) * 0.12 * big;
      sq = Math.abs(s) < 0.3 ? -0.06 : 0.03;
      u.body.rotation.z = Math.sin(u.ph) * 0.05;
      if (sport === 'boxing') { u.armL.rotation.x = -1.3 - s * 0.15; u.armR.rotation.x = -1.3 + s * 0.15; } // guard up while walking
    } else if (mode === 'cheer') {
      if (sport === 'football') sq = celebrate(u, fx, dt) || 0;
      else if (sport === 'gym') { // flex
        u.armL.rotation.x = u.armR.rotation.x = 0; u.armL.rotation.z = -2.3; u.armR.rotation.z = 2.3; u.body.position.y = Math.abs(s) * 0.08;
      } else {
        u.armL.rotation.x = u.armR.rotation.x = -2.8; u.armL.rotation.z = -0.3; u.armR.rotation.z = 0.3;
        u.body.position.y = Math.abs(s) * 0.3;
      }
    } else if (mode === 'train') {
      u.armL.rotation.z = u.armR.rotation.z = 0; u.armL.position.z *= 0.6; u.armR.position.z *= 0.6;
      (TRAIN[kind] || TRAIN[KIND_ALIAS[kind]] || TRAIN.sprint)(u, s, fx);
    } else if (fx.player) {
      idlePlayer(u, fx, dt, f);
    } else if (fx.coach) {
      idleCoach(u, fx, dt, f);
    } else if (sport) {
      idleSport(u, fx, sport, dt, f);
    } else {
      idleBasic(u, fx, s);
    }
    // sport props
    if (fx.towel) fx.towel.visible = mode !== 'train';
    if (fx.robe) fx.robe.visible = mode === 'walk';
    if (fx.ball) {
      const b = fx.ball; b.visible = mode !== 'train';
      if (mode === 'walk') { b.position.set(0.05, 0.13, 0.45 + Math.abs(Math.sin(u.ph * 0.5)) * 0.2); b.rotation.x += dt * 9; }
      else if (mode === 'idle' && fx.juggle) { // keepy-uppy off the right foot
        const j = (u.ph * 1.6) % (Math.PI); b.position.set(0.16, 0.18 + Math.sin(j) * 0.75, 0.3); b.rotation.x += dt * 5;
      } else if (mode !== 'train') { b.position.set(0.25, 0.13, 0.4); }
    }
    if (fx.bball) {
      const b = fx.bball;
      b.visible = mode !== 'train' || kind === 'bdribble';
      if (mode === 'walk' || (mode === 'train' && kind === 'bdribble') || (mode === 'idle' && fx.dribble)) {
        const r = mode === 'train' ? 1.2 : 0.5;
        b.position.set(0.42 + u.body.position.x, 0.15 + Math.abs(Math.sin(u.ph * r)) * 0.55, 0.22); b.rotation.x += dt * 6;
      } else if (mode === 'idle' && fx.shootPose) b.position.set(0.05, 2.05 + u.body.position.y, 0.15);
      else if (mode !== 'train') b.position.set(0.42, 0.62, 0.18);
    }
    if (fx.cball) { // Coach Dwayne: spins the ball on a finger while waiting, carries it under the arm when walking
      if (mode === 'idle' && fx.spinning) { fx.cball.position.set(0.47, 1.66, 0.04); fx.cball.rotation.y += dt * 14; }
      else fx.cball.position.set(-0.47, 0.78, 0.1);
    }
    if (fx.cape) fx.cape.rotation.x = 0.12 + (mode === 'walk' ? 0.65 : 0) + Math.sin(u.ph * 1.7) * 0.08;
    if (fx.aura) { const k = (fx.auraK || 1) * (1 + Math.sin(u.ph * 1.3) * 0.07); fx.aura.scale.set(k, k * 1.15, k); }
    if (fx.halo) { fx.halo.position.y = (fx.sport === 'gym' ? 1.0 : fx.sport === 'swim' ? 0.95 : 0.62) + Math.sin(u.ph * 1.1) * 0.05; if (fx.sport === 'track') fx.halo.rotation.y += dt * 0.8; }
    for (const sp of fx.spin) sp.rotation.y += dt * 4;
    if (fx.bobBall) fx.bobBall.position.y = 0.95 + Math.sin(u.ph * 1.1) * 0.06;
    if (fx.orbit) { const a = u.ph * 0.9; fx.orbit.position.set(Math.cos(a) * 0.62, 1.55, Math.sin(a) * 0.62); fx.orbit.rotation.y += dt * 5; }
    if (fx.emoteT > 0) sq = emoteAnim(u, fx, dt, mode);
    else { if (fx.thumb) fx.thumb.visible = false; }
    // squash & stretch around the feet (eased)
    u.sq = (u.sq || 0) + (sq - (u.sq || 0)) * Math.min(1, dt * 18);
    const b = u.sc || 1; u.root.scale.set(b * (1 - u.sq * 0.5), b * (1 + u.sq), b * (1 - u.sq * 0.5));
    // expressions + blinking
    if (u.face) {
      let e = fx.emoteT > 0 ? fx.emoteFace : mode === 'train' ? (STRAIN.has(kind) && Math.sin(u.ph * 0.5) > 0.2 ? 'strain' : 'focused')
        : mode === 'cheer' ? 'proud' : mode === 'walk' ? 'smile' : fx.mood || 'smile';
      u.blinkT = (u.blinkT == null ? Math.random() * 3 : u.blinkT) - dt;
      if (u.blinkT < 0) { if (u.blinkT < -0.13) u.blinkT = 1.8 + Math.random() * 3.2; else if (e !== 'proud' && e !== 'strain' && e !== 'happy2') e = 'blink'; }
      setExpr(u, e);
    }
  }
  const STRAIN = new Set(['bench', 'squat', 'row', 'bag', 'spar', 'dunk', 'fly']);
  // football goal celebrations: aeroplane arms, knee slide, backflip (5 stars)
  function celebrate(u, fx, dt) {
    fx.celebP = (fx.celebP || 0) + dt;
    const p = fx.celebP, A = u.armL.rotation, B = u.armR.rotation;
    switch (fx.celeb) {
      case 'flip': { // crouch, jump, full backward flip around the hips, land
        const k = (p % 1.5) / 1.5;
        const a = k > 0.18 && k < 0.82 ? -((k - 0.18) / 0.64) * Math.PI * 2 : 0;
        const air = k > 0.15 && k < 0.85 ? Math.sin(((k - 0.15) / 0.7) * Math.PI) : 0;
        const h = 0.8;
        u.body.rotation.x = a; u.body.position.y = air * 0.95 + h - h * Math.cos(a) - (k < 0.15 ? 0.12 : 0); u.body.position.z = -h * Math.sin(a);
        u.legL.rotation.x = u.legR.rotation.x = air > 0.2 ? -1.2 : 0; A.x = B.x = -2.6; A.z = -0.4; B.z = 0.4;
        return k < 0.15 || (k > 0.85 && k < 0.93) ? -0.14 : air > 0.3 ? 0.07 : 0;
      }
      case 'slide': { // run in and slide on the knees, arms up, leaning back
        const k = (p % 2.2) / 2.2;
        u.body.position.z = k < 0.35 ? k * 1.4 : 0.49 + Math.min(0.6, (k - 0.35) * 1.6) * (1 - (k - 0.35));
        if (k < 0.35) { const r = Math.sin(p * 13); u.legL.rotation.x = r; u.legR.rotation.x = -r; A.x = -r * 0.8; B.x = r * 0.8; A.z = B.z = 0; u.body.position.y = Math.abs(r) * 0.12; u.body.rotation.x = 0.15; }
        else { u.body.position.y = -0.27; u.legL.rotation.x = u.legR.rotation.x = 1.45; u.body.rotation.x = -0.35; A.x = B.x = -2.8; A.z = -0.35 - Math.sin(p * 9) * 0.1; B.z = 0.35 + Math.sin(p * 9) * 0.1; }
        break;
      }
      default: // aeroplane: arms wide, banking circles
        A.x = B.x = 0; A.z = -1.5; B.z = 1.5;
        u.body.rotation.z = Math.sin(p * 2.4) * 0.3; u.body.rotation.y = Math.sin(p * 1.2) * 0.8;
        u.body.position.y = Math.abs(Math.sin(p * 9)) * 0.1; u.legL.rotation.x = Math.sin(p * 9) * 0.6; u.legR.rotation.x = -u.legL.rotation.x;
    }
  }
  // the player's coach waiting around: looks around, checks the clipboard, blows the whistle, stretches (~12 s loop)
  function idlePlayer(u, fx, dt, f) {
    const t = ((u.ph / 3) % 12 + 12) % 12;
    const L = u.legL.rotation, R = u.legR.rotation, AL = u.armL.rotation, AR = u.armR.rotation;
    let alx = 0, arx = 0, alz = -0.1, arz = 0.1, by = Math.sin(u.ph * 0.7) * 0.012, brz = 0, hx = 0, hy = 0;
    fx.clip.visible = t >= 3 && t < 6.2;
    fx.mood = 'smile';
    if (t < 3) { hy = Math.sin(t * 2.1) * 0.65; if (t > 1 && t < 2) fx.mood = 'happy'; }                                       // look around
    else if (t < 6.2) { alx = -1.15; alz = 0.25; arx = -0.85 + Math.sin(u.ph * 6) * 0.08; arz = -0.25; hx = 0.32; fx.mood = 'focused'; } // check the clipboard
    else if (t < 7.4) { arx = -2.55; arz = -0.55; hx = -0.1; fx.mood = 'shocked'; by += Math.sin(u.ph * 9) * 0.01; }          // blow the whistle
    else if (t < 10.2) { alx = arx = -2.9; brz = Math.sin((t - 7.4) * 2.2) * 0.22; alz = -0.15; arz = 0.15; fx.mood = 'proud'; } // stretch
    if (t >= 6.2 && t < 6.25 && !fx.blew) { fx.blew = true; if (AT.onWhistle) AT.onWhistle(); } else if (t < 6.2) fx.blew = false;
    L.x += (0 - L.x) * f; R.x += (0 - R.x) * f;
    AL.x += (alx - AL.x) * f; AR.x += (arx - AR.x) * f; AL.z += (alz - AL.z) * f; AR.z += (arz - AR.z) * f;
    u.body.position.y += (by - u.body.position.y) * f; u.body.rotation.z += (brz - u.body.rotation.z) * f; u.body.rotation.x *= 0.85; u.body.rotation.y *= 0.85;
    u.head.rotation.x += (hx - u.head.rotation.x) * f; u.head.rotation.y += (hy - u.head.rotation.y) * f;
  }
  // emotes override the upper body (and the legs when standing still); returns squash/stretch
  function emoteAnim(u, fx, dt, mode) {
    fx.emoteT -= dt; fx.emoteP += dt;
    const p = fx.emoteP, AL = u.armL.rotation, AR = u.armR.rotation, still = mode !== 'walk';
    if (fx.clip) fx.clip.visible = false;
    if (fx.thumb) fx.thumb.visible = fx.emote === 'thumbs';
    switch (fx.emote) {
      case 'cheer': { // jump for joy, arms up
        const j = Math.abs(Math.sin(p * 6.5));
        AL.x = AR.x = -2.85; AL.z = -0.35 - Math.sin(p * 13) * 0.15; AR.z = 0.35 + Math.sin(p * 13) * 0.15;
        fx.emoteFace = 'happy';
        if (still) { u.body.position.y = j * 0.5; u.legL.rotation.x = u.legR.rotation.x = j > 0.3 ? -0.35 : 0; return j < 0.15 ? -0.12 : j > 0.85 ? 0.08 : 0.03; }
        return 0;
      }
      case 'facepalm': { // hand on the face, head down, slow shake
        AR.x = -2.15; AR.z = 0.8; AL.x = -0.2; AL.z = -0.1;
        u.head.rotation.x = 0.38; u.head.rotation.y = Math.sin(p * 5) * 0.18; fx.emoteFace = 'sad';
        if (still) { u.body.rotation.x = 0.12; u.body.position.y = -0.02; }
        return -0.03;
      }
      case 'thumbs': { // thumbs up with a little hop
        AR.x = -1.5; AR.z = 0.05; AL.x = -0.2; AL.z = -0.15; fx.emoteFace = 'proud';
        if (still) { const hop = p < 0.35 ? Math.sin((p / 0.35) * Math.PI) : 0; u.body.position.y = hop * 0.25; return hop > 0.1 ? 0.06 : 0; }
        return 0;
      }
      case 'sad': AL.x = AR.x = -0.05; u.head.rotation.x = 0.35; fx.emoteFace = 'sad'; return -0.03;
      default: fx.emoteFace = 'shocked'; AL.x = AR.x = -2.2; AL.z = -0.6; AR.z = 0.6; return 0.04;
    }
  }
  // TRAINING POSES, one per discipline (kind = the station's discipline id). Slow drills loop on cyc().
  const TAU = Math.PI * 2;
  const cyc = (u, r) => ((((u.ph * r) / TAU) % 1) + 1) % 1;
  const RATE = { hurdles: 0.5, longjump: 0.24, shoot: 0.24, header: 0.3, dive: 0.2, ft: 0.24, dunk: 0.22, layup: 0.24, rope: 0.9 };
  const KIND_ALIAS = { track: 'sprint', stadium: 'relay', gym: 'bench', football: 'shoot', pool: 'free', boxing: 'bag', hoops: 'ft' };
  const run = (u, s, k = 1) => {
    u.legL.rotation.x = s * 1.15 * k; u.legR.rotation.x = -s * 1.15 * k; u.armL.rotation.x = -s * 1.1 * k; u.armR.rotation.x = s * 1.1 * k;
    u.body.position.y = Math.abs(s) * 0.13 * k; u.body.rotation.x = 0.18; u.body.position.z = 0;
  };
  const swimBody = (u) => { u.body.rotation.x = 1.45; u.body.position.y = 0.12; u.body.position.z = -0.55; }; // face down, head forward
  const legs = (u, l, r = l) => { u.legL.rotation.x = l; u.legR.rotation.x = r; };
  const arms = (u, l, r = l) => { u.armL.rotation.x = l; u.armR.rotation.x = r; };
  const TRAIN = {
    // track
    sprint: (u, s) => run(u, s),
    relay: (u, s) => { run(u, s); u.armR.rotation.x = 1.0 + s * 0.15; },               // reaching back for the baton
    hurdles: (u, s) => {
      const air = Math.max(0, Math.sin(cyc(u, RATE.hurdles) * TAU));
      if (air > 0.05) { legs(u, -1.45, 0.9); arms(u, 0.6, -1.6); u.body.position.y = air * 0.55; u.body.rotation.x = 0.45; } else run(u, s);
    },
    longjump: (u, s) => {
      const f = cyc(u, RATE.longjump);
      if (f < 0.5) run(u, s);
      else if (f < 0.82) { const k = (f - 0.5) / 0.32; u.body.position.y = Math.sin(k * Math.PI) * 0.75; legs(u, -1.3 * k); arms(u, -2.6 + k * 1.2); u.body.rotation.x = 0.3 - k * 0.5; }
      else { u.body.position.y = -0.18; legs(u, -1.2); arms(u, -1.2); u.body.rotation.x = 0.4; }
    },
    // gym
    bench: (u, s) => { // lying on the bench, pressing the bar up
      u.body.rotation.x = -1.5; u.body.position.y = 0.62; u.body.position.z = 0; legs(u, 1.5); arms(u, -1.57);
      u.armL.position.z = u.armR.position.z = 0.05 + Math.max(0, s) * 0.22;
    },
    squat: (u) => { const k = (1 - Math.cos(u.ph * 0.5)) / 2; u.body.position.y = -0.32 * k; legs(u, -0.9 * k); u.body.rotation.x = 0.3 * k; arms(u, -2.7); u.armL.rotation.z = -0.55; u.armR.rotation.z = 0.55; },
    tread: (u, s) => { run(u, s, 0.8); u.body.position.y += 0.14; },
    row: (u) => { const k = (1 + Math.sin(u.ph * 0.45)) / 2; u.body.position.y = -0.42; legs(u, -1.25 - k * 0.3); u.body.rotation.x = -0.35 + k * 0.7; arms(u, -1.5 + k * 0.9); },
    // football
    dribble: (u, s) => { const w = Math.sin(u.ph * 0.45); u.body.position.x = w * 0.35; u.body.rotation.y = w * 0.3; legs(u, s * 0.5, -s * 0.5); u.armL.rotation.z = -0.5; u.armR.rotation.z = 0.5; u.body.position.y = Math.abs(s) * 0.05; },
    pass: (u) => { const k = Math.sin(u.ph * 0.5); legs(u, 0, k > 0 ? -k * 1.1 : k * -0.4); u.armL.rotation.z = -0.5; u.armR.rotation.z = 0.4; },
    shoot: (u) => {
      const f = cyc(u, RATE.shoot);
      u.legR.rotation.x = f < 0.3 ? (f / 0.3) * 0.9 : f < 0.42 ? 0.9 - ((f - 0.3) / 0.12) * 2.4 : f < 0.7 ? -1.5 : -1.5 + ((f - 0.7) / 0.3) * 1.5; u.legL.rotation.x = 0;
      u.armL.rotation.z = -0.7; u.armR.rotation.z = 0.5; u.body.rotation.x = f > 0.3 && f < 0.6 ? -0.15 : 0.05;
    },
    header: (u) => { const air = Math.max(0, Math.sin(cyc(u, RATE.header) * TAU)); u.body.position.y = air * 0.35; u.head.rotation.x = air > 0.7 ? 0.5 : -0.2 * air; u.armL.rotation.z = -0.6; u.armR.rotation.z = 0.6; legs(u, air * 0.3); },
    // swimming
    free: (u) => { swimBody(u); arms(u, -(u.ph % TAU), -((u.ph + Math.PI) % TAU)); legs(u, Math.sin(u.ph * 2) * 0.35, -Math.sin(u.ph * 2) * 0.35); },
    fly: (u) => { swimBody(u); u.body.position.y += Math.sin(u.ph) * 0.08; u.body.rotation.x += Math.sin(u.ph) * 0.15; arms(u, -(u.ph % TAU)); legs(u, Math.sin(u.ph + 1) * 0.4); },
    under: (u) => { swimBody(u); u.body.position.y = -0.02; u.body.rotation.x = 1.45 + Math.sin(u.ph * 0.7) * 0.08; arms(u, -3.0); legs(u, Math.sin(u.ph * 0.7) * 0.45); },
    dive: (u) => { // bounce on the board, jump, dive in, climb back out
      const f = cyc(u, RATE.dive); u.body.position.y = 0.45; u.body.position.z = 0;
      if (f < 0.45) { u.body.position.y += Math.abs(Math.sin(f * 3 * Math.PI)) * 0.18; arms(u, -0.3); legs(u, 0); u.body.rotation.x = 0; }
      else if (f < 0.8) { const k = (f - 0.45) / 0.35; u.body.position.y += Math.sin(k * Math.PI) * 0.8 - k * 1.3; u.body.position.z = k * 1.0; u.body.rotation.x = k * 2.6; arms(u, -2.9); legs(u, 0); }
      else { u.body.position.y = -1.6; u.body.rotation.x = 0; }
    },
    // boxing
    bag: (u, s) => { arms(u, -1.5); u.armL.position.z = Math.max(0, s) * 0.25; u.armR.position.z = Math.max(0, -s) * 0.25; u.body.position.y = Math.abs(s) * 0.04; },
    speedbag: (u) => { const w = u.ph * 2.2; arms(u, -2.1 + Math.sin(w) * 0.25, -2.1 - Math.sin(w) * 0.25); u.armL.position.z = Math.max(0, Math.sin(w)) * 0.12; u.armR.position.z = Math.max(0, -Math.sin(w)) * 0.12; },
    rope: (u) => { const w = u.ph * RATE.rope; u.body.position.y = Math.abs(Math.sin(w)) * 0.2; legs(u, -0.15); arms(u, -0.4); u.armL.rotation.z = -0.55 + Math.sin(w * 2) * 0.1; u.armR.rotation.z = 0.55 - Math.sin(w * 2) * 0.1; },
    spar: (u, s) => { TRAIN.bag(u, s); u.body.rotation.y = Math.sin(u.ph * 0.35) * 0.35; u.body.position.x = Math.sin(u.ph * 0.35) * 0.15; },
    // basketball
    ft: (u) => {
      const f = cyc(u, RATE.ft);
      if (f < 0.25) { u.body.position.y = -0.12 * Math.sin((f / 0.25) * Math.PI); arms(u, -1.2 - f * 2); }
      else if (f < 0.4) { const k = (f - 0.25) / 0.15; arms(u, -1.7 - k * 1.2); u.body.position.y = k * 0.12; }
      else { arms(u, Math.min(-1.0, -2.9 + Math.max(0, f - 0.7) * 6)); u.body.position.y = 0; }
      legs(u, 0);
    },
    bdribble: (u, s) => { TRAIN.dribble(u, s); u.armR.rotation.x = -0.6 + Math.sin(u.ph * 1.2) * 0.35; },
    dunk: (u, s) => {
      const f = cyc(u, RATE.dunk);
      if (f < 0.45) run(u, s, 0.7);
      else if (f < 0.8) { const k = (f - 0.45) / 0.35; u.body.position.y = Math.sin(k * Math.PI) * 1.1; u.body.position.z = k * 0.7; arms(u, -2.0, -3.0); legs(u, -0.8, 0.4); u.body.rotation.x = 0; }
      else { u.body.position.z = 0.7 * (1 - (f - 0.8) / 0.2); u.body.position.y = 0; arms(u, -0.4); legs(u, 0); }
    },
    layup: (u, s) => {
      const f = cyc(u, RATE.layup);
      if (f < 0.4) run(u, s, 0.6);
      else if (f < 0.75) { const k = (f - 0.4) / 0.35; u.body.position.y = Math.sin(k * Math.PI) * 0.7; u.body.position.z = k * 0.4; arms(u, -0.6, -2.9); legs(u, -1.1, 0.3); u.body.rotation.x = 0; }
      else { u.body.position.y = 0; u.body.position.z = 0.4 * (1 - (f - 0.75) / 0.25); arms(u, -0.3); legs(u, 0); }
    },
  };
  // coaches waiting around: each has a sport-specific habit
  function idleCoach(u, fx, dt, f) {
    const t = ((u.ph / 3) % 6 + 6) % 6, w = u.ph * 3;
    const L = u.legL.rotation, R = u.legR.rotation, AL = u.armL.rotation, AR = u.armR.rotation;
    let alx = 0, arx = 0, alz = -0.12, arz = 0.12, by = 0, bry = 0;
    fx.spinning = false;
    u.armL.position.z *= 0.8; u.armR.position.z *= 0.8;
    if (fx.clapT > 0) { // Coach Marina claps when a swimmer finishes
      fx.clapT -= dt; alx = arx = -1.35; const c = Math.abs(Math.sin(u.ph * 6)); alz = 0.35 * c - 0.05; arz = -0.35 * c + 0.05; by = Math.abs(Math.sin(u.ph * 3)) * 0.04;
    } else switch (fx.coach) {
      case 'track': case 'stadium': // clicks the stopwatch
        if (t > 3 && t < 5) { arx = -1.25; arz = -0.45; if (Math.sin(w * 2) > 0.95) by = 0.02; }
        u.head.rotation.y = Math.sin(u.ph * 0.4) * 0.4;
        break;
      case 'football': // points and gives instructions, checks the tactics board
        if (t < 2) { arx = -1.55; arz = 0.05 + Math.sin(w * 0.5) * 0.15; bry = -0.2; }
        else if (t < 4) { alx = -1.15; u.head.rotation.x = 0.25; }
        else { alx = -0.4; arx = -0.2; }
        break;
      case 'swim': // arms crossed, whistle now and then
        alx = arx = -1.0; alz = 0.55; arz = -0.55;
        if (t > 4.3 && t < 4.9) { arx = -2.3; arz = 0.3; }
        break;
      case 'boxing': // shadow boxes while waiting
        alx = arx = -1.45; alz = 0.15; arz = -0.15; by = Math.abs(Math.sin(u.ph * 2.6)) * 0.05; bry = Math.sin(u.ph * 0.9) * 0.2;
        u.armL.position.z = Math.max(0, Math.sin(w * 1.4)) * 0.26; u.armR.position.z = Math.max(0, -Math.sin(w * 1.4)) * 0.26;
        break;
      case 'gym': // flexes (the speech bubbles come from the game)
        if (t > 2 && t < 3.8) { alz = -2.3; arz = 2.3; } else { alz = -0.45; arz = 0.45; }
        break;
      case 'hoops': // spins the ball on a finger
        if (t < 4.2) { arx = -2.95; arz = 0.1; fx.spinning = true; } else { alx = -1.0; }
        break;
    }
    const k = f;
    L.x += (0 - L.x) * k; R.x += (0 - R.x) * k;
    AL.x += (alx - AL.x) * k; AR.x += (arx - AR.x) * k; AL.z += (alz - AL.z) * k; AR.z += (arz - AR.z) * k;
    u.body.position.y += (by - u.body.position.y) * k; u.body.rotation.y += (bry - u.body.rotation.y) * k; u.body.rotation.x *= 0.85;
  }
  // coach / staff idle
  function idleBasic(u, fx, s) {
    for (const k of ['legL', 'legR']) u[k].rotation.x *= 0.8;
    u.armL.position.z *= 0.8; u.armR.position.z *= 0.8;
    u.armL.rotation.x *= 0.8; u.armR.rotation.x *= 0.8; u.armL.rotation.z *= 0.8; u.armR.rotation.z *= 0.8;
    u.body.position.y = Math.max(0, s) * 0.03;
  }
  // athletes idle with their sport's warm-up routine (a ~6 s loop); 1★ look around nervously, 5★ celebrate now and then
  function idleSport(u, fx, sport, dt, f) {
    const t = ((u.ph / 3) % 6 + 6) % 6, w = u.ph * 3; // seconds into the loop, fast wave
    const L = u.legL.rotation, R = u.legR.rotation, AL = u.armL.rotation, AR = u.armR.rotation, Bp = u.body.position, Br = u.body.rotation;
    let ly = 0, lx = 0, rx = 0, alx = 0, arx = 0, alz = 0, arz = 0, by = 0, bx = 0, bry = 0;
    u.armL.position.z *= 0.8; u.armR.position.z *= 0.8;
    fx.juggle = false; fx.dribble = fx.shootPose = false;
    if (fx.victory && t > 5) { alx = arx = -2.8; alz = -0.35; arz = 0.35; ly = Math.abs(Math.sin(t * Math.PI * 2)) * 0.2; }
    else if (sport === 'track') {
      if (t < 2) { lx = -0.7; rx = 0.25; alx = -1.0; arx = -1.0; bx = 0.45; }                       // hamstring stretch
      else if (t < 3.2) { lx = Math.max(0, Math.sin(w * 1.2)) * -1.2; rx = Math.max(0, -Math.sin(w * 1.2)) * -1.2; alx = Math.sin(w * 1.2) * 0.8; arx = -alx; ly = Math.abs(Math.sin(w * 1.2)) * 0.08; } // high knees
      else { lx = -1.25; rx = 0.75; alx = -1.45; arx = -1.45; alz = -0.15; arz = 0.15; ly = -0.24; bx = 0.55; } // crouched start
    } else if (sport === 'football') {
      if (fx.ball && t < 4) { fx.juggle = true; rx = -Math.max(0, Math.sin(u.ph * 1.6 * 2)) * 0.9; alz = -0.45; arz = 0.45; }
      else { lx = Math.sin(w) * 0.3; rx = -lx; alz = -0.3; arz = 0.3; ly = Math.abs(Math.sin(w)) * 0.05; }
    } else if (sport === 'swim') {
      if (t < 2.6) { alx = -(u.ph * 2.2) % 6.283; arx = -(u.ph * 2.2 + 3.14) % 6.283; }              // arm circles
      else if (t < 4) { u.body.position.x = Math.sin(u.ph * 14) * 0.05; u.head.rotation.y = Math.sin(u.ph * 12) * 0.5; alz = -0.3; arz = 0.3; } // shake off water
      else { alx = arx = -2.7; bx = 0.5; lx = rx = -0.35; ly = -0.12; }                             // diving start
    } else if (sport === 'boxing') {
      ly = Math.abs(Math.sin(u.ph * 2.6)) * 0.07;                                                     // bounce on the feet
      alx = arx = -1.45; alz = 0.15; arz = -0.15; bry = Math.sin(u.ph * 0.9) * 0.2;                 // guard pose
      if (t > 2 && t < 4.5) { u.armL.position.z = Math.max(0, Math.sin(w * 1.4)) * 0.28; u.armR.position.z = Math.max(0, -Math.sin(w * 1.4)) * 0.28; } // shadow boxing
    } else if (sport === 'hoops') {
      fx.dribble = t < 2.6; fx.shootPose = t >= 2.6 && t < 4;
      if (fx.dribble) { arx = -0.6 + Math.sin(u.ph * 1.0) * 0.35; alz = -0.3; ly = Math.abs(Math.sin(w * 0.5)) * 0.03; }
      else if (fx.shootPose) { alx = arx = -2.75; ly = Math.max(0, Math.sin((t - 2.6) * 4.5)) * 0.18; }
      else { alz = -1.4; arz = 1.4; }                                                                    // arm stretch
    } else { // gym
      if (t < 2.4) { alx = arx = -0.95; alz = 0.45 + Math.sin(w * 2) * 0.08; arz = -0.45 - Math.sin(w * 2) * 0.08; } // chalking hands
      else if (t < 4) { alz = -2.3; arz = 2.3; alx = arx = 0; ly = 0.02; }                          // double-biceps flex
      else { alz = -0.4; arz = 0.4; ly = Math.max(0, Math.sin(u.ph)) * 0.03; }
    }
    if (fx.nervous && !(sport === 'swim' && t >= 2.6 && t < 4)) u.head.rotation.y = Math.sin(u.ph * 0.8) * 0.5;
    ease(L, 'x', lx, f); ease(R, 'x', rx, f); ease(AL, 'x', alx, f); ease(AR, 'x', arx, f);
    if (sport === 'swim' && t < 2.6 && !(fx.victory && t > 5)) { AL.x = alx; AR.x = arx; } // full circles: no easing across the wrap
    ease(AL, 'z', alz, f); ease(AR, 'z', arz, f); ease(Bp, 'y', ly, f); ease(Br, 'x', bx, f); ease(Br, 'y', bry, f);
  }

  // ======================================================================
  // THUMBNAILS (rendered once with the main renderer, cached as data URLs). Anti-aliased: 4x MSAA where WebGL2
  // allows it, and always rendered at 2x the size and scaled down (512x640 -> 256x320).
  // ======================================================================
  const thumbs = {};
  let tScene = null, tCam = null, tRT = null, tBuf = null, tBig = null, tCanvas = null;
  const TW = 256, TH = 320, SS = 2, BW = TW * SS, BH = TH * SS;
  function thumb(renderer, key, make) {
    if (thumbs[key]) return thumbs[key];
    if (!tScene) {
      tScene = new THREE.Scene();
      tScene.add(new THREE.HemisphereLight(0xffffff, 0xa5b8cc, 0.9));
      const d = new THREE.DirectionalLight(0xffffff, 0.55); d.position.set(-2, 4, 5); tScene.add(d);
      tCam = new THREE.PerspectiveCamera(30, TW / TH, 0.1, 50);
      tCam.position.set(0, 1.6, 5.9); tCam.lookAt(0, 1.25, 0);
      const msaa = renderer.capabilities.isWebGL2 && THREE.WebGLMultisampleRenderTarget;
      tRT = msaa ? new THREE.WebGLMultisampleRenderTarget(BW, BH, { samples: 4 }) : new THREE.WebGLRenderTarget(BW, BH);
      if (msaa) tRT.samples = 4;
      tBuf = new Uint8Array(BW * BH * 4);
      tBig = document.createElement('canvas'); tBig.width = BW; tBig.height = BH;
      tCanvas = document.createElement('canvas'); tCanvas.width = TW; tCanvas.height = TH;
    }
    const ch = make();
    ch.rotation.y = 0.35;
    tScene.add(ch);
    const prevColor = renderer.getClearColor(new THREE.Color()), prevAlpha = renderer.getClearAlpha();
    renderer.setRenderTarget(tRT);
    renderer.setClearColor(0x000000, 0);
    renderer.clear();
    renderer.render(tScene, tCam);
    renderer.readRenderTargetPixels(tRT, 0, 0, BW, BH, tBuf);
    renderer.setRenderTarget(null);
    renderer.setClearColor(prevColor, prevAlpha);
    tScene.remove(ch);
    const gb = tBig.getContext('2d');
    const img = gb.createImageData(BW, BH);
    for (let y = 0; y < BH; y++) img.data.set(tBuf.subarray((BH - 1 - y) * BW * 4, (BH - y) * BW * 4), y * BW * 4);
    gb.putImageData(img, 0, 0);
    const g = tCanvas.getContext('2d');
    g.clearRect(0, 0, TW, TH);
    g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
    g.drawImage(tBig, 0, 0, TW, TH);
    return (thumbs[key] = tCanvas.toDataURL('image/png'));
  }

  AT.Skins = { TIERS, LEGENDS, COACHES, RANKS, coachSport, coach, player, emote, bballMesh, figure, athlete, anim, thumb, blob, M, shadowMat, cyc, RATE, setExpr, PLAYER_SKINS, PLAYER_HAIRS, KITS: TOON.KITS };
})();
