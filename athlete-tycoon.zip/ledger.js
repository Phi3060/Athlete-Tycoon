/*
 * ledger.js — a dependency-free port of merchant.js (https://github.com/Flaque/merchant.js)
 * MIT License, Copyright (c) 2017 Evan Conrad — see vendor/merchant-LICENSE.txt
 *
 * merchant.js models an idle-game economy as "ledgers": maps of CURRENCY -> number.
 * The original uses Immutable.js Maps and CommonJS; YouTube Playables wants a small,
 * self-contained bundle with no build step, so this port keeps the same API and
 * semantics but uses plain frozen-style objects (functions never mutate their inputs).
 *
 *   wallet = { COINS: 120, UP_SPEED: 2, TROPHY_GOLD: 1 }
 *   item   = { type: 'UP_SPEED', cost: state => ({ COINS: -50 }), effect: state => ({ SPEED_PCT: 10 }) }
 */
(function (root) {
  'use strict';

  const sum = (...ledgers) => {
    const out = {};
    for (const l of ledgers) {
      if (!l) continue;
      for (const k in l) out[k] = (out[k] || 0) + l[k];
    }
    return out;
  };

  const scale = (ledger, s) => {
    const out = {};
    for (const k in ledger) out[k] = ledger[k] * s;
    return out;
  };

  const inTheBlack = (ledger) => Object.keys(ledger).every((k) => ledger[k] >= 0);
  const inTheRed = (ledger) => Object.keys(ledger).every((k) => ledger[k] < 0);
  const currencies = (...ledgers) => Object.keys(sum(...ledgers));
  const totalOf = (currency, ...ledgers) => sum(...ledgers)[currency] || 0;

  const cost = (item, state = {}) => (item && item.cost ? item.cost(state) : {});
  const allCosts = (items, state = {}) => {
    const out = {};
    for (const k in items) out[k] = cost(items[k], state);
    return out;
  };

  /** Returns the wallet after paying the item's cost (may go negative — check with inTheBlack). */
  const buy = (item, wallet, state = {}) => (item && item.cost ? sum(item.cost(state), wallet) : wallet);

  /** Adds `amount` of the item's type to the wallet. */
  const add = (item, wallet, amount = 1) => sum(wallet, { [item.type]: amount });

  /** Sums every item's effect, scaled by how many of that item the wallet owns. */
  const effects = (items, wallet, state = {}) =>
    sum(...items.filter((i) => i.effect).map((i) => scale(i.effect(state), wallet[i.type] || 0)));

  root.Ledger = { sum, scale, inTheBlack, inTheRed, currencies, totalOf, cost, allCosts, buy, add, effects };
})(window);
