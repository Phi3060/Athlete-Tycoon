/* Athlete Tycoon — world, core loop, progression, skins wiring, save. Tournament mode lives in tourney.js. */
'use strict';
(function () {
  const AT = (window.AT = window.AT || {});
  const SK = AT.Skins;
  const YT = window.ytgame || null;
  const inYT = !!(YT && YT.IN_PLAYABLES_ENV);
  const $ = (id) => document.getElementById(id);
  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const pick = (arr) => arr[(Math.random() * arr.length) | 0];
  const fmt = (n) => {
    n = Math.floor(n);
    if (n < 1000) return '' + n;
    if (n < 1e6) return (n / 1000).toFixed(n < 1e4 ? 1 : 0).replace(/\.0$/, '') + 'K';
    return (n / 1e6).toFixed(n < 1e7 ? 2 : 1).replace(/\.?0+$/, '') + 'M';
  };
  Object.assign(AT, { rand, clamp, pick, fmt, $ });

  // ======================================================================
  // DATA
  // ======================================================================
  const ITEMS = {
    water: { icon: 'drop', name: 'Water' },
    dumbbell: { icon: 'dumbbell', name: 'Dumbbell' },
    football: { icon: 'football', name: 'Football' },
    kickboard: { icon: 'board', name: 'Kickboard' },
    gloves: { icon: 'glove', name: 'Gloves' },
    shake: { icon: 'shake', name: 'Shake' },
    baton: { icon: 'baton', name: 'Baton' },
    basketball: { icon: 'basketball', name: 'Basketball' },
    towel: { icon: 'towel', name: 'Towel' },
    cone: { icon: 'cone', name: 'Cones' },
    plate: { icon: 'plate', name: 'Weight plate' },
    swimcap: { icon: 'swimcap', name: 'Swim cap' },
    pads: { icon: 'mitt', name: 'Focus pads' },
    wraps: { icon: 'wraps', name: 'Hand wraps' },
  };
  const ZONES = [
    { id: 'track', name: 'Track', icon: 'shoe', item: 'water', fee: 8, unit: 30, cost: 0, need: 0, floor: 0xe8613f, shirt: 0xff6b9a, event: 'sprint' },
    { id: 'gym', name: 'Gym', icon: 'dumbbell', item: 'dumbbell', fee: 20, unit: 90, cost: 180, need: 0, floor: 0x8e94a3, shirt: 0x5c7cfa, event: 'lift' },
    { id: 'football', name: 'Football', icon: 'football', item: 'football', fee: 48, unit: 280, cost: 800, need: 1, floor: 0x8ce99a, shirt: 0x37b24d, event: 'penalty' },
    { id: 'pool', name: 'Pool', icon: 'wave', item: 'kickboard', fee: 115, unit: 850, cost: 2600, need: 2, floor: 0xa5d8ff, shirt: 0x15aabf, event: 'swim' },
    { id: 'boxing', name: 'Boxing', icon: 'glove', item: 'gloves', fee: 270, unit: 2400, cost: 8000, need: 3, floor: 0xffc9c9, shirt: 0xe03131, event: 'boxing' },
    { id: 'stadium', name: 'Stadium', icon: 'stadium', item: 'baton', fee: 620, unit: 6500, cost: 24000, need: 5, floor: 0x96f2d7, shirt: 0xf59f00, event: 'relay' },
    { id: 'hoops', name: 'Basketball', icon: 'basketball', item: 'basketball', fee: 420, unit: 4200, cost: 14000, need: 4, floor: 0xe0a96d, shirt: 0x7048e8, event: 'hoops' },
  ];
  // the order zones open in (and are laid out in, front to back): Basketball comes after Boxing, before the Stadium.
  // Zone indexes stay fixed so older saves keep working.
  const ZONE_ORDER = [0, 1, 2, 3, 4, 6, 5];
  const slotOf = (i) => ZONE_ORDER.indexOf(i);
  const nextLocked = () => ZONE_ORDER.find((i) => !S.zones[i].unlocked);
  const prevZone = (i) => ZONE_ORDER[Math.max(0, slotOf(i) - 1)];
  // TRAINING DISCIPLINES: each zone's 4 station slots are 4 different disciplines, bought one by one.
  // item = what the athlete needs brought, w = how training spreads over Speed / Power / Stamina, slow = longer sessions
  const D = (id, name, item, w, o = {}) => Object.assign({ id, name, item, w }, o);
  const TRACK_DISC = [
    D('sprint', 'Sprint lanes', 'water', [1, 0, 0]), D('hurdles', 'Hurdles', 'towel', [0.5, 0, 0.5]),
    D('longjump', 'Long jump pit', 'water', [0, 1, 0]), D('relay', 'Relay baton zone', 'baton', [0, 0, 1]),
  ];
  const DISC = {
    track: TRACK_DISC,
    gym: [D('bench', 'Bench press', 'dumbbell', [0, 1, 0]), D('squat', 'Squat rack', 'plate', [0, 1, 0]),
      D('tread', 'Treadmill', 'shake', [0, 0, 1]), D('row', 'Rowing machine', 'water', [0.5, 0, 0.5])],
    football: [D('dribble', 'Dribbling cones', 'cone', [1, 0, 0]), D('pass', 'Passing wall', 'football', [0, 0, 1]),
      D('shoot', 'Shooting goal', 'football', [0, 1, 0]), D('header', 'Header pendulum', 'water', [0, 1, 0])],
    pool: [D('free', 'Freestyle lane', 'kickboard', [1, 0, 0]), D('fly', 'Butterfly lane', 'swimcap', [0, 1, 0]),
      D('dive', 'Diving board', 'towel', [0, 1, 0]), D('under', 'Underwater lane', 'kickboard', [0, 0, 1])],
    boxing: [D('bag', 'Heavy bag', 'gloves', [0, 1, 0]), D('speedbag', 'Speed bag', 'wraps', [1, 0, 0]),
      D('rope', 'Skipping rope', 'water', [0, 0, 1]), D('spar', 'Sparring ring', 'pads', [1, 1, 1], { slow: 1.7, all: true })],
    stadium: [TRACK_DISC[3], TRACK_DISC[0], TRACK_DISC[1], TRACK_DISC[2]],
    hoops: [D('ft', 'Free throw line', 'basketball', [0, 1, 0]), D('bdribble', 'Dribbling course', 'basketball', [1, 0, 0]),
      D('dunk', 'Dunk ramp', 'towel', [0, 1, 0]), D('layup', 'Layup drill', 'water', [0, 0, 1])],
  };
  const discOf = (zone, k) => DISC[ZONES[zone].id][k];
  // one league ladder per sport; the Stadium relay runs on the Track ladder
  const SPORTS = [
    { id: 'track', name: 'Track', icon: 'shoe', zones: [0, 5], color: '#ff6b9a' },
    { id: 'gym', name: 'Gym', icon: 'dumbbell', zones: [1], color: '#5c7cfa' },
    { id: 'football', name: 'Football', icon: 'football', zones: [2], color: '#37b24d' },
    { id: 'swim', name: 'Swimming', icon: 'wave', zones: [3], color: '#15aabf' },
    { id: 'boxing', name: 'Boxing', icon: 'glove', zones: [4], color: '#e03131' },
    { id: 'hoops', name: 'Basketball', icon: 'basketball', zones: [6], color: '#7048e8' },
  ];
  const sportOfZone = (z) => SPORTS.findIndex((s) => s.zones.includes(z));
  // events: tournaments per season · target: points to promote · keep: points needed to avoid relegation
  const LEAGUES = [
    { name: 'Local League', short: 'Local', icon: 'medalBronze', events: 3, target: 8, keep: 0, coin: 1, decor: 'banner' },
    { name: 'Regional League', short: 'Regional', icon: 'medalSilver', events: 4, target: 11, keep: 3, coin: 1.6, decor: 'banner' },
    { name: 'National League', short: 'National', icon: 'medalGold', events: 4, target: 12, keep: 4, coin: 2.5, decor: 'statue' },
    { name: 'European Championship', short: 'European', icon: 'euro', events: 5, target: 15, keep: 5, coin: 4, decor: 'statue' },
    { name: 'World Championship', short: 'World', icon: 'globe', events: 5, target: 17, keep: 6, coin: 6, decor: 'trophyCase' },
    { name: 'Diamond League', short: 'Diamond', icon: 'diamond', events: 5, target: 19, keep: 7, coin: 9, decor: 'trophyCase' },
  ];
  const PLACE_PTS = [5, 3, 1, 0];  // league points for 1st / 2nd / 3rd / 4th
  const PLAYER = { name: 'Your Academy', logo: 'star', color: '#ffa94d' };
  const RIVALS = [
    { name: 'Thunder Hawks', logo: 'bolt', color: '#4d96ff', skill: 0.15 },
    { name: 'Coral Sharks', logo: 'fin', color: '#ff6b9a', skill: 0.35 },
    { name: 'Lime Lions', logo: 'paw', color: '#51cf66', skill: -0.1 },
  ];
  const NAMES = ['Mia', 'Leo', 'Zoe', 'Kai', 'Ava', 'Max', 'Ivy', 'Sam', 'Nia', 'Eli', 'Ruby', 'Finn', 'Luna', 'Theo', 'Aria', 'Jay', 'Noa', 'Ben', 'Lia', 'Rex', 'Tia', 'Ollie', 'Mae', 'Duke', 'Remy', 'Cleo', 'Ty', 'Suki', 'Omar', 'Pia'];
  const STAR_XP = [0, 3, 8, 15, 25];         // training sessions needed for 1..5 stars
  const TIER_FEE = [1, 1.6, 2.5, 4, 6.5];     // membership fee multiplier by star level
  const TIER_POWER = [10, 22, 36, 52, 72];    // tournament strength by star level
  const STATION_MULT = [0, 1, 2.4, 5.5];
  const STATION_OFF = [[-1.0, -2.0], [2.4, -2.0], [-1.0, 2.0], [2.4, 2.0]];
  const RACK_X = -4.5;
  const ZONE_GAP = 11;
  const TOURNEY_INTERVAL = 150;
  const MAX_ATHLETES = 12;                    // walk-ins on screen at once (perf cap); extra ones wait outside
  const LINE_MAX = 6;                         // visible waiting line in the lobby
  const zoneZ = (i) => -slotOf(i) * ZONE_GAP;
  // lobby layout
  const DESK = { x: -3.6, z: 8.6 };
  const STAFF = new THREE.Vector3(-4.9, 0.12, 8.6);
  const RECEP_POS = new THREE.Vector3(-5.5, 0.12, 9.7);
  const EXIT = new THREE.Vector3(0, 0.12, 17.8);
  const HALL = { x: 4.0, z: 12.6 };
  const queueSlot = (k, v) => v.set(-2.6 + (k % 9) * 0.9, 0.12, 8.6 + Math.floor(k / 9) * 1.0);
  const lineSlot = (k, v) => v.set(-1.5 - k * 0.85, 0.12, 14.6);

  const UPGRADES = [
    { type: 'UP_SPEED', icon: 'speed', name: 'Speed', base: 40, mult: 1.75, max: 10, effect: () => ({ SPEED_PCT: 9 }) },
    { type: 'UP_CAP', icon: 'boxes', name: 'Carry', base: 30, mult: 1.7, max: 10, effect: () => ({ CAP: 2 }) },
    { type: 'UP_TRAIN', icon: 'stopwatch', name: 'Training', base: 60, mult: 1.8, max: 10, effect: () => ({ TRAIN_PCT: 12 }) },
    { type: 'UP_PRICE', icon: 'tag', name: 'Price', base: 80, mult: 1.85, max: 10, effect: () => ({ INCOME_PCT: 15 }) },
    { type: 'UP_AWAY', icon: 'hourglass', name: 'Away Time', base: 300, mult: 2.4, max: 6, effect: () => ({ AWAY_H: 1 }) },
  ];
  UPGRADES.forEach((u) => (u.cost = (st) => ({ COINS: -Math.round(u.base * Math.pow(u.mult, st.wallet[u.type] || 0)) })));
  const BONUSES = [
    { type: 'TROPHY_GOLD', effect: () => ({ INCOME_PCT: 5 }) },
    { type: 'TROPHY_SILVER', effect: () => ({ INCOME_PCT: 3 }) },
    { type: 'TROPHY_BRONZE', effect: () => ({ INCOME_PCT: 1 }) },
    { type: 'GOLD_GEAR', effect: () => ({ TRAIN_PCT: 6 }) },
    { type: 'DECOR', effect: () => ({ INCOME_PCT: 2 }) },          // one per league title (academy decoration)
    { type: 'MEDAL_EURO', effect: () => ({ INCOME_PCT: 4 }) },
    { type: 'MEDAL_WORLD', effect: () => ({ INCOME_PCT: 6 }) },
    { type: 'TROPHY_DIAMOND', effect: () => ({ INCOME_PCT: 5 }) },
  ];
  const ALL_ITEMS = UPGRADES.concat(BONUSES);

  // ---------- team, scouting, daily tasks ----------
  // Hidden test mode (tap the coin counter 10 times). Set to false before publishing.
  const TEST_MODE = true;
  const RARITY = [
    { name: 'Common', col: '#adb5bd', grow: 1, stat: [10, 24], cap: 60, stars: 1 },
    { name: 'Rare', col: '#4dabf7', grow: 1.3, stat: [20, 34], cap: 75, stars: 1 },
    { name: 'Epic', col: '#be4bdb', grow: 1.6, stat: [30, 46], cap: 90, stars: 2 },
    { name: 'Legendary', col: '#fab005', grow: 2, stat: [44, 60], cap: 100, stars: 2 },
  ];
  // scouting trips: real-time minutes, coin cost, Scouting Office level needed, rarity odds (%)
  const TRIPS = [
    { name: 'Local', icon: 'pin', min: 2, cost: 100, lvl: 1, odds: [75, 20, 4.5, 0.5] },
    { name: 'Regional', icon: 'map', min: 5, cost: 700, lvl: 1, odds: [55, 32, 11, 2] },
    { name: 'National', icon: 'flag', min: 15, cost: 3500, lvl: 2, odds: [35, 38, 22, 5] },
    { name: 'International', icon: 'globe', min: 30, cost: 14000, lvl: 3, odds: [18, 36, 34, 12] },
  ];
  const OFFICE_COST = [400, 2500, 9000, 30000, 90000]; // build, then upgrades to Lv 2..5
  const OFFICE_MAX = 5;
  // speed/power/stamina weight per sport = the stats its minigame uses (training raises these, tournament power uses them)
  const STAT_W = [[0.55, 0.1, 0.35], [0.1, 0.6, 0.3], [0.4, 0.45, 0.15], [0.4, 0.1, 0.5], [0.35, 0.35, 0.3], [0.35, 0.4, 0.25]];
  const SPORT_EVENT = ['sprint races', 'lifts', 'shootouts', 'swim races', 'bouts', 'shooting contests'];
  Object.assign(AT, { ITEMS, ZONES, ZONE_ORDER, DISC, LEAGUES, SPORTS, PLACE_PTS, sportOfZone, PLAYER, RIVALS, NAMES, UPGRADES, BONUSES, TOURNEY_INTERVAL, STAR_XP });

  // ======================================================================
  // STATE
  // ======================================================================
  let S = null;
  const newLeague = (lvl) => ({ lvl, pts: 0, played: 0, rp: [0, 0, 0], next: 60, won: [], best: lvl, titles: 0 });
  const newState = () => ({
    v: 1,
    wallet: { COINS: 0 },
    zones: ZONES.map((z, i) => ({ unlocked: i === 0, stations: i === 0 ? 1 : 0, assistants: 0 })),
    recep: false,
    roster: [],
    lg: SPORTS.map(() => newLeague(0)),   // per-sport league progress
    trophyLog: [],                         // [{ t: 0 gold | 1 silver | 2 bronze, l: league }] for the trophy hall
    chalWins: 0,
    played: 0,
    nextId: 1,
    paid: {},
    skins: {},      // "zone-tier": 1 for every skin ever reached
    legends: {},    // zone -> member id that became that zone's legend
    newSkins: 0,
    saved: Date.now(),
    sound: true,
    music: true,
    office: 0,            // Scouting Office level (0 = not built)
    scout: null,          // { trip, ends (ms), cards: [talents] | null }
    scoutFree: 0,         // free scouting trips (daily chest, login streak)
    stat: { trips: 0, signed: 0, bestRar: 0 },
    daily: null,          // { day, tasks: [{ k, sp, goal, prog, reward, claimed }], chest }
    login: { day: '', streak: 0 },
    goal: 0,              // index into GOALS
    dayShift: 0,          // test mode "skip day"
    offlinePend: 0,
    recov: 0,             // Recovery Room level (0 = not built)
    spa: 0,
  });
  AT.S = () => S;
  const rosterRT = {}; // runtime only: { present, cool }
  const rt = (m) => rosterRT[m.id] || (rosterRT[m.id] = { present: false, cool: 0 });

  const starsOf = (m) => STAR_XP.filter((x) => m.xp >= x).length;
  const displayName = (m) => m.title || m.name;
  const powerOf = (stars) => {
    const s = clamp(stars, 1, 6), i = Math.min(3, Math.floor(s) - 1), f = s - 1 - i;
    return TIER_POWER[i] + (TIER_POWER[i + 1] - TIER_POWER[i]) * f;
  };
  // the highest league reached in any sport
  const leagueIndex = () => Math.max(...S.lg.map((l) => l.lvl));
  // league titles won across all sports (opens new zones)
  const titleCount = () => S.lg.reduce((a, l) => a + l.won.length, 0);
  const teamList = () => S.roster.filter((m) => m.team);
  const teamSlots = () => 4 + Math.max(1, S.office); // 5 slots, +1 per Scouting Office level
  const sportHasAthletes = (s) => S.roster.some((m) => m.team && SPORTS[s].zones.includes(m.zone) && S.zones[m.zone].unlocked);
  // weighted stat score (0-100) for the athlete's own sport, and tournament power: stars + stats
  const statScore = (m) => { if (!m.st) return 0; const w = STAT_W[Math.max(0, sportOfZone(m.zone))]; return m.st[0] * w[0] + m.st[1] * w[1] + m.st[2] * w[2]; };
  const athPower = (m) => powerOf(starsOf(m)) * 0.85 + statScore(m) * 0.16;
  const sportOpen = (s) => SPORTS[s].zones.some((z) => S.zones[z].unlocked);
  const trophyCount = () => (S.wallet.TROPHY_GOLD || 0) + (S.wallet.TROPHY_SILVER || 0) + (S.wallet.TROPHY_BRONZE || 0) + (S.wallet.MEDAL_EURO || 0) + (S.wallet.MEDAL_WORLD || 0) + (S.wallet.TROPHY_DIAMOND || 0);
  function stats() {
    const e = Ledger.effects(ALL_ITEMS, S.wallet, S);
    return {
      speed: 4.6 * (1 + (e.SPEED_PCT || 0) / 100),
      cap: 4 + (e.CAP || 0),
      train: 1 + (e.TRAIN_PCT || 0) / 100,
      income: 1 + (e.INCOME_PCT || 0) / 100,
      incomePct: e.INCOME_PCT || 0,
      trainPct: e.TRAIN_PCT || 0,
      awayH: 2 + (e.AWAY_H || 0),
    };
  }
  let ST = null;
  const refreshStats = () => (ST = stats());
  const feeFor = (m) => ZONES[m.zone].fee * TIER_FEE[starsOf(m) - 1] * ST.income;
  const addCoins = (n) => (S.wallet = Ledger.sum(S.wallet, { COINS: n }));
  const spendCoins = (n) => (S.wallet = Ledger.sum(S.wallet, { COINS: -n }));
  const addItem = (type, n = 1) => { S.wallet = Ledger.add({ type }, S.wallet, n); refreshStats(); };
  const unlockSkin = (zone, tier) => {
    const k = `${zone}-${tier}`;
    if (S.skins[k]) return false;
    S.skins[k] = 1; S.newSkins = (S.newSkins || 0) + 1;
    return true;
  };
  Object.assign(AT, { topZoneOf: () => S.zones.reduce((a, z, i) => (z.unlocked && ZONES[i].fee > ZONES[a].fee ? i : a), 0), RARITY, teamList, teamSlots, statScore, athPower, SPORT_EVENT });
  Object.assign(AT, { starsOf, leagueIndex, titleCount, sportHasAthletes, sportOpen, trophyCount, addCoins, addItem, stats: () => ST, feeFor, displayName, powerOf, TIER_FEE });

  // ======================================================================
  // SOUND: audio.js synthesizes music + effects; settings live in the save
  // ======================================================================
  const Snd = AT.Audio;
  AT.sfx = (n, g) => Snd.play(n, g);

  // ======================================================================
  // THREE SETUP
  // ======================================================================
  const gameEl = $('game');
  const canvas = $('c3d');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  // render at the screen's full pixel density (up to 3x); adaptive quality may lower it only as the very last step,
  // and never below 2x on 2x+ screens (1x screens stay at 1x)
  const dpr = () => Math.min(window.devicePixelRatio || 1, 3);
  const pxFloor = () => (dpr() >= 2 ? 2 : dpr());
  let pixelRatio = dpr();
  renderer.setPixelRatio(pixelRatio);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const MAX_ANISO = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  AT.renderer = renderer;
  const scene = new THREE.Scene();
  const SKY = 0xcfeefd;
  scene.background = new THREE.Color(SKY);
  scene.fog = new THREE.Fog(SKY, 40, 78);
  const camera = new THREE.PerspectiveCamera(40, 9 / 16, 0.5, 150);
  const CAM_DIR = new THREE.Vector3(0, 0.83, 0.56).normalize();
  const camLook = new THREE.Vector3(0, 0, 10);
  let camDist = 30;
  // zoom = visible width in world units at the look point: 10 by default, pinch between 8 (close) and 13 (overview)
  const ZOOM_MIN = 8, ZOOM_MAX = 13, ZOOM_DEF = 10, ZOOM_VER = 2; // ZOOM_VER: bump to reset saved zooms once
  let camZoom = ZOOM_DEF;
  const camExt = { half: 4.25, ahead: 12, behind: 7 }; // the view's footprint on the ground around the look point
  const camLead = new THREE.Vector2(); // look-ahead in the walking direction
  let camPan = null; // short pan to a target (tutorial step, new zone), then back to the coach
  scene.add(new THREE.HemisphereLight(0xffffff, 0xa5b8cc, 0.82));
  const sun = new THREE.DirectionalLight(0xfff4e0, 0.72);
  const SUN_OFF = new THREE.Vector3(-7, 16, 8);
  sun.position.copy(SUN_OFF);
  // soft real-time shadows; the light's shadow box is fitted tightly to the visible area around the coach (fitShadow)
  sun.castShadow = true;
  Object.assign(sun.shadow.camera, { left: -13, right: 13, top: 17, bottom: -17, near: 1, far: 60 });
  const SUN_ROT = new THREE.Matrix4().lookAt(SUN_OFF, new THREE.Vector3(), new THREE.Vector3(0, 1, 0));
  const SUN_X = new THREE.Vector3(), SUN_Y = new THREE.Vector3(), SUN_Z = new THREE.Vector3();
  SUN_ROT.extractBasis(SUN_X, SUN_Y, SUN_Z);
  let shadowTexel = 0.02;
  // the shadow box only re-centres when the view has moved SHADOW_SLACK units, so the cached static shadows stay valid
  const SHADOW_SLACK = 2.0, shadowC = { x: 0, y: 0, z: 0, set: false };
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.03;
  scene.add(sun, sun.target);
  const world = new THREE.Group();
  scene.add(world);
  // characters and static zone pieces are merged into a few draw calls (batch.js)
  const BATCH = AT.Batch && AT.Batch.init(renderer, scene, world, sun);

  function resize() {
    const w = gameEl.clientWidth, h = gameEl.clientHeight;
    if (!w || !h) return;
    // pick up density changes (moving to another screen, zoom) without exceeding the adaptive cap
    const want = Math.max(pxFloor(), Math.min(dpr(), pixelCap));
    if (Math.abs(want - pixelRatio) > 0.01) { pixelRatio = want; renderer.setPixelRatio(pixelRatio); }
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    camFit();
    if (AT.Tourney) AT.Tourney.resize();
  }
  // camera distance from the zoom (visible width at the look point), then the view's ground footprint for the edge clamp
  function camFit() {
    camDist = clamp(camZoom / (2 * Math.tan(THREE.MathUtils.degToRad(20)) * camera.aspect), 8, 45);
    if (AT.Batch) AT.Batch.farDist = camDist + 7; // characters beyond this use the simpler far version
    const pp = camera.position.clone(), pq = camera.quaternion.clone();
    camera.position.copy(CAM_DIR).multiplyScalar(camDist); camera.lookAt(0, 0, 0); camera.updateMatrixWorld();
    const hit = (nx, ny) => {
      _fr.set(nx, ny, 0.5).unproject(camera).sub(camera.position).normalize();
      return _fp.copy(camera.position).addScaledVector(_fr, _fr.y < -1e-3 ? -camera.position.y / _fr.y : 200);
    };
    camExt.ahead = -hit(0, 1).z; camExt.behind = hit(0, -1).z; camExt.half = hit(1, 0.5).x;
    camera.position.copy(pp); camera.quaternion.copy(pq); camera.updateMatrixWorld();
    fitShadow();
    shadowC.set = false; if (AT.Batch) AT.Batch.staticDirty = true;
  }
  function setZoom(w) {
    w = clamp(w, ZOOM_MIN, ZOOM_MAX);
    if (Math.abs(w - camZoom) < 1e-3) return;
    camZoom = w; if (S) { S.zoom = +w.toFixed(2); S.zoomV = ZOOM_VER; }
    camFit();
  }
  function panTo(x, z) {
    if (Math.abs(x - camLook.x) < 2.5 && Math.abs(z - camLook.z) < 3.5) return; // already in view
    camPan = { x, z, t: 0 };
  }
  // shadow box = what the camera sees (ground up to head height) in the light's frame, plus a small margin
  const _fv = new THREE.Vector3(), _fr = new THREE.Vector3(), _fp = new THREE.Vector3(), _fc = new THREE.Vector3();
  function fitShadow() {
    const pp = camera.position.clone(), pq = camera.quaternion.clone();
    _fc.set(0, 0, 0).addScaledVector(CAM_DIR, camDist);
    camera.position.copy(_fc); camera.lookAt(0, 0, 0); camera.updateMatrixWorld();
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
    for (const nx of [-1, 1]) for (const ny of [-1, 1]) {
      _fr.set(nx, ny, 0.5).unproject(camera).sub(_fc).normalize();
      for (const hy of [0, 2.6]) {
        const t = _fr.y < -1e-3 ? Math.min((hy - _fc.y) / _fr.y, 70) : 70;
        _fp.copy(_fc).addScaledVector(_fr, t);
        const lx = _fp.dot(SUN_X), ly = _fp.dot(SUN_Y);
        x0 = Math.min(x0, lx); x1 = Math.max(x1, lx); y0 = Math.min(y0, ly); y1 = Math.max(y1, ly);
      }
    }
    const m = 1.2 + SHADOW_SLACK, sc = sun.shadow.camera;
    Object.assign(sc, { left: x0 - m, right: x1 + m, bottom: y0 - m, top: y1 + m, near: 1, far: SUN_OFF.length() + 30 });
    sc.updateProjectionMatrix();
    shadowTexel = Math.max(sc.right - sc.left, sc.top - sc.bottom) / sun.shadow.mapSize.x;
    camera.position.copy(pp); camera.quaternion.copy(pq); camera.updateMatrixWorld();
  }
  let pixelCap = 3, resizeQ = 0;
  // screen size / orientation / zoom changes: resize on the next frame (and once more after rotation settles)
  const queueResize = () => { cancelAnimationFrame(resizeQ); resizeQ = requestAnimationFrame(resize); setTimeout(resize, 350); };
  window.addEventListener('resize', queueResize);
  window.addEventListener('orientationchange', queueResize);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', queueResize);
  if (window.ResizeObserver) new ResizeObserver(queueResize).observe(gameEl);

  // ---------- caches ----------
  const M = (color, kind) => SK.M(color, kind === true ? 'basic' : kind);
  const _g = {};
  const GEO = (k, make) => _g[k] || (_g[k] = make());
  const boxG = (w, h, d) => GEO(`b${w},${h},${d}`, () => new THREE.BoxGeometry(w, h, d));
  const sphG = (r, ws = 8, hs = 6) => GEO(`s${r},${ws},${hs}`, () => new THREE.SphereGeometry(r, ws, hs));
  const cylG = (rt, rb, h, s = 8) => GEO(`c${rt},${rb},${h},${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
  const mesh = (geo, mat, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return m; };
  const B = (w, h, d, color, x, y, z) => mesh(boxG(w, h, d), M(color), x, y, z);

  // ---------- canvas textures ----------
  const IC = AT.Icon, ico = (n, c) => IC.svg(n, c);
  const FONT = 'ui-rounded, "SF Pro Rounded", "Nunito", system-ui, sans-serif';
  const texCache = {};
  // canvas textures are drawn at 3-4x their layout size (at least 4x the size they appear on screen, even close up on
  // a large monitor) and use trilinear mipmaps + anisotropy, so 3D labels stay crisp near and far
  const crispTex = (t) => { t.minFilter = THREE.LinearMipmapLinearFilter; t.magFilter = THREE.LinearFilter; t.generateMipmaps = true; t.anisotropy = MAX_ANISO; return t; };
  function ctex(key, w, h, draw) {
    if (texCache[key]) return texCache[key];
    const c = document.createElement('canvas'), k = w >= 400 ? 3 : 4;
    c.width = w * k; c.height = h * k;
    const g = c.getContext('2d'); g.scale(k, k);
    draw(g, w, h);
    return (texCache[key] = crispTex(new THREE.CanvasTexture(c)));
  }
  // slightly heavier lettering for 3D labels: a thin stroke in the text colour thickens the glyphs so they stay
  // readable from far away
  function boldText(g, text, x, y, maxW, lw = 2.6) {
    g.save(); g.lineJoin = 'round'; g.lineWidth = lw; g.strokeStyle = g.fillStyle;
    if (maxW) g.strokeText(text, x, y, maxW); else g.strokeText(text, x, y);
    g.restore();
    if (maxW) g.fillText(text, x, y, maxW); else g.fillText(text, x, y);
  }
  function rr(g, x, y, w, h, r) {
    g.beginPath(); g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
  }
  AT.rr = rr; AT.FONT = FONT;
  const spr = (tex, sx, sy, order = 10) => {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
    s.scale.set(sx, sy, 1); s.renderOrder = order; return s;
  };
  const labelTex = (text, border = '#ff922b', icon = null) => ctex('L' + text + border + icon, 512, 128, (g, w, h) => {
    rr(g, 6, 10, w - 12, h - 26, 40); g.fillStyle = 'rgba(0,0,0,.18)'; g.fill();
    rr(g, 7, 5, w - 14, h - 28, 40); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 11; g.strokeStyle = border; g.stroke();
    g.fillStyle = '#2b2d42'; g.font = `900 58px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (!icon) { boldText(g, text, w / 2, h / 2 - 8, w - 50, 3); return; }
    const tw = Math.min(g.measureText(text).width, w - 140), x0 = (w - tw - 72) / 2;
    IC.draw(g, icon, x0 + 30, h / 2 - 8, 64);
    g.textAlign = 'left'; boldText(g, text, x0 + 72, h / 2 - 8, w - 140, 3);
  });
  const bubbleTex = (icon) => ctex('B' + icon, 128, 140, (g) => {
    g.fillStyle = '#fff';
    g.beginPath(); g.arc(64, 60, 54, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.moveTo(48, 105); g.lineTo(64, 136); g.lineTo(80, 105); g.fill();
    g.lineWidth = 8; g.strokeStyle = '#ffd43b'; g.beginPath(); g.arc(64, 60, 53, 0, Math.PI * 2); g.stroke();
    IC.draw(g, icon, 64, 60, 72);
  });
  // team athletes get their stars on a rarity-coloured pill (grey / blue / purple / gold)
  const starsTex = (n, rar) => ctex('S' + n + '_' + (rar == null ? '' : rar), 200, 44, (g) => {
    if (rar != null) { rr(g, 2, 2, 196, 40, 20); g.fillStyle = RARITY[rar].col; g.fill(); g.lineWidth = 4; g.strokeStyle = '#fff'; g.stroke(); }
    for (let i = 0; i < 5; i++) IC.draw(g, 'star', 22 + i * 39, 22, rar == null ? 42 : 34, i < n ? (n === 5 ? '#ff922b' : null) : '#e9ecef');
  });
  // discipline tag: name + the stats it trains
  const discTex = (D) => ctex('D' + D.id, 300, 66, (g, w, h) => {
    rr(g, 3, 3, w - 6, h - 6, 24); g.fillStyle = 'rgba(43,45,66,.72)'; g.fill();
    const ic = ['speed', 'bolt', 'heart'].filter((_, k) => D.w[k] > 0);
    g.font = `900 25px ${FONT}`; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
    const tw = Math.min(g.measureText(D.name).width, w - 40 - ic.length * 30), x0 = (w - tw - ic.length * 30 - 6) / 2;
    boldText(g, D.name, x0, h / 2 + 1, w - 40 - ic.length * 30, 1.8);
    ic.forEach((n, k) => IC.draw(g, n, x0 + tw + 22 + k * 30, h / 2, 28));
  });
  const starsFor = (m) => starsTex(starsOf(m), m.team ? m.rar || 0 : null);
  // purchase tiles get their own live texture: remaining price + a progress ring that fills as coins flow in
  const tileNum = (n) => (n < 1e5 ? Math.max(0, n).toLocaleString('en-US') : fmt(n));
  function drawTileLabel(t) {
    const W2 = 256, H2 = 186, SC = 3;
    let c = t.canvas;
    if (!c) { c = t.canvas = document.createElement('canvas'); c.width = W2 * SC; c.height = H2 * SC; }
    const g = c.getContext('2d'), lock = t.locked;
    g.setTransform(SC, 0, 0, SC, 0, 0); g.clearRect(0, 0, W2, H2);
    const k = t.cost ? clamp(t.paid / t.cost, 0, 1) : 0;
    // card
    rr(g, 8, 62, W2 - 16, 112, 30); g.fillStyle = 'rgba(0,0,0,.2)'; g.fill();
    rr(g, 8, 54, W2 - 16, 112, 30); g.fillStyle = lock ? '#495057' : '#fff'; g.fill();
    g.lineWidth = 9; g.strokeStyle = lock ? '#868e96' : '#fab005'; g.stroke();
    // icon disc with the progress ring around it
    const cx = W2 / 2, cy = 52, R = 44;
    g.beginPath(); g.arc(cx, cy, R + 6, 0, Math.PI * 2); g.fillStyle = lock ? '#495057' : '#fff'; g.fill();
    g.lineWidth = 12; g.strokeStyle = lock ? '#868e96' : '#e9ecef';
    g.beginPath(); g.arc(cx, cy, R - 3, 0, Math.PI * 2); g.stroke();
    if (k > 0 && !lock) {
      g.strokeStyle = '#40c057'; g.lineCap = 'round';
      g.beginPath(); g.arc(cx, cy, R - 3, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2); g.stroke(); g.lineCap = 'butt';
    }
    g.lineWidth = 3; g.strokeStyle = AT.Icon.INK;
    g.beginPath(); g.arc(cx, cy, R + 3.5, 0, Math.PI * 2); g.stroke();
    IC.draw(g, t.icon, cx, cy, 52);
    // remaining amount
    g.font = `900 44px ${FONT}`; g.textBaseline = 'middle';
    const txt = lock ? t.lockText : tileNum(Math.ceil(t.cost - t.paid - 1e-6));
    const tw = Math.min(g.measureText(txt).width, W2 - 92), x0 = (W2 - tw - 50) / 2;
    IC.draw(g, lock ? 'lock' : 'coin', x0 + 20, 132, 42);
    g.textAlign = 'left'; g.lineJoin = 'round';
    g.fillStyle = lock ? '#fff' : (k > 0 ? '#2b8a3e' : '#2b2d42'); boldText(g, txt, x0 + 48, 134, W2 - 92, 2.4);
    if (k > 0 && !lock) { // small "% paid" chip
      const pc = Math.floor(k * 100) + '%';
      g.font = `900 20px ${FONT}`; const pw = g.measureText(pc).width + 16;
      rr(g, cx + R - 10, 10, pw, 26, 13); g.fillStyle = '#40c057'; g.fill();
      g.fillStyle = '#fff'; g.textAlign = 'center'; g.fillText(pc, cx + R - 10 + pw / 2, 24);
    }
    if (!t.tex) {
      t.tex = crispTex(new THREE.CanvasTexture(c));
    } else t.tex.needsUpdate = true;
    t.shownRem = Math.ceil(t.cost - t.paid - 1e-6); t.shownK = Math.floor(k * 100);
    return t.tex;
  }
  // particle textures
  const PTEX = {
    sparkle: ctex('p-sp', 64, 64, (g) => { g.fillStyle = '#fff3bf'; g.fill(new Path2D('M32 4c2.6 13 7 17.4 20 20-13 2.6-17.4 7-20 20-2.6-13-7-17.4-20-20 13-2.6 17.4-7 20-20z')); }),
    lightning: ctex('p-lt', 64, 64, (g) => {
      g.strokeStyle = '#ffe066'; g.lineWidth = 7; g.lineJoin = 'miter'; g.shadowColor = '#fff'; g.shadowBlur = 8;
      g.beginPath(); g.moveTo(40, 4); g.lineTo(22, 30); g.lineTo(38, 32); g.lineTo(20, 60); g.stroke();
    }),
    wave: ctex('p-wv', 64, 64, (g) => {
      g.strokeStyle = '#a5f3fc'; g.lineWidth = 7; g.lineCap = 'round';
      g.beginPath(); g.arc(32, 44, 22, Math.PI * 1.1, Math.PI * 1.9); g.stroke();
      g.fillStyle = '#e3fafc'; g.beginPath(); g.arc(14, 30, 5, 0, 7); g.fill();
    }),
    comet: ctex('p-cm', 64, 64, (g) => {
      const gr = g.createRadialGradient(32, 32, 2, 32, 32, 30); gr.addColorStop(0, '#fff'); gr.addColorStop(0.4, '#ffa94d'); gr.addColorStop(1, 'rgba(255,120,0,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    }),
    ring: ctex('p-rg', 128, 128, (g) => {
      const gr = g.createRadialGradient(64, 64, 20, 64, 64, 62); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.75, 'rgba(255,236,153,.9)'); gr.addColorStop(1, 'rgba(255,212,59,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    }),
    speed: ctex('p-sl', 64, 64, (g) => {
      g.strokeStyle = 'rgba(255,255,255,.95)'; g.lineCap = 'round';
      for (const [y, l, w] of [[22, 40, 5], [34, 54, 6], [46, 34, 4]]) { g.lineWidth = w; g.beginPath(); g.moveTo(60 - l, y); g.lineTo(60, y); g.stroke(); }
    }),
    glow: ctex('p-gl', 64, 64, (g) => {
      const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,230,120,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    }),
  };

  // ======================================================================
  // MODELS
  // ======================================================================
  const SKINS = [0xffd6b0, 0xf1c27d, 0xe0ac69, 0xc68642, 0x8d5524];
  const HAIRS = [0x3b2a1a, 0x111111, 0xe0b04a, 0x8b4513, 0xd9480f, 0xf783ac];
  const makeChar = (shirt, o = {}) => SK.figure(Object.assign({ shirt }, o));
  const animChar = (ch, dt, mode, kind) => SK.anim(ch, dt, mode, kind);
  // national-style football kits: the European ones unlock in the European Championship, Brazil and Argentina styles in the World Championship
  const kitLvl = () => Math.max(S.lg[2].best || 0, S.lg[2].lvl || 0);
  const kitUnlocked = (id) => { const K = SK.KITS[id]; return !!K && kitLvl() >= (K.region === 'eu' ? 3 : 4); };
  const myKit = () => (S.kit && kitUnlocked(S.kit) ? S.kit : null);
  AT.kitUnlocked = kitUnlocked; AT.myKit = myKit;
  AT.setKit = (id) => { S.kit = id || null; charCache.forEach((c, k) => { if (c.kit !== myKit()) charCache.delete(k); }); save(true); };
  // rival academies wear national-style kits in football (they rotate with the league)
  const KIT_ORDER = ['bra', 'ger', 'arg', 'esp', 'fra', 'ita'];
  AT.rivalKit = (k, lvl = 0) => KIT_ORDER[(k + lvl * 2) % KIT_ORDER.length];
  const athleteSpec = (m, tier) => ({ zone: m.zone, tier, shirt: ZONES[m.zone].shirt, skin: SKINS[m.skin], hair: HAIRS[m.hair], num: ((m.id * 7) % 98) + 1, name: m.name, seed: m.id, kit: m.zone === 2 ? myKit() : null, scale: 0.9 });
  AT.thumbFor = (m) => SK.thumb(renderer, `m${m.id}-${starsOf(m)}${m.zone === 2 ? myKit() || '' : ''}`, () => SK.athlete(Object.assign(athleteSpec(m, starsOf(m)), { scale: 1 })));
  AT.thumbSkin = (zone, tier) => SK.thumb(renderer, `z${zone}-${tier}`, () => SK.athlete({ zone, tier, shirt: ZONES[zone].shirt, skin: SKINS[1], hair: HAIRS[(zone + tier) % HAIRS.length], num: 10 + zone, name: SK.LEGENDS[zone].name.split(' ').pop(), scale: 1 }));

  function makeItem(type) {
    const g = new THREE.Group();
    switch (type) {
      case 'water':
        g.add(mesh(cylG(0.12, 0.13, 0.32, 8), M(0x4dabf7), 0, 0.16, 0));
        g.add(mesh(cylG(0.13, 0.13, 0.07, 8), M(0xffffff), 0, 0.2, 0));
        g.add(mesh(cylG(0.06, 0.07, 0.07, 6), M(0xffffff), 0, 0.36, 0));
        break;
      case 'dumbbell': {
        const bar = mesh(cylG(0.035, 0.035, 0.46, 6), M(0xadb5bd), 0, 0.13, 0); bar.rotation.z = Math.PI / 2; g.add(bar);
        for (const x of [-0.2, 0.2]) { const p = mesh(cylG(0.13, 0.13, 0.1, 8), M(0x343a40), x, 0.13, 0); p.rotation.z = Math.PI / 2; g.add(p); }
        break;
      }
      case 'football':
        g.add(mesh(GEO('ico', () => new THREE.IcosahedronGeometry(0.17, 0)), M(0xffffff), 0, 0.17, 0));
        g.add(mesh(GEO('ico2', () => new THREE.DodecahedronGeometry(0.155, 0)), M(0x212529), 0, 0.17, 0));
        break;
      case 'kickboard':
        g.add(B(0.44, 0.08, 0.3, 0xffd43b, 0, 0.05, 0));
        g.add(B(0.44, 0.085, 0.08, 0xff6b6b, 0, 0.05, 0));
        break;
      case 'gloves': {
        const a = mesh(sphG(0.15, 8, 6), M(0xfa5252), -0.1, 0.15, 0); a.scale.set(0.9, 1, 1.2); g.add(a);
        const b = mesh(sphG(0.15, 8, 6), M(0xfa5252), 0.12, 0.15, 0); b.scale.set(0.9, 1, 1.2); g.add(b);
        break;
      }
      case 'shake':
        g.add(mesh(cylG(0.14, 0.1, 0.3, 8), M(0xf783ac), 0, 0.15, 0));
        g.add(mesh(cylG(0.15, 0.15, 0.05, 8), M(0xffffff), 0, 0.32, 0));
        g.add(mesh(cylG(0.02, 0.02, 0.22, 4), M(0x40c057), 0.05, 0.42, 0));
        break;
      case 'baton': { const b = mesh(cylG(0.055, 0.055, 0.42, 8), M(0xfab005, 'shiny'), 0, 0.07, 0); b.rotation.z = Math.PI / 2; g.add(b);
        for (const x of [-0.17, 0.17]) { const r = mesh(cylG(0.06, 0.06, 0.05, 8), M(0xe03131), x, 0.07, 0); r.rotation.z = Math.PI / 2; g.add(r); } break; }
      case 'basketball': { const b = SK.bballMesh(0.17); b.position.y = 0.17; g.add(b); break; }
      // rack-only props (each sport's shelf holds only its own gear)
      case 'blocks': // starting blocks
        g.add(B(0.1, 0.03, 0.42, 0x868e96, 0, 0.02, 0));
        for (const [x, z] of [[-0.09, -0.08], [0.09, 0.1]]) { const p = B(0.14, 0.04, 0.12, 0x228be6, x, 0.08, z); p.rotation.x = -0.7; g.add(p); }
        break;
      case 'hurdle':
        g.add(B(0.03, 0.26, 0.03, 0xdee2e6, -0.17, 0.13, 0), B(0.03, 0.26, 0.03, 0xdee2e6, 0.17, 0.13, 0));
        g.add(B(0.4, 0.07, 0.03, 0xfa5252, 0, 0.27, 0), B(0.1, 0.02, 0.18, 0xdee2e6, -0.17, 0.01, 0), B(0.1, 0.02, 0.18, 0xdee2e6, 0.17, 0.01, 0));
        break;
      case 'cone':
        g.add(mesh(GEO('cone', () => new THREE.ConeGeometry(0.14, 0.32, 6)), M(0xff922b), 0, 0.17, 0));
        g.add(B(0.26, 0.02, 0.26, 0xff922b, 0, 0.01, 0));
        break;
      case 'bib': // folded training bibs
        g.add(B(0.34, 0.06, 0.26, 0xc0eb75, 0, 0.03, 0), B(0.34, 0.06, 0.26, 0xff8787, 0, 0.09, 0));
        break;
      case 'towel':
        g.add(mesh(cylG(0.11, 0.11, 0.34, 8), M(0xffffff), 0, 0.11, 0)); g.children[0].rotation.z = Math.PI / 2;
        g.add(mesh(cylG(0.115, 0.115, 0.05, 8), M(0x4dabf7), 0.1, 0.11, 0)); g.children[1].rotation.z = Math.PI / 2;
        break;
      case 'swimcap': { const c = mesh(GEO('rcap', () => new THREE.SphereGeometry(0.14, 8, 5, 0, Math.PI * 2, 0, Math.PI / 2)), M(0xe64980)); g.add(c); break; }
      case 'wraps':
        for (const x of [-0.09, 0.09]) { const r = mesh(cylG(0.08, 0.08, 0.1, 10), M(0xf8f9fa), x, 0.08, 0); r.rotation.z = Math.PI / 2; g.add(r); }
        break;
      case 'pads': // focus mitts
        for (const x of [-0.1, 0.11]) { const p = mesh(cylG(0.14, 0.12, 0.08, 10), M(0x212529), x, 0.06, 0); g.add(p); g.add(mesh(cylG(0.08, 0.08, 0.02, 10), M(0xfa5252), x, 0.105, 0)); }
        break;
      case 'plate':
        { const p = mesh(cylG(0.17, 0.17, 0.05, 12), M(0x343a40), 0, 0.025, 0); g.add(p); g.add(mesh(cylG(0.05, 0.05, 0.06, 8), M(0xadb5bd), 0, 0.03, 0)); }
        break;
    }
    g.userData.type = type;
    return g;
  }
  // item pool (stack items are reused instead of rebuilt)
  const itemPool = {};
  const getItem = (type) => { const p = itemPool[type]; const m = p && p.length ? p.pop() : makeItem(type); m.scale.setScalar(1); m.rotation.set(0, 0, 0); return m; };
  const releaseItem = (m) => { if (m.parent) m.parent.remove(m); (itemPool[m.userData.type] || (itemPool[m.userData.type] = [])).push(m); };

  function makeTrophy(tier) {
    const col = tier === 0 ? 0xffd43b : tier === 1 ? 0xdee2e6 : 0xe8590c;
    const mt = M(col, 'shiny');
    const g = new THREE.Group();
    g.add(B(0.3, 0.08, 0.3, 0x5c3d2e, 0, 0.04, 0));
    g.add(mesh(cylG(0.04, 0.07, 0.16, 6), mt, 0, 0.16, 0));
    g.add(mesh(cylG(0.17, 0.08, 0.22, 8), mt, 0, 0.35, 0));
    const h1 = mesh(GEO('handle', () => new THREE.TorusGeometry(0.07, 0.02, 4, 8)), mt, -0.17, 0.37, 0);
    const h2 = h1.clone(); h2.position.x = 0.17; g.add(h1, h2);
    return g;
  }

  // ======================================================================
  // WORLD BUILD
  // ======================================================================
  const colliders = [];
  const racks = [];
  const bins = [];   // trash cans: next to every rack + one at the entrance
  const stations = [];
  const athletes = [];
  const assistants = [];
  const queue = [];   // desk queue (paying)
  const line = [];    // lobby waiting line (no free station yet)
  const tiles = new Map();
  const built = { zone: [], stations: ZONES.map(() => 0), assist: ZONES.map(() => 0), preview: {}, style: [], gear: [], cols: {} };
  let recepEnt = null, trophyGroup = null, hallLabel = null;
  const bounds = { minX: -6.3, maxX: 6.3, minZ: -4.4, maxZ: 16.3 };
  const addCol = (x, z, hw, hd) => colliders.push({ x, z, hw, hd });

  function buildStatic() {
    world.add(B(70, 0.2, 170, 0x9be08f, 0, -0.1, -45));
    // trees as two instanced meshes (2 draw calls instead of ~100)
    const spots = [];
    for (let z = 18; z > -80; z -= 4.2) for (const side of [-1, 1]) spots.push([side * rand(8.2, 12), z + rand(-1, 1), rand(0.8, 1.3)]);
    const trunks = new THREE.InstancedMesh(boxG(0.3, 0.8, 0.3), M(0x8d5524), spots.length);
    const leaves = new THREE.InstancedMesh(GEO('tree', () => new THREE.ConeGeometry(0.9, 1.8, 6)), M(0xffffff), spots.length);
    const mtx = new THREE.Matrix4(), q = new THREE.Quaternion(), sc = new THREE.Vector3(), pos = new THREE.Vector3(), col = new THREE.Color();
    spots.forEach(([x, z, s], i) => {
      sc.setScalar(s);
      mtx.compose(pos.set(x, 0.4 * s, z), q, sc); trunks.setMatrixAt(i, mtx);
      mtx.compose(pos.set(x, 1.6 * s, z), q, sc); leaves.setMatrixAt(i, mtx);
      leaves.setColorAt(i, col.setHex(pick([0x51cf66, 0x40c057, 0x69db7c])));
    });
    world.add(trunks, leaves);
    // lobby
    world.add(B(13, 0.12, 12, 0xfff3e0, 0, 0.06, 11));
    world.add(B(13.3, 0.1, 12.3, 0xffffff, 0, 0.05, 11));
    world.add(B(2.6, 0.125, 12, 0xffe8cc, 0, 0.065, 11));
    // (the main entrance is built by buildMainGate and grows with the academy)
    // waiting benches
    world.add(B(5.4, 0.35, 0.5, 0x74c0fc, -3.7, 0.3, 15.45), B(5.4, 0.5, 0.12, 0x4dabf7, -3.7, 0.55, 15.7));
    addCol(-3.7, 15.5, 2.7, 0.3);
    const waitSign = spr(labelTex('Waiting', '#4dabf7', 'hourglass'), 2.0, 0.5, 8); waitSign.position.set(-3.7, 1.6, 15.6); world.add(waitSign);
    addBin(3.7, 14.5, -1);  // entrance trash can
    // reception desk
    const desk = new THREE.Group(); desk.position.set(DESK.x, 0.12, DESK.z);
    desk.add(B(0.9, 0.95, 2.4, 0x845ef7, 0, 0.47, 0), B(1.1, 0.1, 2.6, 0xffffff, 0, 0.98, 0));
    desk.add(B(0.4, 0.3, 0.5, 0x495057, -0.1, 1.18, -0.6), B(0.3, 0.2, 0.05, 0x74c0fc, -0.1, 1.33, -0.36));
    world.add(desk);
    addCol(DESK.x, DESK.z, 0.55, 1.3);
    const staffPad = mesh(GEO('staff', () => new THREE.CircleGeometry(1.05, 24)), new THREE.MeshBasicMaterial({ color: 0x69db7c, transparent: true, opacity: 0.55, depthWrite: false }), STAFF.x, 0.135, STAFF.z);
    staffPad.rotation.x = -Math.PI / 2; world.add(staffPad);
    const deskSign = spr(labelTex('Reception', '#845ef7', 'coin'), 2.6, 0.65, 8); deskSign.position.set(DESK.x - 0.6, 2.6, DESK.z); world.add(deskSign);
    // trophy hall
    const hall = new THREE.Group(); hall.position.set(HALL.x, 0.12, HALL.z);
    hall.add(B(4.2, 0.25, 2.6, 0xfff0f6, 0, 0.12, 0));
    hall.add(B(4.2, 2.3, 0.3, 0xf783ac, 0, 1.15, -1.15));
    hall.add(B(4.0, 0.1, 0.55, 0xffffff, 0, 0.95, -0.85), B(4.0, 0.1, 0.55, 0xffffff, 0, 1.65, -0.85));
    world.add(hall);
    trophyGroup = new THREE.Group(); trophyGroup.position.copy(hall.position); world.add(trophyGroup);
    addCol(HALL.x, HALL.z - 0.9, 2.15, 0.5);
  }

  function zoneDecor(i, g, zc) {
    const Z = ZONES[i];
    const dark = new THREE.Color(Z.floor).multiplyScalar(0.82).getHex();
    switch (Z.id) {
      case 'track': // red running track: lanes, start and finish lines, lane numbers
        for (let x = -3.3; x <= 6; x += 1.3) g.add(B(0.06, 0.012, 9, 0xffffff, x, 0.126, 0));
        g.add(B(10, 0.012, 0.12, 0xffffff, 1.3, 0.127, 4.1), B(10, 0.012, 0.12, 0xffffff, 1.3, 0.127, -4.1));
        for (let k = 0; k < 10; k++) g.add(B(0.5, 0.013, 0.12, k % 2 ? 0x212529 : 0xffffff, -3.0 + k * 0.5 + 2.2, 0.128, -3.8));
        break;
      case 'gym': // rubber floor tiles, mirror wall at the back
        g.add(B(10.2, 0.02, 8.2, 0x495057, 1.0, 0.125, 0));
        for (let x = -3.6; x <= 5.6; x += 1.15) g.add(B(0.04, 0.022, 8.2, 0x343a40, x, 0.127, 0));
        for (let z = -3.6; z <= 3.6; z += 1.15) g.add(B(10.2, 0.022, 0.04, 0x343a40, 1.0, 0.127, z));
        for (let k = 0; k < 4; k++) {
          g.add(B(2.3, 2.0, 0.08, 0xadb5bd, -2.4 + k * 2.45, 1.12, -4.45));
          g.add(mesh(boxG(2.1, 1.8, 0.05), M(0xd0ebff, 'shiny'), -2.4 + k * 2.45, 1.12, -4.4));
          g.add(B(0.5, 1.4, 0.02, 0xf1f3f5, -2.9 + k * 2.45, 1.2, -4.37));
        }
        addCol(1.0, zc - 4.45, 5.0, 0.12);
        break;
      case 'football': // grass pitch with mowing stripes
        for (let k = 0; k < 6; k++) if (k % 2) g.add(B(2.1, 0.008, 9.0, 0x74c69d, -5.25 + k * 2.1, 0.123, 0));
        g.add(B(0.08, 0.01, 9, 0xffffff, 0.7, 0.125, 0));
        { const c = mesh(GEO('circ', () => new THREE.TorusGeometry(1.4, 0.05, 3, 28)), M(0xffffff, true), 0.7, 0.13, 0); c.rotation.x = Math.PI / 2; g.add(c); }
        g.add(B(12.2, 0.01, 0.08, 0xffffff, 0, 0.125, -4.3), B(12.2, 0.01, 0.08, 0xffffff, 0, 0.125, 4.3));
        break;
      case 'pool': {
        g.add(B(8.4, 0.03, 8, 0x339af0, 0.7, 0.13, 0));
        const beads = [];
        for (const x of [-2.7, 0.7, 4.1]) for (let z = -3.6; z <= 3.6; z += 0.6) beads.push([x, z]);
        const inst = new THREE.InstancedMesh(sphG(0.09, 6, 4), M(0xffffff), beads.length);
        const mtx = new THREE.Matrix4(), c = new THREE.Color();
        beads.forEach(([x, z], k) => { mtx.makeTranslation(x, 0.17, z); inst.setMatrixAt(k, mtx); inst.setColorAt(k, c.setHex(k % 4 === 0 ? 0xfa5252 : 0xffffff)); });
        g.add(inst);
        break;
      }
      case 'boxing': {
        // ring open on the left (rack side) and the front, roped on the back and right
        const cx = 0.7, hw = 3.4, hd = 3.9;
        g.add(B(hw * 2 + 0.2, 0.04, hd * 2 + 0.2, 0xe7f5ff, cx, 0.13, 0));                              // ring canvas
        g.add(B(hw * 2 - 0.6, 0.042, 0.1, 0x74c0fc, cx, 0.133, 0), B(0.1, 0.042, hd * 2 - 0.6, 0x74c0fc, cx, 0.133, 0));
        const corners = [[-hw, -hd, 0xe03131], [hw, -hd, 0x1c7ed6], [-hw, hd, 0xffffff], [hw, hd, 0xffffff]];
        for (const [x, z, pc] of corners) { g.add(B(0.25, 1.4, 0.25, 0x343a40, cx + x, 0.82, z)); g.add(B(0.3, 0.6, 0.3, pc, cx + x, 1.0, z)); addCol(cx + x, zc + z, 0.18, 0.18); }
        for (const [y, rc] of [[0.55, 0x1c7ed6], [0.9, 0xffffff], [1.25, 0xfa5252]]) { g.add(B(hw * 2, 0.06, 0.06, rc, cx, y, -hd)); g.add(B(0.06, 0.06, hd * 2, rc, cx + hw, y, 0)); }
        addCol(cx, zc - hd, hw, 0.1); addCol(cx + hw, zc, 0.1, hd);
        break;
      }
      case 'hoops': { // indoor court: wooden planks, painted lines, two hoops, a small bench
        for (let x = -5.7; x <= 6; x += 0.6) g.add(B(0.025, 0.012, 9, 0xc98b4f, x, 0.126, 0));
        const line = (w, d, x, z) => g.add(B(w, 0.014, d, 0xffffff, x, 0.128, z));
        line(11.6, 0.07, 0.15, -4.25); line(11.6, 0.07, 0.15, 4.25); line(0.07, 8.5, 5.95, 0); line(0.07, 8.5, -5.65, 0);
        g.add(B(1.8, 0.013, 2.2, 0x7048e8, 5.05, 0.127, 0)); line(0.06, 2.2, 4.15, 0);                                   // painted key
        { const c = mesh(GEO('ftc', () => new THREE.TorusGeometry(0.75, 0.035, 3, 24, Math.PI)), M(0xffffff, true), 4.15, 0.13, 0); c.rotation.set(Math.PI / 2, 0, Math.PI / 2); g.add(c); }
        { const a3 = mesh(GEO('3pt', () => new THREE.TorusGeometry(3.0, 0.04, 3, 36, Math.PI)), M(0xffffff, true), 5.75, 0.13, 0); a3.rotation.set(Math.PI / 2, 0, Math.PI / 2); g.add(a3); }
        { const cc = mesh(GEO('ccirc', () => new THREE.TorusGeometry(0.9, 0.035, 3, 24)), M(0xffffff, true), -1.6, 0.13, 0); cc.rotation.x = Math.PI / 2; g.add(cc); }
        const st = styleMats(1, 0x7048e8);
        const h1 = new THREE.Group(); hoopRig(h1, st, 1, 0, 2.2); h1.position.set(5.75, 0.12, 0); h1.rotation.y = -Math.PI / 2; g.add(h1);
        const h2 = new THREE.Group(); hoopRig(h2, st, 1, 0, 2.2); h2.position.set(-1.6, 0.12, -4.0); g.add(h2);
        addCol(6.1, zc, 0.15, 0.15); addCol(-1.6, zc - 4.35, 0.15, 0.15);
        // bench
        g.add(B(2.2, 0.1, 0.45, 0x7048e8, 4.6, 0.55, 3.75), B(2.2, 0.5, 0.08, 0x5f3dc4, 4.6, 0.8, 3.98));
        for (const bx of [3.6, 5.6]) g.add(B(0.08, 0.45, 0.4, 0x495057, bx, 0.32, 3.75));
        for (const bx of [3.9, 4.5]) g.add(mesh(cylG(0.07, 0.08, 0.24, 8), M(0x4dabf7), bx, 0.72, 3.7));
        addCol(4.6, zc + 3.8, 1.1, 0.3);
        break;
      }
      case 'stadium':
        for (let r = 0; r < 3; r++) g.add(B(12.2, 0.4, 0.6, [0xffd43b, 0x4dabf7, 0xff6b9a][r], 0, 0.3 + r * 0.4, -4.1 + r * -0.6));
        for (const z of [-2.8, 0, 2.8]) g.add(B(10.5, 0.01, 0.07, 0xffffff, 0.7, 0.125, z));
        addCol(0, zc - 4.7, 6.2, 0.95);
        break;
    }
  }

  const RACK_EXTRA = { water: ['blocks', 'hurdle'], dumbbell: ['plate', 'shake'], football: ['cone', 'bib'], kickboard: ['towel', 'swimcap'], gloves: ['wraps', 'pads'], baton: ['hurdle', 'water'], basketball: ['water', 'towel'] };
  // every item a zone's disciplines need (the rack hands out whichever is needed most)
  const zoneItems = (i) => [...new Set(DISC[ZONES[i].id].map((d) => d.item))];
  function makeRack(item, zone) {
    const g = new THREE.Group();
    const wood = 0xd9a066;
    g.add(B(1.3, 0.08, 0.8, wood, 0, 0.55, 0), B(1.3, 0.08, 0.8, wood, 0, 0.18, 0));
    for (const [x, z] of [[-0.6, -0.35], [0.6, -0.35], [-0.6, 0.35], [0.6, 0.35]]) g.add(B(0.08, 0.6, 0.08, 0x8d5524, x, 0.3, z));
    const top = zoneItems(zone), row = [0, 1, 2].map((k) => top[k % top.length]);
    row.forEach((t, k) => { const it = makeItem(t); it.position.set(-0.38 + k * 0.38, 0.59, 0); g.add(it); });
    // bottom shelf: the rest of that sport's gear
    const extra = RACK_EXTRA[item] || [item, item];
    extra.concat(extra[0]).forEach((t, k) => { const it = makeItem(t); it.position.set(-0.38 + k * 0.38, 0.22, 0.05); g.add(it); });
    const ring = mesh(GEO('rring', () => new THREE.RingGeometry(1.15, 1.32, 28)), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, depthWrite: false }), 0, 0.02, 0);
    ring.rotation.x = -Math.PI / 2; g.add(ring);
    const ico = spr(bubbleTex(ITEMS[item].icon), 0.8, 0.88, 9); ico.position.y = 1.55; g.add(ico);
    g.userData.ico = ico;
    return g;
  }

  function makeBin() {
    const g = new THREE.Group();
    g.add(mesh(cylG(0.34, 0.27, 0.74, 10), M(0x40c057), 0, 0.37, 0));
    g.add(mesh(cylG(0.36, 0.36, 0.1, 10), M(0x2f9e44), 0, 0.08, 0));
    for (let k = 0; k < 6; k++) { const a = (k / 6) * Math.PI * 2; const r = B(0.06, 0.48, 0.04, 0x2f9e44, Math.sin(a) * 0.31, 0.42, Math.cos(a) * 0.31); r.rotation.y = a; g.add(r); }
    const lid = new THREE.Group(); lid.position.set(0, 0.76, -0.34);
    lid.add(mesh(cylG(0.38, 0.38, 0.08, 10), M(0x2f9e44), 0, 0, 0.34), B(0.24, 0.08, 0.08, 0x2b8a3e, 0, 0.08, 0.34));
    g.add(lid);
    const ring = mesh(GEO('bring', () => new THREE.RingGeometry(0.98, 1.12, 28)), new THREE.MeshBasicMaterial({ color: 0x69db7c, transparent: true, opacity: 0.65, depthWrite: false }), 0, 0.02, 0);
    ring.rotation.x = -Math.PI / 2; g.add(ring);
    const ico = spr(bubbleTex('trash'), 0.66, 0.72, 9); ico.position.y = 1.5; g.add(ico);
    g.userData = { lid, ring, ico };
    return g;
  }
  function addBin(x, z, zone) {
    const obj = makeBin(); obj.position.set(x, 0.12, z); world.add(obj);
    addCol(x, z, 0.3, 0.3);
    obj.scale.setScalar(0.01);
    tween({ dur: 0.35, step: (k) => obj.scale.setScalar(Math.max(0.01, easeBack(k))) });
    bins.push({ x, z, zone, obj, lid: 0, lidT: 0 });
  }

  function buildZone(i) {
    const Z = ZONES[i], zc = zoneZ(i);
    const g = new THREE.Group(); g.position.z = zc;
    g.add(B(12.6, 0.12, 9.2, Z.floor, 0, 0.06, 0));
    g.add(B(12.9, 0.1, 9.5, 0xffffff, 0, 0.05, 0));
    zoneDecor(i, g, zc);
    const label = spr(labelTex(Z.name, '#' + new THREE.Color(Z.shirt).getHexString(), Z.icon), 2.7, 0.68, 8);
    label.position.set(-3.8, 2.4, -3.9); g.add(label);
    const rack = makeRack(Z.item, i); rack.position.set(RACK_X, 0.12, 0); g.add(rack);
    racks.push({ zone: i, item: Z.item, pos: new THREE.Vector3(RACK_X, 0.12, zc), obj: rack });
    addCol(RACK_X, zc, 0.7, 0.45);
    world.add(g);
    addBin(RACK_X - 1.2, zc - 2.3, i);
    if (built.ready) openEntrance(i); else buildEntrance(i, false);
    g.scale.set(1, 0.01, 1);
    tween({ dur: 0.35, step: (k) => g.scale.set(1, Math.max(0.01, easeBack(k)), 1) });
  }

  function buildPreview(i) {
    const Z = ZONES[i];
    const g = new THREE.Group(); g.position.z = zoneZ(i);
    g.add(B(12.6, 0.1, 9.2, 0xdee2e6, 0, 0.05, 0));
    for (let x = -6; x <= 6; x += 1.5) if (x < -0.9 || x > 2.3) g.add(B(0.7, 0.5, 0.12, 0xffffff, x, 0.35, 4.55));
    const label = spr(labelTex(Z.name, '#adb5bd', Z.icon), 2.8, 0.7, 8); label.position.set(0, 2.6, -1.5); g.add(label);
    world.add(g);
    built.preview[i] = g;
    buildEntrance(i, true);
  }

  // ======================================================================
  // ENTRANCES: a themed gate in front of every zone (closed and grey while locked) + the academy's main gate
  // ======================================================================
  const GATE_X = 0.7, GATE_HW = 1.35;
  const entrances = {};
  const greyOf = (c) => { const k = new THREE.Color(c); const l = 0.3 * k.r + 0.59 * k.g + 0.11 * k.b; return new THREE.Color(0.45 + l * 0.35, 0.47 + l * 0.35, 0.5 + l * 0.35).getHex(); };
  function buildEntrance(i, locked) {
    if (entrances[i]) { world.remove(entrances[i].g); delete entrances[i]; }
    const id = ZONES[i].id, z0 = zoneZ(i) + 4.85;
    const g = new THREE.Group(); g.position.set(GATE_X, 0.12, z0);
    const C = (col, kind) => (locked ? M(greyOf(col)) : M(col, kind));
    const box = (w, h, d, col, x, y, z, kind) => { const m = BX(w, h, d, C(col, kind), x, y, z); g.add(m); return m; };
    const fx = { type: id };
    const posts = (col, w = 0.28, h = 2.3, kind) => { for (const sx of [-1, 1]) box(w, h, w, col, sx * GATE_HW, h / 2, 0, kind); };
    switch (id) {
      case 'track': { // finish-line arch with a clock on top
        for (const sx of [-1, 1]) for (let k = 0; k < 5; k++) box(0.3, 0.46, 0.3, k % 2 ? 0xffffff : 0xe03131, sx * GATE_HW, 0.23 + k * 0.46, 0);
        for (let k = 0; k < 12; k++) for (let r = 0; r < 2; r++) box(0.25, 0.15, 0.2, (k + r) % 2 ? 0x212529 : 0xffffff, -1.4 + k * 0.255, 2.38 + r * 0.15, 0);
        const clock = new THREE.Group(); clock.position.set(0, 3.0, 0.02); g.add(clock);
        clock.add(BX(0.75, 0.5, 0.18, C(0x212529), 0, 0, 0));
        clock.add(BX(0.62, 0.36, 0.02, locked ? M(0x868e96) : M(0xff6b6b, 'hot'), 0, 0, 0.1));
        if (!locked) { const t = spr(ctex('clock', 128, 64, (gg) => { gg.fillStyle = '#ffe066'; gg.font = `900 44px ${FONT}`; gg.textAlign = 'center'; gg.textBaseline = 'middle'; boldText(gg, '9.58', 64, 34, 0, 2.4); }), 0.55, 0.28, 9); t.position.set(0, 3.0, 0.15); g.add(t); }
        break;
      }
      case 'football': { // goal posts with a net
        for (const sx of [-1, 1]) g.add(mesh(cylG(0.09, 0.09, 2.4, 8), C(0xffffff, 'shiny'), sx * GATE_HW, 1.2, 0));
        const bar = mesh(cylG(0.09, 0.09, 2.8, 8), C(0xffffff, 'shiny'), 0, 2.4, 0); bar.rotation.z = Math.PI / 2; g.add(bar);
        const net = mesh(boxG(2.7, 0.75, 0.02), GEO('gnet', () => new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.6 })), 0, 2.05, -0.35); net.rotation.x = -0.45; g.add(net);
        for (const sx of [-1, 1]) { const sn = mesh(boxG(0.02, 2.35, 0.6), net.material, sx * GATE_HW, 1.2, -0.3); g.add(sn); }
        g.add(mesh(GEO('ico', () => new THREE.IcosahedronGeometry(0.17, 0)), C(0xffffff), 0, 2.75, 0));
        break;
      }
      case 'pool': { // blue tiled archway with waves
        for (const sx of [-1, 1]) for (let k = 0; k < 7; k++) box(0.36, 0.3, 0.36, k % 2 ? 0x4dabf7 : 0x1c7ed6, sx * GATE_HW, 0.15 + k * 0.32, 0);
        for (let k = 0; k <= 10; k++) { const a = Math.PI * (k / 10); const t = box(0.34, 0.3, 0.36, k % 2 ? 0x4dabf7 : 0x74c0fc, Math.cos(a) * GATE_HW, 2.25 + Math.sin(a) * 0.75, 0); t.rotation.z = a - Math.PI / 2; }
        for (const y of [3.2, 3.45]) { const w = mesh(GEO('gwave' + y, () => new THREE.TorusGeometry(0.35, 0.06, 4, 12, Math.PI)), C(0x99e9f2, 'shiny'), 0, y - 0.25, 0.05); g.add(w); const w2 = w.clone(); w2.position.x = -0.65; const w3 = w.clone(); w3.position.x = 0.65; g.add(w2, w3); }
        fx.splash = !locked;
        break;
      }
      case 'boxing': { // ring posts with red ropes and spotlights
        posts(0x212529, 0.25, 2.5);
        for (const sx of [-1, 1]) box(0.34, 0.5, 0.34, sx < 0 ? 0xe03131 : 0x1c7ed6, sx * GATE_HW, 2.35, 0);
        for (const y of [1.85, 2.1, 2.35]) box(2.7, 0.06, 0.06, 0xfa5252, 0, y, 0.12);
        fx.spots = [];
        for (const sx of [-1, 1]) {
          const lamp = new THREE.Group(); lamp.position.set(sx * GATE_HW, 2.75, 0); g.add(lamp);
          lamp.add(mesh(cylG(0.12, 0.16, 0.25, 8), C(0x343a40)));
          if (!locked) { const beam = mesh(GEO('beam', () => new THREE.ConeGeometry(0.75, 2.6, 12, 1, true)), M(0xfff3bf, 'glow'), 0, -1.3, 0); lamp.add(beam); }
          lamp.rotation.z = sx * 0.35; fx.spots.push(lamp);
        }
        break;
      }
      case 'gym': { // heavy metal gate with a giant dumbbell on top
        posts(0x495057, 0.42, 2.4, 'shiny');
        for (const sx of [-1, 1]) for (const y of [0.4, 1.2, 2.0]) g.add(mesh(sphG(0.05, 5, 4), C(0xced4da, 'shiny'), sx * GATE_HW, y, 0.22));
        box(3.1, 0.3, 0.45, 0x343a40, 0, 2.5, 0, 'shiny');
        const bar = mesh(cylG(0.07, 0.07, 2.4, 8), C(0xced4da, 'shiny'), 0, 2.95, 0); bar.rotation.z = Math.PI / 2; g.add(bar);
        for (const sx of [-1, 1]) for (const [r, off] of [[0.55, 0], [0.42, 0.16]]) { const p = mesh(cylG(r, r, 0.14, 14), C(r > 0.5 ? 0x212529 : 0x5c7cfa), sx * (0.95 + off), 2.95, 0); p.rotation.z = Math.PI / 2; g.add(p); }
        break;
      }
      case 'hoops': { // arch with a hoop and backboard on top
        posts(0x7048e8, 0.3, 2.4);
        box(3.0, 0.3, 0.3, 0x5f3dc4, 0, 2.5, 0);
        box(1.3, 0.85, 0.08, 0xffffff, 0, 3.15, 0, 'shiny'); box(0.5, 0.35, 0.09, 0xfa5252, 0, 3.0, 0.01);
        const rim = mesh(GEO('grim', () => new THREE.TorusGeometry(0.28, 0.035, 4, 16)), C(0xff922b, 'shiny'), 0, 2.85, 0.32); rim.rotation.x = Math.PI / 2; g.add(rim);
        g.add(mesh(GEO('gnet2', () => new THREE.CylinderGeometry(0.28, 0.18, 0.35, 10, 1, true)), GEO('netmat2', () => new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.7 })), 0, 2.66, 0.32));
        if (!locked) { const b = SK.bballMesh(0.18); b.position.set(0.55, 2.85, 0.2); g.add(b); fx.ball = b; }
        break;
      }
      default: { // stadium: big arch with floodlights
        posts(0xf59f00, 0.34, 2.6);
        box(3.2, 0.42, 0.4, 0xffd43b, 0, 2.75, 0);
        for (const sx of [-1, 1]) { box(0.08, 1.0, 0.08, 0x868e96, sx * GATE_HW, 3.4, 0); box(0.6, 0.35, 0.12, 0xffffff, sx * GATE_HW, 3.95, 0.02, locked ? null : 'hot'); }
      }
    }
    // doors: two barred gates hinged on the posts (closed while locked)
    const doorCol = locked ? 0x868e96 : new THREE.Color(ZONES[i].shirt).getHex();
    const doors = [-1, 1].map((sx) => {
      const d = new THREE.Group(); d.position.set(sx * (GATE_HW - 0.1), 0, 0.06); g.add(d);
      const w = GATE_HW - 0.12;
      d.add(BX(w, 0.08, 0.06, M(doorCol), -sx * w / 2, 1.5, 0), BX(w, 0.08, 0.06, M(doorCol), -sx * w / 2, 0.25, 0));
      for (let k = 1; k <= 4; k++) d.add(BX(0.05, 1.35, 0.05, M(doorCol), -sx * (k * w) / 4.4, 0.85, 0));
      return d;
    });
    if (locked) { // lock + price on the closed gate
      const Z = ZONES[i], need = Z.need > titleCount();
      const tag = spr(labelTex(need ? `${Z.need} title${Z.need > 1 ? 's' : ''}` : fmt(Z.cost), '#868e96', 'lock'), 1.6, 0.4, 9); tag.position.set(0, 1.95, 0.1); g.add(tag);
      fx.tag = tag; fx.tagNeed = need;
    }
    if (!built.cols['gate' + i]) { built.cols['gate' + i] = 1; for (const sx of [-1, 1]) addCol(GATE_X + sx * GATE_HW, z0, 0.2, 0.2); }
    world.add(g);
    const e = (entrances[i] = { g, doors, open: locked ? 0 : 1, target: locked ? 0 : 1, fx, locked });
    setDoors(e);
    return e;
  }
  const setDoors = (e) => e.doors.forEach((d, k) => (d.rotation.y = (k ? -1 : 1) * e.open * 1.75));
  // unlocking a zone: the gate swings open with confetti and a fanfare
  function openEntrance(i) {
    const e = buildEntrance(i, false);
    e.open = 0; e.target = 1; setDoors(e);
    const z0 = zoneZ(i) + 4.85;
    setTimeout(() => { confetti(GATE_X, 2.2, z0, 40); Snd.play('level'); }, 200);
    Snd.play('tier');
  }
  // MAIN GATE: simple fence -> stone gate -> glowing stadium entrance, as the academy grows
  let mainGate = null, mainTier = -1;
  const gateTier = () => { const n = S.zones.filter((z) => z.unlocked).length; return n >= 5 ? 2 : n >= 3 ? 1 : 0; };
  function buildMainGate(tier, celebrate) {
    if (mainGate) world.remove(mainGate.g);
    const g = new THREE.Group(); g.position.set(0, 0.12, 16.95);
    const fx = { glow: [], water: null };
    const P2 = 1.75;
    if (tier === 0) { // wooden posts, plank sign, picket fence
      for (const sx of [-1, 1]) { g.add(B(0.3, 2.6, 0.3, 0x8d5524, sx * P2, 1.3, 0)); g.add(mesh(GEO('cap0', () => new THREE.ConeGeometry(0.24, 0.3, 4)), M(0x5c4a3d), sx * P2, 2.75, 0)); }
      g.add(B(3.8, 0.45, 0.12, 0xd9a066, 0, 2.35, 0.1));
      for (let x = 2.1; x <= 6.4; x += 0.38) for (const sx of [-1, 1]) g.add(B(0.12, 0.7, 0.06, 0xf1e3c8, sx * x, 0.35, 0));
      for (const sx of [-1, 1]) for (const y of [0.25, 0.55]) g.add(B(4.4, 0.07, 0.05, 0xd9a066, sx * 4.25, y, -0.04));
    } else if (tier === 1) { // stone gate with flags
      for (const sx of [-1, 1]) {
        g.add(B(0.75, 3.1, 0.75, 0xadb5bd, sx * P2, 1.55, 0), B(0.9, 0.2, 0.9, 0xced4da, sx * P2, 3.15, 0), B(0.9, 0.25, 0.9, 0x868e96, sx * P2, 0.12, 0));
        for (let k = 0; k < 4; k++) g.add(B(0.77, 0.03, 0.77, 0x868e96, sx * P2, 0.6 + k * 0.65, 0));
        g.add(mesh(cylG(0.04, 0.04, 1.6, 6), M(0xdee2e6, 'shiny'), sx * P2, 4.0, 0));
        const flag = B(0.75, 0.48, 0.03, sx < 0 ? 0xffa94d : 0xff6b9a, sx * P2 + 0.38, 4.5, 0); g.add(flag); fx.glow.push({ flag, ph: sx });
        g.add(B(4.3, 0.7, 0.55, 0xadb5bd, sx * 4.35, 0.35, 0), B(4.3, 0.12, 0.6, 0xced4da, sx * 4.35, 0.75, 0));
      }
      const arch = mesh(GEO('sarch', () => new THREE.TorusGeometry(1.4, 0.2, 6, 16, Math.PI)), M(0xced4da), 0, 2.4, 0); g.add(arch);
      g.add(B(4.2, 0.5, 0.6, 0x868e96, 0, 3.05, 0));
    } else { // glowing stadium entrance
      for (const sx of [-1, 1]) {
        g.add(B(0.8, 4.0, 0.8, 0xf8f9fa, sx * P2, 2.0, 0, 'shiny'));
        for (const y of [0.9, 1.9, 2.9]) { const b = BX(0.84, 0.14, 0.84, M(0xffa94d, 'hot'), sx * P2, y, 0); g.add(b); fx.glow.push({ band: b }); }
        // floodlight towers
        g.add(B(0.14, 5.2, 0.14, 0x868e96, sx * 5.6, 2.6, 0.4));
        const pan = BX(1.0, 0.6, 0.15, M(0xfff9db, 'hot'), sx * 5.6, 5.2, 0.4); pan.rotation.x = 0.4; g.add(pan);
        const glow = spr(PTEX.glow, 2.6, 2.6, 4); glow.position.set(sx * 5.6, 5.2, 0.6); glow.material.blending = THREE.AdditiveBlending; g.add(glow);
        for (const fxk of [-0.6, 0.6]) { const flag = B(0.6, 0.4, 0.03, fxk < 0 ? 0xffa94d : 0xff6b9a, sx * (P2 + 1.6) + fxk, 2.6, 0); g.add(mesh(cylG(0.03, 0.03, 2.8, 6), M(0xdee2e6), sx * (P2 + 1.6) + fxk - 0.3, 1.4, 0), flag); fx.glow.push({ flag, ph: fxk + sx }); }
        g.add(B(4.0, 0.8, 0.6, 0xdee2e6, sx * 4.4, 0.4, 0, 'shiny'), B(4.0, 0.08, 0.62, 0xff6b9a, sx * 4.4, 0.75, 0, 'hot'));
      }
      const arch = mesh(GEO('garch', () => new THREE.TorusGeometry(1.75, 0.22, 6, 20, Math.PI)), M(0xffd43b, 'gold'), 0, 3.2, 0); g.add(arch);
      const lights = mesh(GEO('garch2', () => new THREE.TorusGeometry(1.75, 0.08, 4, 20, Math.PI)), M(0xffe066, 'hot'), 0, 3.2, 0.2); g.add(lights); fx.glow.push({ band: lights });
      g.add(B(4.4, 0.55, 0.7, 0xffa94d, 0, 4.0, 0, 'shiny'));
    }
    // sign + logo on the arch
    const sign = spr(labelTex('ATHLETE TYCOON', '#ff6b9a', 'star'), 3.9, 0.98, 8); sign.position.set(0, tier === 2 ? 4.45 : tier === 1 ? 3.55 : 2.95, 0.3); g.add(sign);
    const logo = spr(bubbleTex('star'), 0.8, 0.88, 8); logo.position.set(0, tier === 2 ? 5.3 : tier === 1 ? 4.35 : 3.75, 0.3); g.add(logo); fx.logo = logo;
    // flower beds, lamps, a fountain (and a statue once the gate is stone)
    for (const sx of [-1, 1]) {
      g.add(B(1.9, 0.22, 0.6, 0x8d5524, sx * 3.3, 0.11, 0.75));
      for (let k = 0; k < 6; k++) g.add(mesh(sphG(0.13, 6, 4), M([0xff6b9a, 0xffd43b, 0xffffff, 0xbe4bdb][(k + (sx > 0 ? 2 : 0)) % 4]), sx * 3.3 - 0.8 + k * 0.32, 0.3, 0.75 + (k % 2 ? 0.12 : -0.12)));
      g.add(mesh(cylG(0.05, 0.07, 2.0, 6), M(tier ? 0x212529 : 0x5c4a3d), sx * 2.35, 1.0, 0.8));
      const bulb = mesh(sphG(0.17, 8, 6), M(0xfff3bf, 'hot'), sx * 2.35, 2.05, 0.8); g.add(bulb);
    }
    const fnt = new THREE.Group(); fnt.position.set(-5.0, 0, 1.75); g.add(fnt);
    fnt.add(mesh(cylG(0.8, 0.9, 0.35, 14), M(tier ? 0xced4da : 0xadb5bd), 0, 0.17, 0), mesh(cylG(0.68, 0.68, 0.05, 14), M(0x4dabf7, 'shiny'), 0, 0.33, 0));
    fnt.add(mesh(cylG(0.08, 0.12, 0.7, 8), M(0xced4da), 0, 0.6, 0));
    fx.water = mesh(GEO('jet', () => new THREE.ConeGeometry(0.28, 0.5, 10, 1, true)), GEO('jetm', () => new THREE.MeshBasicMaterial({ color: 0xa5d8ff, transparent: true, opacity: 0.7, depthWrite: false })), 0, 1.15, 0);
    fx.water.rotation.x = Math.PI; fnt.add(fx.water);
    if (tier >= 1) {
      const ped = new THREE.Group(); ped.position.set(5.0, 0, 1.75); g.add(ped);
      ped.add(B(0.9, 0.7, 0.9, 0xdee2e6, 0, 0.35, 0));
      const st = SK.figure({ shirt: 0, shorts: 0, skin: 0, bald: true, scale: 0.8 });
      st.traverse((o) => { if (o.isMesh && o.material && !o.material.transparent) o.material = tier === 2 ? M(0, 'gold') : M(0xced4da); });
      st.position.y = 0.7; st.userData.armR.rotation.z = 2.6; ped.add(st);
    }
    world.add(g);
    mainGate = { g, fx, tier };
    if (celebrate) { confetti(0, 2.5, 17, 50); Snd.play('tier'); toast(`${ico('gate')} The academy entrance got an upgrade!`, 2600); }
  }
  function updateEntrances(dt) {
    for (const k in entrances) {
      const e = entrances[k];
      if (e.open !== e.target) { e.open += Math.sign(e.target - e.open) * Math.min(Math.abs(e.target - e.open), dt * 1.1); setDoors(e); }
      if (e.fx.splash && Math.random() < dt * 3) emit('wave', GATE_X + rand(-1.6, 1.6), rand(1.2, 3.2), e.g.position.z + 0.2, 0.7, 0.6);
      if (e.fx.spots) e.fx.spots.forEach((l, j) => (l.rotation.z = (j ? -1 : 1) * (0.35 + Math.sin(time * 1.4 + j) * 0.25)));
      if (e.fx.ball) { e.fx.ball.position.y = 2.85 + Math.abs(Math.sin(time * 3)) * 0.5; e.fx.ball.rotation.x += dt * 5; }
      if (e.fx.tag) e.fx.tag.position.y = 1.95 + Math.sin(time * 3) * 0.05;
    }
    if (mainGate) {
      const f = mainGate.fx;
      if (f.water) f.water.scale.set(1, 1 + Math.sin(time * 6) * 0.12, 1);
      for (const o of f.glow) { if (o.flag) o.flag.rotation.y = Math.sin(time * 2.5 + o.ph) * 0.25; }
      if (f.logo) f.logo.position.y += Math.sin(time * 2) * 0.002;
    }
  }

  // EQUIPMENT STYLE follows the zone's upgrades: 0 = old (wood, worn), 1 = modern (chrome, bright), 2 = golden
  const zoneStyle = (i) => (S.zones[i].stations >= 4 ? 2 : S.zones[i].stations >= 3 ? 1 : 0);
  function styleMats(lvl, bright) {
    if (lvl === 2) return { frame: M(0, 'gold'), accent: M(0, 'gold'), dark: M(0x5c3d00, 'shiny'), bright: M(0, 'gold') };
    if (lvl === 1) return { frame: M(0xdee2e6, 'shiny'), accent: M(bright, 'shiny'), dark: M(0x343a40, 'shiny'), bright: M(bright, 'shiny') };
    return { frame: M(0xb07a45), accent: M(new THREE.Color(bright).lerp(new THREE.Color(0xc9b8a6), 0.55).getHex()), dark: M(0x5c4a3d), bright: M(0xd9a066) };
  }
  const BX = (w, h, d, mat, x, y, z) => mesh(boxG(w, h, d), mat, x, y, z);
  function hurdle(st, w = 1.2) {
    const g = new THREE.Group();
    g.add(BX(0.07, 0.75, 0.07, st.frame, -w / 2, 0.375, 0), BX(0.07, 0.75, 0.07, st.frame, w / 2, 0.375, 0));
    g.add(BX(0.3, 0.05, 0.4, st.frame, -w / 2, 0.025, 0.12), BX(0.3, 0.05, 0.4, st.frame, w / 2, 0.025, 0.12));
    g.add(BX(w + 0.08, 0.16, 0.06, st.accent, 0, 0.72, 0));
    if (st.stripe) g.add(BX(0.18, 0.165, 0.065, st.stripe, 0, 0.72, 0));
    return g;
  }
  // TRAINING STATIONS: one builder per discipline. The athlete stands at the origin; equipment sits mostly behind (-z).
  // userData.tick(dt, ph, on) animates props in sync with the athlete's training pose (ph = the athlete's anim phase).
  const TAU = Math.PI * 2;
  const cycOf = (ph, kind) => SK.cyc({ ph }, SK.RATE[kind] || 1);
  const lane = (g, lvl, col, len = 2.0, z = -0.35) => g.add(BX(1.0, 0.03, len, lvl === 0 ? M(new THREE.Color(col).lerp(new THREE.Color(0xc9b8a6), 0.4).getHex()) : lvl === 1 ? M(col) : M(0xffd43b, 'shiny'), 0, 0.015, z));
  const ballMesh = (kind) => (kind === 'b' ? SK.bballMesh(0.13) : (() => { const b = new THREE.Group(); b.add(mesh(GEO('ico', () => new THREE.IcosahedronGeometry(0.17, 0)), M(0xffffff))); b.add(mesh(GEO('ico2', () => new THREE.DodecahedronGeometry(0.155, 0)), M(0x212529))); b.scale.setScalar(0.8); return b; })());
  function hoopRig(g, st, lvl, z, rimY = 2.0) { // pole + backboard + rim + net, facing +z
    g.add(BX(0.12, rimY + 0.5, 0.12, st.frame, 0, (rimY + 0.5) / 2, z - 0.35));
    g.add(BX(0.9, 0.6, 0.05, lvl === 2 ? M(0, 'gold') : M(0xffffff, lvl ? 'shiny' : null), 0, rimY + 0.25, z - 0.25));
    g.add(BX(0.34, 0.26, 0.055, M(0xfa5252), 0, rimY + 0.15, z - 0.24));
    const rim = mesh(GEO('rim', () => new THREE.TorusGeometry(0.2, 0.025, 4, 14)), lvl === 2 ? M(0, 'gold') : M(0xfa5252, 'shiny'), 0, rimY, z); rim.rotation.x = Math.PI / 2; g.add(rim);
    g.add(mesh(GEO('net', () => new THREE.CylinderGeometry(0.2, 0.13, 0.3, 10, 1, true)), GEO('netmat2', () => new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.7 })), 0, rimY - 0.16, z));
  }
  function makeStationMesh(id, x, z, lvl = 0, noCol = false) {
    const g = new THREE.Group(), u = g.userData;
    const col = (...a) => { if (!noCol) addCol(...a); };
    switch (id) {
      // ---------- TRACK ----------
      case 'sprint': { // lane, starting blocks, timing gate
        const st = styleMats(lvl, 0xfa5252); lane(g, lvl, 0xd9480f);
        const sb = new THREE.Group(); sb.position.set(0.3, 0, 0.3);
        sb.add(BX(0.1, 0.04, 0.5, st.dark, 0, 0.02, 0));
        for (const [bx, bz] of [[-0.09, -0.1], [0.09, 0.12]]) { const p = BX(0.15, 0.05, 0.13, st.bright, bx, 0.09, bz); p.rotation.x = -0.7; sb.add(p); }
        g.add(sb);
        for (const sx of [-0.55, 0.55]) g.add(BX(0.07, 1.1, 0.07, st.frame, sx, 0.55, -1.25));
        g.add(BX(1.17, 0.1, 0.08, st.accent, 0, 1.12, -1.25), BX(0.3, 0.16, 0.05, M(0x212529), 0, 1.3, -1.25));
        col(x, z - 1.25, 0.6, 0.1);
        break;
      }
      case 'hurdles': {
        const st = styleMats(lvl, 0xfa5252); st.stripe = lvl === 0 ? null : M(0xffffff, lvl === 2 ? 'shiny' : null); lane(g, lvl, 0xd9480f, 2.4, -0.6);
        for (const hz of [-0.75, -1.55]) { const h = hurdle(st, 1.0); h.position.z = hz; h.scale.setScalar(0.85); g.add(h); }
        col(x, z - 1.15, 0.6, 0.5);
        break;
      }
      case 'longjump': { // runway, take-off board, sand pit
        const st = styleMats(lvl, 0xfab005); lane(g, lvl, 0xd9480f, 1.2, 0.1);
        g.add(BX(1.0, 0.035, 0.14, M(0xffffff), 0, 0.02, -0.5));
        g.add(BX(1.4, 0.06, 1.2, lvl === 2 ? M(0xffe066, 'shiny') : M(0xf3d9a4), 0, 0.03, -1.25), BX(1.5, 0.08, 0.08, st.frame, 0, 0.04, -1.88));
        for (let k = 0; k < 3; k++) g.add(mesh(sphG(0.09, 6, 4), M(0xe6c98a), -0.4 + k * 0.35, 0.06, -1.1 - (k % 2) * 0.3));
        const rake = new THREE.Group(); rake.position.set(0.75, 0, -1.6);
        rake.add(BX(0.03, 0.03, 0.9, st.frame, 0, 0.45, 0)); rake.children[0].rotation.x = 0.9; rake.add(BX(0.3, 0.05, 0.05, st.dark, 0, 0.1, -0.3));
        g.add(rake);
        u.puff = mesh(sphG(0.25, 8, 5), GEO('sandmat', () => new THREE.MeshBasicMaterial({ color: 0xf3d9a4, transparent: true, opacity: 0.6, depthWrite: false })), 0, 0.15, -1.15);
        u.puff.visible = false; g.add(u.puff);
        u.tick = (dt, ph, on) => { const f = cycOf(ph, 'longjump'); u.puff.visible = on && f > 0.8; if (u.puff.visible) u.puff.scale.setScalar(0.5 + (f - 0.8) * 6); };
        break;
      }
      case 'relay': { // exchange zone with baton stand
        const st = styleMats(lvl, 0xfab005); lane(g, lvl, 0xe8590c, 2.2, -0.45);
        for (const tz of [-0.2, -1.2]) { const t = mesh(GEO('tri', () => new THREE.CircleGeometry(0.18, 3)), M(0xffd43b, true), 0, 0.035, tz); t.rotation.x = -Math.PI / 2; t.rotation.z = Math.PI / 2; g.add(t); }
        g.add(mesh(cylG(0.05, 0.12, 0.7, 8), st.frame, 0.72, 0.35, -1.25));
        const bt = mesh(cylG(0.05, 0.05, 0.38, 8), lvl === 2 ? M(0, 'gold') : M(0xfab005, 'shiny'), 0.72, 0.85, -1.25); g.add(bt);
        col(x + 0.72, z - 1.25, 0.15, 0.15);
        break;
      }
      // ---------- GYM ----------
      case 'bench': {
        const st = styleMats(lvl, 0x5c7cfa);
        g.add(BX(0.42, 0.12, 1.45, lvl === 0 ? M(0x8d5524) : st.accent, 0, 0.4, -0.85));
        for (const bz of [-0.3, -1.4]) g.add(BX(0.32, 0.36, 0.1, st.frame, 0, 0.18, bz));
        for (const sx of [-0.5, 0.5]) g.add(BX(0.07, 1.0, 0.07, st.frame, sx, 0.5, -1.35));
        const bar = new THREE.Group(); bar.position.set(0, 1.0, -1.25);
        const rod = mesh(cylG(0.03, 0.03, 1.5, 6), lvl === 2 ? M(0, 'gold') : M(0xced4da, 'shiny')); rod.rotation.z = Math.PI / 2; bar.add(rod);
        for (const px of [-0.62, 0.62]) { const p = mesh(cylG(0.22, 0.22, 0.07, 12), st.dark); p.position.x = px; p.rotation.z = Math.PI / 2; bar.add(p); }
        g.add(bar); u.bar = bar;
        u.tick = (dt, ph, on) => { if (on) { bar.position.set(0, 1.1 + Math.max(0, Math.sin(ph)) * 0.2, -1.05); } else bar.position.set(0, 1.0, -1.35); };
        col(x, z - 0.9, 0.55, 0.6);
        break;
      }
      case 'squat': {
        const st = styleMats(lvl, 0x5c7cfa);
        g.add(BX(1.6, 0.05, 1.0, lvl === 0 ? M(0x8d5524) : M(0x212529), 0, 0.025, -0.25));
        for (const sx of [-0.72, 0.72]) { g.add(BX(0.09, 1.75, 0.09, st.frame, sx, 0.88, -0.75)); g.add(BX(0.16, 0.05, 0.16, st.accent, sx, 1.2, -0.68)); }
        g.add(BX(1.53, 0.08, 0.08, st.frame, 0, 1.75, -0.75));
        const bar = new THREE.Group();
        const rod = mesh(cylG(0.03, 0.03, 1.7, 6), lvl === 2 ? M(0, 'gold') : M(0xced4da, 'shiny')); rod.rotation.z = Math.PI / 2; bar.add(rod);
        for (const px of [-0.66, 0.66]) { const p = mesh(cylG(0.25, 0.25, 0.08, 12), lvl === 1 ? M(0xe03131, 'shiny') : st.dark); p.position.x = px; p.rotation.z = Math.PI / 2; bar.add(p); }
        g.add(bar);
        u.tick = (dt, ph, on) => { if (on) { const k = (1 - Math.cos(ph * 0.5)) / 2; bar.position.set(0, 1.18 - k * 0.29, -0.1); } else bar.position.set(0, 1.26, -0.68); };
        col(x, z - 0.75, 0.8, 0.1);
        break;
      }
      case 'tread': { // the athlete runs on the belt
        const st = styleMats(lvl, 0x5c7cfa);
        g.add(BX(0.8, 0.12, 1.7, lvl === 0 ? M(0x868e96) : M(0x343a40), 0, 0.06, -0.15));
        const belt = new THREE.Group(); g.add(belt);
        for (let k = 0; k < 6; k++) belt.add(BX(0.62, 0.015, 0.05, M(0x5c5f66), 0, 0.125, -0.9 + k * 0.3));
        for (const sx of [-0.42, 0.42]) { g.add(BX(0.05, 0.85, 0.05, st.frame, sx, 0.5, 0.55)); g.add(BX(0.05, 0.05, 0.6, st.frame, sx, 0.92, 0.3)); }
        g.add(BX(0.7, 0.3, 0.1, st.accent, 0, 1.0, 0.6), BX(0.4, 0.15, 0.02, M(0x69db7c, true), 0, 1.02, 0.66));
        u.tick = (dt, ph, on) => { if (on) belt.children.forEach((b) => { b.position.z -= dt * 2.4; if (b.position.z < -0.9) b.position.z += 1.8; }); };
        col(x, z - 0.15, 0.42, 0.85);
        break;
      }
      case 'row': {
        const st = styleMats(lvl, 0x5c7cfa);
        g.add(BX(0.18, 0.12, 2.0, st.frame, 0, 0.12, 0.2));
        const fly = mesh(cylG(0.28, 0.28, 0.16, 12), st.accent, 0, 0.35, 1.15); fly.rotation.z = Math.PI / 2; g.add(fly);
        g.add(BX(0.45, 0.05, 0.12, st.dark, 0, 0.2, 0.78));
        const seat = BX(0.3, 0.07, 0.3, lvl === 0 ? M(0x5c4a3d) : M(0x212529), 0, 0.22, -0.1); g.add(seat);
        u.tick = (dt, ph, on) => { if (on) { seat.position.z = -0.1 - (1 + Math.sin(ph * 0.45)) * 0.12; fly.rotation.x += dt * 6; } };
        col(x, z + 1.15, 0.3, 0.2);
        break;
      }
      // ---------- FOOTBALL ----------
      case 'dribble': {
        const st = styleMats(lvl, 0xff922b);
        for (let k = 0; k < 5; k++) g.add(mesh(GEO('cone', () => new THREE.ConeGeometry(0.14, 0.32, 6)), lvl === 2 ? M(0, 'gold') : lvl === 1 ? M(0xff922b, 'shiny') : M(0xd9a066), (k % 2 ? 0.35 : -0.35), 0.16, -0.45 - k * 0.32));
        g.add(BX(0.9, 0.01, 1.8, M(0x74c69d), 0, 0.006, -1.0));
        break;
      }
      case 'pass': { // rebound wall, the ball goes back and forth
        const st = styleMats(lvl, 0xffffff);
        g.add(BX(1.7, 0.75, 0.12, lvl === 0 ? M(0xb07a45) : lvl === 1 ? M(0xffffff, 'shiny') : M(0, 'gold'), 0, 0.38, -1.45));
        g.add(BX(1.8, 0.07, 0.4, st.frame, 0, 0.04, -1.35));
        g.add(BX(0.5, 0.3, 0.13, M(0x37b24d), 0, 0.38, -1.4));
        const ball = ballMesh(); g.add(ball);
        u.tick = (dt, ph, on) => { ball.visible = on; if (on) { const k = Math.abs(Math.sin(ph * 0.25 + 0.4)); ball.position.set(0.12, 0.14, -1.3 + (1 - k) * 1.55); ball.rotation.x += dt * 9; } };
        col(x, z - 1.45, 0.9, 0.1);
        break;
      }
      case 'shoot': { // small goal, shots fly into the net
        const post = lvl === 0 ? M(0xb07a45) : lvl === 1 ? M(0xffffff, 'shiny') : M(0, 'gold');
        g.add(BX(0.09, 0.95, 0.09, post, -0.85, 0.47, -1.5), BX(0.09, 0.95, 0.09, post, 0.85, 0.47, -1.5), BX(1.79, 0.09, 0.09, post, 0, 0.93, -1.5));
        g.add(mesh(boxG(1.7, 0.9, 0.02), GEO('netmat', () => new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 })), 0, 0.45, -1.95));
        g.add(BX(0.05, 0.05, 0.5, post, -0.85, 0.9, -1.75), BX(0.05, 0.05, 0.5, post, 0.85, 0.9, -1.75));
        const ball = ballMesh(); g.add(ball);
        u.tick = (dt, ph, on) => { const f = cycOf(ph, 'shoot'); const k = on && f > 0.42 ? Math.min(1, (f - 0.42) / 0.2) : 0; ball.position.set(0.2 + k * 0.25, 0.14 + Math.sin(k * Math.PI) * 0.5 + k * 0.25, 0.3 - k * 2.1); ball.visible = on; };
        col(x, z - 1.6, 0.9, 0.3);
        break;
      }
      case 'header': { // pendulum ball on a gallows frame
        const st = styleMats(lvl, 0xffffff);
        g.add(BX(0.09, 2.4, 0.09, st.frame, 0.75, 1.2, -0.3), BX(0.85, 0.08, 0.08, st.frame, 0.37, 2.38, -0.3), BX(0.5, 0.06, 0.5, st.dark, 0.75, 0.03, -0.3));
        const pend = new THREE.Group(); pend.position.set(0, 2.36, -0.3); g.add(pend);
        pend.add(mesh(cylG(0.012, 0.012, 0.55, 4), M(0x868e96), 0, -0.27, 0));
        const ball = ballMesh(); ball.position.y = -0.62; pend.add(ball);
        u.tick = (dt, ph, on) => { pend.rotation.x = on ? Math.sin(cycOf(ph, 'header') * TAU + 1.6) * 0.45 : Math.sin(time * 1.3) * 0.05; };
        col(x + 0.75, z - 0.3, 0.12, 0.12);
        break;
      }
      // ---------- POOL ----------
      case 'free': case 'fly': case 'under': {
        const st = styleMats(lvl, 0x15aabf);
        g.add(BX(0.62, 0.45, 0.55, lvl === 0 ? M(0xe9ecef) : lvl === 1 ? M(0xffffff, 'shiny') : M(0, 'gold'), 0, 0.22, -1.55));
        const top = BX(0.56, 0.07, 0.48, st.accent, 0, 0.47, -1.52); top.rotation.x = 0.12; g.add(top);
        g.add(mesh(GEO('plate', () => new THREE.PlaneGeometry(0.3, 0.3)), new THREE.MeshBasicMaterial({ map: SK_NUM(lvl), transparent: true }), 0, 0.3, -1.27));
        if (id === 'under') g.add(BX(0.95, 0.02, 2.4, M(0x1864ab), 0, 0.012, -0.1));
        if (id === 'fly') g.add(mesh(GEO('flag', () => new THREE.ConeGeometry(0.1, 0.22, 3)), M(0xfa5252), 0.38, 0.6, -1.6));
        const bub = []; // bubbles / splashes behind the swimmer
        for (let k = 0; k < 3; k++) { const b = mesh(sphG(0.06, 6, 4), M(0xe7f5ff), 0, 0.2, 0); b.visible = false; g.add(b); bub.push(b); }
        u.tick = (dt, ph, on) => bub.forEach((b, k) => { b.visible = on; if (on) { const t = (time * (id === 'under' ? 0.8 : 2) + k / 3) % 1; b.position.set(Math.sin(k * 2.1) * 0.2, 0.15 + t * (id === 'under' ? 0.25 : 0.12), -0.6 - t * 0.6); b.scale.setScalar(1 - t * 0.6); } });
        col(x, z - 1.55, 0.33, 0.3);
        break;
      }
      case 'dive': { // diving board over the water
        const st = styleMats(lvl, 0x15aabf);
        g.add(BX(0.5, 0.55, 0.5, st.frame, 0, 0.27, -1.6));
        const board = new THREE.Group(); board.position.set(0, 0.56, -1.4); g.add(board);
        board.add(BX(0.5, 0.06, 1.55, lvl === 0 ? M(0xd9a066) : lvl === 1 ? M(0x4dabf7, 'shiny') : M(0, 'gold'), 0, 0, 0.75));
        for (const sx of [-0.3, 0.3]) g.add(BX(0.04, 0.6, 0.04, M(0xdee2e6, 'shiny'), sx, 0.85, -1.7));
        const ring = mesh(GEO('splash', () => new THREE.RingGeometry(0.2, 0.32, 16)), GEO('splashmat', () => new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, depthWrite: false })), 0, 0.17, 1.0);
        ring.rotation.x = -Math.PI / 2; ring.visible = false; g.add(ring);
        u.tick = (dt, ph, on) => {
          const f = cycOf(ph, 'dive');
          board.rotation.x = on && f < 0.45 ? -Math.abs(Math.sin(f * 3 * Math.PI)) * 0.08 : 0;
          ring.visible = on && f > 0.75; if (ring.visible) { const k = (f - 0.75) / 0.25; ring.scale.setScalar(1 + k * 2.5); ring.material.opacity = 0.8 * (1 - k); }
        };
        col(x, z - 1.6, 0.3, 0.3);
        break;
      }
      // ---------- BOXING ----------
      case 'bag': {
        const st = styleMats(lvl, 0xc92a2a);
        g.add(BX(0.12, 2.2, 0.12, st.frame, 0.65, 1.1, -1.0), BX(0.78, 0.08, 0.08, st.frame, 0.3, 2.15, -1.0));
        const bag = new THREE.Group(); bag.position.set(0, 2.1, -1.0);
        bag.add(mesh(cylG(0.015, 0.015, 0.3, 4), M(0x868e96), 0, -0.15, 0));
        const leather = lvl === 0 ? M(0x8d5524) : lvl === 1 ? M(0xc92a2a, 'shiny') : M(0, 'gold');
        bag.add(mesh(cylG(0.26, 0.26, 0.95, 10), leather, 0, -0.78, 0));
        for (const by of [-0.6, -0.98]) bag.add(mesh(cylG(0.27, 0.27, 0.08, 10), lvl === 0 ? M(0xadb5bd) : lvl === 1 ? M(0xffffff) : M(0xc92a2a, 'shiny'), 0, by, 0));
        g.add(bag);
        u.tick = (dt, ph, on) => { bag.rotation.x = on ? -Math.abs(Math.sin(ph)) * 0.2 : bag.rotation.x * 0.9; };
        col(x + 0.3, z - 1.0, 0.45, 0.3);
        break;
      }
      case 'speedbag': {
        const st = styleMats(lvl, 0xc92a2a);
        g.add(BX(0.1, 2.3, 0.1, st.frame, 0, 1.15, -0.85), BX(0.8, 0.07, 0.6, lvl === 0 ? M(0x8d5524) : st.accent, 0, 2.05, -0.5));
        const bag = new THREE.Group(); bag.position.set(0, 2.0, -0.42); g.add(bag);
        const sb = mesh(sphG(0.13, 8, 6), lvl === 2 ? M(0, 'gold') : M(0xc92a2a, 'shiny'), 0, -0.2, 0); sb.scale.y = 1.3; bag.add(sb);
        u.tick = (dt, ph, on) => { bag.rotation.x = on ? Math.sin(ph * 4.4) * 0.9 : bag.rotation.x * 0.9; };
        col(x, z - 0.85, 0.12, 0.12);
        break;
      }
      case 'rope': { // skipping rope swings around the athlete
        const st = styleMats(lvl, 0xc92a2a);
        g.add(BX(1.3, 0.02, 1.3, lvl === 0 ? M(0x868e96) : M(0x343a40), 0, 0.01, 0));
        g.add(mesh(cylG(0.22, 0.22, 0.05, 10), st.accent, 0.95, 0.5, -0.9));
        for (const [lx, lz] of [[-0.12, -0.12], [0.12, -0.12], [-0.12, 0.12], [0.12, 0.12]]) g.add(BX(0.04, 0.5, 0.04, st.frame, 0.95 + lx, 0.25, -0.9 + lz));
        g.add(mesh(cylG(0.07, 0.08, 0.25, 8), M(0x4dabf7), 0.95, 0.65, -0.9));
        const rope = mesh(GEO('rope', () => new THREE.TorusGeometry(0.72, 0.018, 3, 22)), lvl === 2 ? M(0, 'gold') : M(0xfa5252, 'shiny'), 0, 0.88, 0);
        rope.rotation.y = Math.PI / 2; g.add(rope);
        u.tick = (dt, ph, on) => { rope.visible = on; if (on) rope.rotation.z = ph * SK.RATE.rope * 2 + Math.PI; };
        col(x + 0.95, z - 0.9, 0.2, 0.2);
        break;
      }
      case 'spar': { // mini ring with a sparring partner holding pads
        const st = styleMats(lvl, 0xc92a2a);
        g.add(BX(2.0, 0.06, 2.1, lvl === 2 ? M(0xfff3bf) : M(0xe7f5ff), 0, 0.03, -0.6));
        for (const [cx, cz] of [[-1, -1.65], [1, -1.65]]) g.add(BX(0.12, 1.1, 0.12, st.frame, cx, 0.55, cz));
        for (const y of [0.55, 0.85]) g.add(BX(2.0, 0.04, 0.04, lvl === 2 ? M(0, 'gold') : M(0xfa5252), 0, y, -1.65));
        const partner = SK.figure({ shirt: 0x343a40, shorts: 0x1c7ed6, skin: SKINS[2], cap: 0x1c7ed6, hands: 0x212529, scale: 0.85 });
        partner.position.set(0, 0.06, -1.05); g.add(partner);
        const pu = partner.userData; pu.armL.rotation.x = pu.armR.rotation.x = -1.5;
        u.tick = (dt, ph, on) => { const w = on ? Math.sin(ph * 0.35) : 0; partner.position.x = -w * 0.2; pu.body.rotation.y = w * 0.4; pu.armL.position.z = on ? Math.max(0, -Math.sin(ph)) * 0.12 : 0; pu.armR.position.z = on ? Math.max(0, Math.sin(ph)) * 0.12 : 0; };
        col(x, z - 1.65, 1.0, 0.1);
        break;
      }
      // ---------- BASKETBALL ----------
      case 'ft': case 'dunk': case 'layup': {
        const st = styleMats(lvl, 0x7048e8);
        hoopRig(g, st, lvl, -1.45, id === 'dunk' ? 1.85 : 2.0);
        if (id === 'ft') g.add(BX(1.0, 0.012, 0.07, M(0xffffff), 0, 0.012, 0.18));
        if (id === 'dunk') { const r = BX(0.7, 0.18, 0.7, lvl === 0 ? M(0x8d5524) : st.accent, 0, 0.05, -0.2); r.rotation.x = -0.12; g.add(r); }
        if (id === 'layup') for (const sx of [-0.45, 0.45]) g.add(mesh(GEO('cone', () => new THREE.ConeGeometry(0.14, 0.32, 6)), M(0xff922b), sx, 0.16, 0.25));
        const ball = SK.bballMesh(0.12); g.add(ball);
        const rimY = id === 'dunk' ? 1.85 : 2.0;
        u.tick = (dt, ph, on) => {
          ball.visible = on; if (!on) return;
          const f = cycOf(ph, id), rel = id === 'ft' ? 0.4 : id === 'dunk' ? 0.62 : 0.6;
          if (f < rel) ball.position.set(0.05, id === 'ft' ? 1.25 + f * 1.2 : 1.0, -0.15 - (id === 'ft' ? 0 : Math.max(0, f - 0.45) * 1.5));
          else if (f < rel + 0.25) { const k = (f - rel) / 0.25, y0 = id === 'ft' ? 1.75 : 1.9; ball.position.set(0, y0 + (rimY + 0.05 - y0) * k + Math.sin(k * Math.PI) * (id === 'ft' ? 0.9 : 0.2), -0.15 - k * 1.3); }
          else { const k = Math.min(1, (f - rel - 0.25) / 0.15); ball.position.set(0, rimY - k * 1.75, -1.45); }
          ball.rotation.x += dt * 8;
        };
        col(x, z - 1.8, 0.45, 0.15);
        break;
      }
      case 'bdribble': {
        for (let k = 0; k < 4; k++) g.add(mesh(GEO('cone', () => new THREE.ConeGeometry(0.14, 0.32, 6)), lvl === 2 ? M(0, 'gold') : M(0x7048e8, lvl ? 'shiny' : null), (k % 2 ? 0.4 : -0.4), 0.16, -0.5 - k * 0.38));
        g.add(BX(1.1, 0.012, 2.0, M(0xd9a066), 0, 0.008, -0.9));
        for (const lz of [-0.1, -1.8]) g.add(BX(1.1, 0.014, 0.05, M(0xffffff), 0, 0.012, lz));
        break;
      }
    }
    return g;
  }
  // lane numbers on the pool blocks
  const SK_NUM = (lvl) => ctex('lane' + lvl, 64, 64, (g) => { g.fillStyle = lvl === 2 ? '#7a4b00' : '#1864ab'; g.font = `900 46px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(lvl + 1), 32, 35); });
  // upgrading a zone (more stations) restyles all of its equipment
  function restyleZone(i) {
    const lvl = zoneStyle(i);
    if (built.style[i] === lvl) return;
    const first = built.style[i] == null;
    built.style[i] = lvl;
    for (const st of stations) {
      if (st.zone !== i) continue;
      const fresh = makeStationMesh(st.kind, st.pos.x, st.pos.z, lvl, true);
      fresh.position.copy(st.obj.position);
      world.remove(st.obj); st.obj = fresh; world.add(fresh);
      if (!first) bounce(fresh);
    }
    if (built.gear[i]) world.remove(built.gear[i]);
    built.gear[i] = zoneGear(i, lvl);
    if (!first) { confetti(0.7, 0.6, zoneZ(i), 18); toast(`${ico(ZONES[i].icon)} ${ZONES[i].name} equipment upgraded!`); }
  }
  // per-zone props that also follow the equipment style
  function zoneGear(i, lvl) {
    const Z = ZONES[i], g = new THREE.Group(); g.position.z = zoneZ(i);
    const st = styleMats(lvl, new THREE.Color(Z.shirt).getHex());
    const once = (k, fn) => { if (!built.cols[k]) { built.cols[k] = 1; fn(); } };
    switch (Z.id) {
      case 'track': {
        st.accent = styleMats(lvl, 0xfa5252).accent; st.stripe = lvl ? M(0xffffff) : null;
        for (const hz of [-2.6, 0, 2.6]) { const h = hurdle(st, 0.9); h.position.set(5.3, 0, hz); g.add(h); }
        once('trk' + i, () => { for (const hz of [-2.6, 0, 2.6]) addCol(5.3, zoneZ(i) + hz, 0.5, 0.12); });
        break;
      }
      case 'gym': { // dumbbell rack
        g.add(BX(0.5, 0.08, 2.0, st.frame, 5.4, 0.45, -2.8), BX(0.5, 0.08, 2.0, st.frame, 5.4, 0.85, -2.8));
        for (const zz of [-3.7, -1.9]) g.add(BX(0.06, 0.9, 0.06, st.frame, 5.4, 0.45, zz));
        for (let k = 0; k < 4; k++) for (const y of [0.55, 0.95]) { const d = makeItem('dumbbell'); d.rotation.y = Math.PI / 2; d.position.set(5.4, y - 0.04, -3.5 + k * 0.45); if (lvl === 2) d.traverse((o) => { if (o.isMesh) o.material = M(0, 'gold'); }); g.add(d); }
        once('gym' + i, () => addCol(5.4, zoneZ(i) - 2.8, 0.3, 1.0));
        break;
      }
      case 'football':
        for (const [fx, fz] of [[-6.0, -4.3], [6.0, -4.3], [6.0, 4.3]]) {
          g.add(BX(0.05, 1.0, 0.05, st.frame, fx, 0.5, fz));
          const fl = BX(0.02, 0.26, 0.34, lvl === 2 ? M(0, 'gold') : M(0xffd43b), fx, 0.87, fz + 0.17); g.add(fl);
        }
        break;
      case 'pool': // backstroke flags across the pool
        for (const fz of [-3.3]) {
          g.add(BX(0.06, 1.6, 0.06, st.frame, -3.5, 0.8, fz), BX(0.06, 1.6, 0.06, st.frame, 4.9, 0.8, fz), BX(8.4, 0.02, 0.02, M(0xffffff), 0.7, 1.55, fz));
          for (let k = 0; k < 14; k++) { const f = mesh(GEO('pen', () => new THREE.ConeGeometry(0.12, 0.24, 3)), M([0xfa5252, 0xffffff, 0x228be6][k % 3]), -3.1 + k * 0.58, 1.42, fz); f.rotation.x = Math.PI; g.add(f); }
        }
        break;
      case 'boxing': // corner stools
        for (const [sx, sz] of [[-2.25, 3.45], [3.65, -3.45]]) {
          g.add(mesh(cylG(0.25, 0.25, 0.07, 10), st.accent, sx, 0.52, sz));
          for (const [lx, lz] of [[-0.14, -0.14], [0.14, -0.14], [-0.14, 0.14], [0.14, 0.14]]) g.add(BX(0.04, 0.5, 0.04, st.frame, sx + lx, 0.25, sz + lz));
          g.add(mesh(cylG(0.1, 0.12, 0.25, 8), M(0x4dabf7), sx + 0.32, 0.12, sz));
        }
        break;
      case 'hoops': { // ball cart
        g.add(BX(0.9, 0.06, 0.55, st.frame, 5.3, 0.55, -3.0));
        for (const [cx, cz] of [[-0.4, -0.25], [0.4, -0.25], [-0.4, 0.25], [0.4, 0.25]]) g.add(BX(0.04, 0.55, 0.04, st.frame, 5.3 + cx, 0.28, -3.0 + cz));
        for (let k = 0; k < 6; k++) { const b = SK.bballMesh(0.13, lvl === 2); b.position.set(5.0 + (k % 3) * 0.3, 0.72 + Math.floor(k / 3) * 0.2, -3.08 + (Math.floor(k / 3) ? 0.1 : -0.05)); g.add(b); }
        once('bcart' + i, () => addCol(5.3, zoneZ(i) - 3.0, 0.5, 0.3));
        break;
      }
      case 'stadium':
        for (const hz of [-2.0, 1.2]) { st.stripe = lvl ? M(0xffffff) : null; const h = hurdle(st, 0.9); h.position.set(5.3, 0, hz); g.add(h); }
        once('std' + i, () => { for (const hz of [-2.0, 1.2]) addCol(5.3, zoneZ(i) + hz, 0.5, 0.12); });
        break;
    }
    world.add(g);
    return g;
  }

  // athletes face the equipment for these drills (back to the camera), and face the camera for the rest
  const FACE_EQUIP = new Set(['pass', 'shoot', 'header', 'bag', 'speedbag', 'spar', 'ft', 'dunk', 'layup']);
  function addStation(i, k) {
    const zc = zoneZ(i), [ox, oz] = STATION_OFF[k], D = discOf(i, k);
    const obj = makeStationMesh(D.id, ox, zc + oz, built.style[i] || 0); obj.position.set(ox, 0.12, zc + oz); world.add(obj);
    // the discipline's name is painted on the floor in front of it
    const label = mesh(GEO('dtag', () => new THREE.PlaneGeometry(1.75, 0.385)), new THREE.MeshBasicMaterial({ map: discTex(D), transparent: true, depthWrite: false }), ox, 0.168, zc + oz + 0.78);
    label.rotation.x = -Math.PI / 2; world.add(label);
    stations.push({ zone: i, idx: k, pos: new THREE.Vector3(ox, 0.12, zc + oz), obj, athlete: null, item: D.item, kind: D.id, disc: D, face: FACE_EQUIP.has(D.id) ? Math.PI : 0, label });
    obj.scale.setScalar(0.01);
    tween({ dur: 0.35, step: (q) => obj.scale.setScalar(Math.max(0.01, easeBack(q))) });
  }

  function newEnt(char, x, z) {
    const obj = new THREE.Group(); obj.position.set(x, 0.12, z); obj.add(char); world.add(obj);
    obj.userData.ent = true; // moves around: never merged into the static zone batches
    return { obj, char, moving: false };
  }

  // COACHES: hired helpers look like their sport's coach; lvl 1 assistant -> 2 head coach -> 3 legendary coach
  const COACH_CAP = [3, 5, 8], COACH_SPEED = [3.3, 4.2, 5.2];
  const COACH_SKIN = { track: 3, gym: 2, football: 1, swim: 0, boxing: 0, stadium: 4, hoops: 4 };
  const coachInfo = (i) => SK.COACHES[SK.coachSport(i)];
  // where the carried stack sits: in front (stack), in a net bag at the side (balls), or on the shoulder (weights)
  function setCarry(c, style) {
    c.carry = style;
    if (style === 'net') c.stackGroup.position.set(0.5, 0.95, 0.05);
    else if (style === 'shoulder') c.stackGroup.position.set(-0.36, 1.22, -0.05);
    else c.stackGroup.position.set(0, 0.85, -0.42);
    if (style === 'net' && !c.net) {
      c.net = mesh(GEO('netbag', () => new THREE.SphereGeometry(0.3, 8, 6)), GEO('netbagm', () => new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.55 })), 0, 0, 0);
      c.stackGroup.add(c.net);
    }
  }
  function buildCoachChar(i, lvl) {
    const sp = SK.coachSport(i);
    return SK.coach({ zone: i, lvl, skin: SKINS[COACH_SKIN[sp] || 0], hair: HAIRS[(i * 2) % HAIRS.length] });
  }
  const coachLabelTex = (i, lvl) => labelTex(`${lvl >= 2 ? (lvl >= 3 ? 'Legend ' : 'Head ') : ''}${coachInfo(i).name}`, lvl >= 3 ? '#fab005' : '#' + new THREE.Color(ZONES[i].shirt).getHexString(), lvl >= 3 ? 'crown' : lvl >= 2 ? 'star' : 'whistle');
  function addAssistant(i) {
    const zc = zoneZ(i), lvl = clamp(S.zones[i].assistants, 1, 3);
    const ch = buildCoachChar(i, lvl);
    const a = newEnt(ch, RACK_X + 1.2, zc + 1.2);
    a.zone = i; a.lvl = lvl; a.stack = []; a.stackMeshes = []; a.cap = COACH_CAP[lvl - 1]; a.speed = COACH_SPEED[lvl - 1]; a.pickT = 0; a.dropT = 0; a.target = new THREE.Vector3();
    a.stackGroup = new THREE.Group(); ch.userData.root.add(a.stackGroup); setCarry(a, coachInfo(i).carry);
    a.tag = spr(coachLabelTex(i, lvl), 1.75, 0.44, 8); a.tag.position.y = 2.35; a.obj.add(a.tag);
    a.shoutT = rand(4, 8);
    assistants.push(a);
    poof(a.obj.position);
    return a;
  }
  // promotion: swap in the better-dressed character, keep whatever they carry
  function promoteAssistant(a) {
    const lvl = clamp(S.zones[a.zone].assistants, 1, 3);
    if (lvl === a.lvl) return;
    a.lvl = lvl; a.cap = COACH_CAP[lvl - 1]; a.speed = COACH_SPEED[lvl - 1];
    const ch = buildCoachChar(a.zone, lvl), rot = a.char.rotation.y;
    a.char.userData.root.remove(a.stackGroup); a.obj.remove(a.char);
    a.char = ch; ch.rotation.y = rot; a.obj.add(ch); ch.userData.root.add(a.stackGroup);
    a.tag.material.map = coachLabelTex(a.zone, lvl);
    emit('ring', a.obj.position.x, 1.0, a.obj.position.z, 1.0, 0.9, 5); confetti(a.obj.position.x, 1.2, a.obj.position.z, 22);
    Snd.play('tier'); bounce(a.tag);
    toast(`${ico(lvl >= 3 ? 'crown' : 'star')} ${coachInfo(a.zone).name} is now a ${SK.RANKS[lvl - 1]}! Carries ${a.cap}, walks faster`, 2600);
  }

  function addRecep() {
    const ch = makeChar(0xbe4bdb, { hair: HAIRS[5], skin: SKINS[1] });
    recepEnt = newEnt(ch, RECEP_POS.x, RECEP_POS.z);
    recepEnt.char.rotation.y = Math.PI / 2;
    poof(recepEnt.obj.position);
  }

  const goldDumbbell = () => { const t = makeItem('dumbbell'); t.traverse((o) => { if (o.isMesh) o.material = M(0, 'gold'); }); return t; };
  // special prizes: European / World medals and the unique Diamond League trophy
  function makeMedal3D(kind) {
    const g = new THREE.Group();
    g.add(B(0.3, 0.08, 0.3, 0x5c3d2e, 0, 0.04, 0));
    g.add(B(0.05, 0.26, 0.05, 0x495057, 0, 0.2, 0));
    const disc = mesh(cylG(0.16, 0.16, 0.05, 14), M(kind === 'world' ? 0x4dabf7 : 0x3b5bdb, 'shiny'), 0, 0.42, 0); disc.rotation.x = Math.PI / 2; g.add(disc);
    const rim = mesh(GEO('mrim', () => new THREE.TorusGeometry(0.16, 0.025, 5, 16)), M(0, 'gold'), 0, 0.42, 0); g.add(rim);
    if (kind === 'world') g.add(mesh(sphG(0.09, 8, 6), M(0x69db7c), 0, 0.42, 0.03));
    else for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; g.add(mesh(sphG(0.025, 4, 3), M(0, 'gold'), Math.cos(a) * 0.09, 0.42 + Math.sin(a) * 0.09, 0.03)); }
    return g;
  }
  function makeDiamondTrophy() {
    const g = new THREE.Group();
    g.add(B(0.34, 0.1, 0.34, 0x212529, 0, 0.05, 0));
    g.add(mesh(cylG(0.05, 0.09, 0.18, 6), M(0xdee2e6, 'shiny'), 0, 0.19, 0));
    const gem = mesh(GEO('gem', () => new THREE.OctahedronGeometry(0.2, 0)), M(0x99e9f2, 'shiny'), 0, 0.5, 0);
    gem.scale.y = 1.3; gem.userData.spin = true; g.add(gem);
    return g;
  }
  function refreshTrophyHall() {
    while (trophyGroup.children.length) trophyGroup.remove(trophyGroup.children[0]);
    const list = [];
    for (let i = 0; i < (S.wallet.TROPHY_DIAMOND || 0); i++) list.push({ k: 'diamond' });
    for (let i = 0; i < (S.wallet.MEDAL_WORLD || 0); i++) list.push({ k: 'world' });
    for (let i = 0; i < (S.wallet.MEDAL_EURO || 0); i++) list.push({ k: 'euro' });
    // trophies won in higher leagues are bigger and get the best shelf spots
    S.trophyLog.slice().sort((a, b) => b.l - a.l || a.t - b.t).forEach((e) => list.push({ k: 'cup', t: e.t, l: e.l }));
    for (let i = 0; i < (S.wallet.GOLD_GEAR || 0); i++) list.push({ k: 'gear' });
    const rows = [[1.7, -0.85], [1.0, -0.85], [0.25, 0.3]];
    list.slice(0, 18).forEach((e, n) => {
      const row = Math.floor(n / 6), col = n % 6;
      const t = e.k === 'gear' ? goldDumbbell() : e.k === 'diamond' ? makeDiamondTrophy() : e.k === 'cup' ? makeTrophy(e.t) : makeMedal3D(e.k);
      if (e.k === 'cup') t.scale.setScalar(0.9 + e.l * 0.11);
      t.position.set(-1.65 + col * 0.66, rows[row][0], rows[row][1]);
      trophyGroup.add(t);
    });
    if (hallLabel) world.remove(hallLabel);
    const pct = Math.round(ST.incomePct - (S.wallet.UP_PRICE || 0) * 15);
    hallLabel = spr(labelTex(`Trophy Hall  +${pct}%`, '#f783ac', 'trophy'), 3.2, 0.8, 8);
    hallLabel.position.set(HALL.x, 3.1, HALL.z - 1.1);
    world.add(hallLabel);
    refreshDecor();
  }
  // ACADEMY DECORATIONS: one spot per sport in a "titles row" at the top of the lobby; every league title upgrades it
  // (banner -> statue -> trophy case) and adds a permanent +2% income
  const decorGroup = new THREE.Group();
  const decorSpot = (i) => ({ x: 1.95 + i * 0.86, z: 6.35 });
  let decorTitle = null;
  let decorKey = '';
  function refreshDecor() {
    const key = S.lg.map((l) => l.won.length).join(',');
    if (key === decorKey) return;
    decorKey = key;
    if (!decorGroup.parent) world.add(decorGroup);
    while (decorGroup.children.length) decorGroup.remove(decorGroup.children[0]);
    S.lg.forEach((l, i) => {
      if (!l.won.length) return;
      const top = Math.max(...l.won), kind = LEAGUES[top].decor, sp = SPORTS[i], col = new THREE.Color(sp.color).getHex();
      const { x, z } = decorSpot(i), g = new THREE.Group(); g.position.set(x, 0.12, z);
      if (!decorCols[i]) { decorCols[i] = true; addCol(x, z, 0.36, 0.38); }
      if (kind === 'banner') {
        g.add(mesh(cylG(0.05, 0.05, 2.2, 6), M(0xdee2e6, 'shiny'), 0, 1.1, 0));
        g.add(mesh(sphG(0.08, 6, 4), M(0, 'gold'), 0, 2.24, 0));
        g.add(B(0.6, 0.9, 0.05, col, 0.3, 1.68, 0.02));
        g.add(B(0.6, 0.16, 0.06, 0xffd43b, 0.3, 1.27, 0.02));
        g.add(B(0.5, 0.12, 0.5, 0x868e96, 0, 0.06, 0));
      } else if (kind === 'statue') {
        g.add(B(0.72, 0.5, 0.72, 0xdee2e6, 0, 0.25, 0), B(0.8, 0.08, 0.8, 0xadb5bd, 0, 0.54, 0));
        const st = SK.figure({ shirt: 0, shirtKind: 'gold', shorts: 0, shortsKind: 'gold', skin: 0xffd43b, shoes: 0, shoesKind: 'gold', bald: true, scale: 0.62 });
        st.traverse((o) => { if (o.isMesh && o.material && !o.material.transparent && o.material.color && !o.material.isMeshBasicMaterial) o.material = M(0, 'gold'); });
        st.position.y = 0.58;
        const u = st.userData; u.armR.rotation.z = 2.6; u.armL.rotation.z = -0.3;
        g.add(st);
        g.add(B(0.74, 0.14, 0.05, col, -0.38, 0.28, 0));
      } else {
        g.add(B(0.7, 0.16, 0.7, 0x5c3d2e, 0, 0.08, 0), B(0.7, 0.1, 0.7, 0x5c3d2e, 0, 1.75, 0));
        for (const [ox, oz] of [[-0.32, -0.32], [0.32, -0.32], [-0.32, 0.32], [0.32, 0.32]]) g.add(B(0.06, 1.6, 0.06, 0xffd43b, ox, 0.95, oz));
        g.add(B(0.62, 0.05, 0.62, 0xffffff, 0, 0.9, 0));
        const glass = mesh(boxG(0.62, 1.55, 0.62), new THREE.MeshPhongMaterial({ color: 0xd0ebff, transparent: true, opacity: 0.28, shininess: 120, depthWrite: false }), 0, 0.95, 0);
        g.add(glass);
        const low = makeTrophy(0); low.scale.setScalar(1.1); low.position.set(0, 0.16, 0); g.add(low);
        const high = top === 5 ? makeDiamondTrophy() : makeMedal3D('world'); high.position.set(0, 0.93, 0); g.add(high);
      }
      const lab = spr(bubbleTex(sp.icon), 0.5, 0.55, 8);
      lab.position.set(0, kind === 'banner' ? 2.65 : kind === 'statue' ? 2.05 : 2.25, 0); g.add(lab);
      decorGroup.add(g);
    });
    const n = S.lg.reduce((a, l) => a + l.won.length, 0);
    if (n && !decorTitle) { decorTitle = spr(labelTex('League Titles', '#fab005', 'trophy'), 2.4, 0.6, 8); decorTitle.position.set(3.65, 3.25, 6.35); world.add(decorTitle); }
  }
  const decorCols = {};

  // ======================================================================
  // ENTITIES & MOVEMENT
  // ======================================================================
  let coach = null, coachTier = 1;
  const coachVel = new THREE.Vector2();
  // the player's own coach: chosen look + an outfit that grows with the academy (tracksuit -> premium -> golden jacket)
  const DEFAULT_LOOK = { sex: 'm', skin: 0, hair: 'short', hairCol: 0, hat: 'cap' };
  const coachTierNow = () => { const n = S.zones.filter((z) => z.unlocked).length; return n >= 5 ? 3 : n >= 3 ? 2 : 1; };
  const buildPlayerChar = () => SK.player({ look: S.look || DEFAULT_LOOK, tier: coachTierNow() });
  function refreshCoachLook(celebrate) {
    const old = coach.char, ch = buildPlayerChar();
    ch.rotation.y = old.rotation.y;
    coach.obj.remove(old); coach.obj.add(ch); coach.char = ch;
    old.userData.root.remove(coach.stackGroup); ch.userData.root.add(coach.stackGroup);
    coachTier = coachTierNow();
    if (celebrate) { poof(coach.obj.position); SK.emote(ch, 'cheer', 1.8); }
  }
  AT.coachEmote = (k) => { if (coach) SK.emote(coach.char, k, k === 'thumbs' ? 1.3 : 2.0); };
  function makeCoach() {
    const ch = buildPlayerChar(); coachTier = coachTierNow();
    coach = newEnt(ch, 0, 12.5);
    coach.stack = []; coach.stackMeshes = []; coach.pickT = 0; coach.dropT = 0;
    coach.stackGroup = new THREE.Group(); coach.stackGroup.position.set(0, 0.85, -0.42); ch.userData.root.add(coach.stackGroup);
    coach.char.rotation.y = Math.PI;
  }

  function faceTo(e, yaw, dt) {
    let d = yaw - e.char.rotation.y;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    e.char.rotation.y += d * Math.min(1, dt * 14);
  }
  function moveTo(e, target, speed, dt) {
    const p = e.obj.position;
    const dx = target.x - p.x, dz = target.z - p.z, d = Math.hypot(dx, dz);
    if (d < 0.06) { e.moving = false; return true; }
    const s = Math.min(d, speed * dt);
    p.x += (dx / d) * s; p.z += (dz / d) * s;
    e.moving = true; faceTo(e, Math.atan2(dx, dz), dt);
    return false;
  }
  const d2 = (p, x, z) => Math.hypot(p.x - x, p.z - z);

  function pushOut(p, r) {
    for (const c of colliders) {
      const dx = p.x - c.x, dz = p.z - c.z;
      const ox = c.hw + r - Math.abs(dx), oz = c.hd + r - Math.abs(dz);
      if (ox > 0 && oz > 0) { if (ox < oz) p.x += Math.sign(dx || 1) * ox; else p.z += Math.sign(dz || 1) * oz; }
    }
  }
  function pushCircle(p, r, ox, oz, or) {
    const dx = p.x - ox, dz = p.z - oz, d = Math.hypot(dx, dz), min = r + or;
    if (d < min && d > 1e-4) { p.x += (dx / d) * (min - d); p.z += (dz / d) * (min - d); }
  }
  function pushChars(p, r) {
    for (const a of athletes) pushCircle(p, r, a.obj.position.x, a.obj.position.z, 0.3);
    for (const a of assistants) pushCircle(p, r, a.obj.position.x, a.obj.position.z, 0.33);
    if (recepEnt) pushCircle(p, r, recepEnt.obj.position.x, recepEnt.obj.position.z, 0.33);
  }

  // ---------- stacks ----------
  function layoutStack(c) {
    const n = c.stackMeshes.length;
    if (c.carry === 'net') { // a bundle of balls in a net bag
      c.stackMeshes.forEach((m, i) => { m.scale.setScalar(0.72); m.position.set(((i % 2) - 0.5) * 0.24, -0.15 - Math.floor(i / 2) * 0.22, ((i % 4) < 2 ? 0 : 0.12)); });
      if (c.net) { c.net.visible = n > 0; c.net.scale.set(1, 0.6 + Math.ceil(n / 2) * 0.38, 1); c.net.position.y = -0.1 - Math.ceil(n / 2) * 0.1; }
      return;
    }
    const sp = Math.min(c.carry === 'shoulder' ? 0.22 : 0.3, 4.2 / Math.max(1, n));
    c.stackMeshes.forEach((m, i) => m.position.set(0, i * sp, 0));
  }
  function pushStack(c, item) {
    c.stack.push(item);
    const m = getItem(item); m.scale.setScalar(0.01);
    c.stackGroup.add(m); c.stackMeshes.push(m);
    tween({ dur: 0.22, step: (k) => m.scale.setScalar(Math.max(0.01, easeBack(k))) });
    layoutStack(c);
  }
  function takeFromStack(c, item) {
    const idx = c.stack.lastIndexOf(item);
    if (idx < 0) return null;
    c.stack.splice(idx, 1);
    const m = c.stackMeshes.splice(idx, 1)[0];
    const wp = new THREE.Vector3(); m.getWorldPosition(wp);
    c.stackGroup.remove(m);
    layoutStack(c);
    return { mesh: m, wp };
  }

  // ---------- trash cans ----------
  const BIN_R = 1.15;
  const binNear = (p) => bins.find((b) => d2(p, b.x, b.z) < BIN_R) || null;
  function nearestBin(p, zone) {
    let best = null, bd = 1e9;
    for (const b of bins) { if (zone != null && b.zone !== zone) continue; const d = d2(p, b.x, b.z); if (d < bd) { bd = d; best = b; } }
    return best;
  }
  const _tw = new THREE.Vector3();
  function trashOne(c, bin, isCoach) {
    const m = c.stackMeshes.pop(); c.stack.pop();
    if (!m) return;
    m.getWorldPosition(_tw);
    c.stackGroup.remove(m); layoutStack(c);
    world.add(m); m.position.copy(_tw);
    const a = _tw.clone(), b = new THREE.Vector3(bin.x, 1.0, bin.z);
    tween({
      dur: 0.24,
      step: (k) => { m.position.lerpVectors(a, b, k); m.position.y += Math.sin(k * Math.PI) * 0.7; m.scale.setScalar(Math.max(0.05, 1 - k * 0.75)); m.rotation.x += 0.35; },
      done: () => { releaseItem(m); },
    });
    bin.lidT = 0.3;
    if (isCoach) { Snd.play('trash', 45); if (!c.stack.length) { bounce(bin.obj.userData.ico); floatText(ico('trash') + ' Empty!', bin.obj.position, 1.9, 'star'); } }
  }
  function updateBins(dt) {
    const full = coach.stack.length >= ST.cap;
    for (const b of bins) {
      b.lidT -= dt;
      const want = b.lidT > 0 ? 1.15 : 0;
      b.lid += (want - b.lid) * Math.min(1, dt * 18);
      b.obj.userData.lid.rotation.x = -b.lid;
      b.obj.userData.ring.material.opacity = full ? 0.55 + 0.4 * Math.sin(time * 8) : 0.6;
    }
  }

  // which item to hand out: whatever the athletes in that zone still need most (minus what's already carried);
  // when nobody waits, rotate through the zone's built disciplines' items
  function rackPick(zone, c) {
    const types = [...new Set(stations.filter((s) => s.zone === zone).map((s) => s.item))];
    if (!types.length) return ZONES[zone].item;
    let best = types[0], bv = -1e9;
    for (const t of types) {
      let need = 0;
      for (const s of stations) {
        const a = s.athlete;
        if (s.zone !== zone || s.item !== t || !a) continue;
        if (a.state === 'wait' || a.state === 'enter') need += a.needs - a.got;
        else if (a.state === 'train') need += a.needs - a.got - 1;
      }
      const have = c.stack.filter((x) => x === t).length, v = need - have - have * 0.01;
      if (v > bv) { bv = v; best = t; }
    }
    return best;
  }
  function carrierInteract(c, dt, isCoach) {
    c.pickT -= dt; c.dropT -= dt;
    const p = c.obj.position;
    const cap = isCoach ? ST.cap : c.cap;
    // standing on a trash can: throw items away one by one (and don't grab anything meanwhile)
    const bin = binNear(p);
    if (bin) {
      if (c.stack.length && c.dropT <= 0) { trashOne(c, bin, isCoach); c.dropT = 0.085; }
      c.pickT = Math.max(c.pickT, 0.25);
      return;
    }
    if (c.pickT <= 0 && c.stack.length < cap && !c.noPick) {
      for (const r of racks) {
        if (!isCoach && r.zone !== c.zone) continue;
        if (d2(p, r.pos.x, r.pos.z) < 1.4) {
          pushStack(c, rackPick(r.zone, c)); c.pickT = 0.13;
          if (isCoach) { Snd.play('pick', 60); if (c.stack.length >= cap) Snd.play('full', 400); }
          bounce(r.obj.userData.ico);
          break;
        }
      }
    }
    if (c.dropT <= 0 && c.stack.length) {
      for (const st of stations) {
        const a = st.athlete;
        if (!a || a.state !== 'wait') continue;
        if (!isCoach && st.zone !== c.zone) continue;
        if (d2(p, st.pos.x, st.pos.z) > 1.8) continue;
        const got = takeFromStack(c, st.item);
        if (!got) continue;
        c.dropT = 0.15;
        a.state = 'train'; a.t = 0; a.bubble.visible = false; a.bar.visible = true;
        if (isCoach) { Snd.play('drop', 50); task('deliver'); }
        flyItem(got.mesh, got.wp, a);
        break;
      }
    }
  }

  // ======================================================================
  // ATHLETES (pooled shells + cached skins per member)
  // ======================================================================
  function newMember(zone) {
    const used = new Set(S.roster.map((m) => m.name));
    const free = NAMES.filter((n) => !used.has(n));
    const m = { id: S.nextId++, name: free.length ? pick(free) : pick(NAMES) + ' ' + S.nextId, zone, xp: 0, skin: (Math.random() * SKINS.length) | 0, hair: (Math.random() * HAIRS.length) | 0 };
    S.roster.push(m);
    unlockSkin(zone, 1);
    return m;
  }
  const shellPool = [];
  const charCache = new Map(); // member id -> { tier, ch }
  function getShell() {
    let s = shellPool.pop();
    if (!s) {
      const obj = new THREE.Group(); obj.userData.ent = true;
      const starsSpr = spr(starsTex(1), 0.95, 0.21, 11); starsSpr.position.y = 1.75; obj.add(starsSpr);
      const bar = makeBar(0.9); bar.position.y = 2.02; obj.add(bar);
      const bubble = spr(bubbleTex('hourglass'), 0.9, 0.98, 12); bubble.position.y = 2.45; obj.add(bubble);
      const en = makeBar(0.62); en.position.y = 1.56; en.scale.set(1, 0.6, 1); obj.add(en); // team energy
      s = { obj, starsSpr, bar, bubble, en, target: new THREE.Vector3() };
    }
    return s;
  }
  function charFor(m) {
    const tier = starsOf(m);
    let c = charCache.get(m.id);
    const kit = m.zone === 2 ? myKit() : null;
    if (!c || c.tier !== tier || c.kit !== kit) { c = { tier, kit, ch: SK.athlete(athleteSpec(m, tier)) }; charCache.set(m.id, c); }
    return c.ch;
  }
  function setBubble(a, icon) { a.bubble.material.map = bubbleTex(icon); a.bubble.visible = true; bounce(a.bubble); }
  function spawnAthlete(m) {
    const a = getShell();
    a.char = charFor(m); a.char.rotation.y = Math.PI; a.char.userData.root.position.y = 0; a.obj.add(a.char);
    a.obj.position.set(rand(-0.8, 0.8), 0.12, EXIT.z);
    a.m = m; a.station = null; a.got = 0; a.needs = 2; a.t = 0; a.lvl = 0; a.trailT = 0; a.arrived = false; a.moving = false;
    a.starsSpr.material.map = starsFor(m); a.starsSpr.scale.set(0.95, 0.21, 1);
    a.bar.visible = false; a.bubble.visible = false; a.bubble.scale.set(0.9, 0.98, 1);
    a.en.visible = !!m.team; a.enShown = -1;
    world.add(a.obj);
    rt(m).present = true;
    athletes.push(a);
    return a;
  }
  // team athletes pick the station that trains what they still need most: stats far below their cap,
  // weighted toward what their sport uses; a station you picked for them (tap them) comes first
  function needScore(m, D) {
    if (!m.st) return 0;
    const cap = RARITY[m.rar || 0].cap, sw = STAT_W[Math.max(0, sportOfZone(m.zone))];
    let v = 0;
    for (let k = 0; k < 3; k++) v += D.w[k] * Math.max(0, cap - m.st[k]) * (0.4 + sw[k]);
    return D.all ? v * 0.62 : v; // the sparring ring trains everything, but slowly
  }
  function bestStation(m, list) {
    if (!list.length) return null;
    if (!m.team) return pick(list);
    if (m.pref) { const p = list.find((s) => s.kind === m.pref); if (p) return p; }
    let best = list[0], bv = -1;
    for (const s of list) { const v = needScore(m, s.disc) + Math.random() * 3; if (v > bv) { bv = v; best = s; } }
    return best;
  }
  function assignStation(a, st) {
    st.athlete = a; a.station = st; a.state = 'enter'; a.bubble.visible = false;
  }
  function despawn(a, i) {
    world.remove(a.obj);
    a.obj.remove(a.char); a.char = null;
    athletes.splice(i, 1);
    const r = rt(a.m); r.present = false; r.cool = a.m.team ? rand(14, 26) : rand(3, 8);
    shellPool.push(a);
  }
  function makeBar(w) {
    const g = new THREE.Group();
    const bg = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x212529, depthTest: false, transparent: true, opacity: 0.75 }));
    bg.scale.set(w + 0.1, 0.2, 1); bg.renderOrder = 20;
    const fg = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x69db7c, depthTest: false }));
    fg.center.set(0, 0.5); fg.position.x = -w / 2; fg.scale.set(0.001, 0.12, 1); fg.renderOrder = 21;
    g.add(bg, fg); g.userData = { fg, w };
    return g;
  }
  const setBar = (b, p) => (b.userData.fg.scale.x = Math.max(0.001, b.userData.w * clamp(p, 0, 1)));
  const trainTime = () => 2.6 / ST.train;

  function relayoutQueue() { queue.forEach((a, k) => queueSlot(k, a.target)); }
  function relayoutLine() { line.forEach((a, k) => lineSlot(k, a.target)); }

  function updateAthletes(dt) {
    // waiting line -> free station (FIFO per zone)
    for (let k = 0; k < line.length; k++) {
      const a = line[k];
      const st = bestStation(a.m, stations.filter((s) => !s.athlete && s.zone === a.m.zone));
      if (st) { line.splice(k, 1); k--; assignStation(a, st); relayoutLine(); }
    }
    for (let i = athletes.length - 1; i >= 0; i--) {
      const a = athletes[i];
      let mode = 'idle';
      if (a.lvl > 0) { levelUpAnim(a, dt); continue; }
      switch (a.state) {
        case 'line':
          moveTo(a, a.target, 3.2, dt);
          if (!a.moving) faceTo(a, 0, dt);
          a.bubble.position.y = 2.45 + Math.sin(time * 3 + i) * 0.05;
          break;
        case 'enter':
          if (moveTo(a, a.station.pos, 3.2, dt)) { a.state = 'wait'; setBubble(a, ITEMS[a.station.item].icon); }
          break;
        case 'wait':
          faceTo(a, 0, dt);
          a.bubble.position.y = 2.45 + Math.sin(time * 4 + i) * 0.06;
          break;
        case 'train': {
          faceTo(a, a.station.face, dt); mode = 'train';
          a.t += dt / (trainTime() * (a.station.disc.slow || 1));
          setBar(a.bar, (a.got + a.t) / a.needs);
          // Sky King-style golden ballers leave a trail of fire when they dunk
          if (a.char.userData.fx.fire && a.station.kind === 'dunk' && a.char.userData.body.position.y > 0.3 && Math.random() < 0.6) emit('comet', a.obj.position.x + rand(-0.2, 0.2), 0.8 + a.char.userData.body.position.y, a.obj.position.z - 0.4, 0.45, 0.6);
          if (a.t >= 1) {
            a.got++; a.t = 0;
            if (a.got >= a.needs) finishTraining(a);
            else { a.state = 'wait'; setBubble(a, ITEMS[a.station.item].icon); }
          }
          break;
        }
        case 'queue':
          moveTo(a, a.target, 3.4, dt);
          a.arrived = d2(a.obj.position, a.target.x, a.target.z) < 0.35;
          if (!a.moving) faceTo(a, -Math.PI / 2, dt);
          break;
        case 'leave':
          if (moveTo(a, EXIT, 3.4, dt)) { despawn(a, i); continue; }
          break;
      }
      if (mode !== 'train') mode = a.moving ? 'walk' : 'idle';
      if (a.m.team) { const e = Math.round(enOf(a.m)); if (e !== a.enShown) { a.enShown = e; setBar(a.en, e / 100); a.en.userData.fg.material.color.set(enCol(e)); } }
      animChar(a.char, dt, mode, a.station ? a.station.kind : null);
      // sparkle / lightning / wave / comet trails for Star & Legend skins
      const trail = a.char.userData.fx.trail;
      if (trail && a.moving) {
        a.trailT -= dt;
        if (a.trailT <= 0) {
          a.trailT = trail === 'comet' ? 0.04 : 0.07;
          emit(trail, a.obj.position.x + rand(-0.25, 0.25), 0.5 + rand(0, 0.9), a.obj.position.z + rand(-0.2, 0.2), trail === 'sparkle' || trail === 'speed' ? 0.35 : 0.55, trail === 'speed' ? 0.7 : 0.55);
        }
      }
    }
    // equipment moves with the athlete training on it (bar, bag, ball, rope...)
    for (const st of stations) {
      const tk = st.obj.userData.tick;
      if (!tk) continue;
      const a = st.athlete, on = !!(a && a.state === 'train' && a.char && a.lvl <= 0);
      tk(dt, on ? a.char.userData.ph : 0, on);
    }
  }

  function finishTraining(a) {
    const m = a.m, before = starsOf(m);
    a.bar.visible = false;
    const D = a.station.disc, zone = a.station.zone;
    a.station.athlete = null; a.station = null;
    task('train');
    const coachE = assistants.find((c) => c.zone === zone);
    if (coachE && coachE.char.userData.fx.coach === 'swim') coachE.char.userData.fx.clapT = 1.3; // Coach Marina claps
    if (m.team) {
      // team athletes don't pay: they gain XP (faster for rarer talents), improve a stat and head back out
      const R = RARITY[m.rar || 0], gain = R.grow * ST.train ** 0.5;
      m.xp = Math.min(STAR_XP[4] + 5, m.xp + gain);
      // the discipline decides which stat improves (the sparring ring trains all three a little)
      const w = D.w, sum = w[0] + w[1] + w[2], r = Math.random() * sum;
      const ks = D.all ? [0, 1, 2] : [r < w[0] ? 0 : r < w[0] + w[1] ? 1 : 2];
      for (const k of ks) m.st[k] = Math.min(R.cap, +(m.st[k] + R.grow * (D.all ? rand(0.4, 0.8) : rand(0.6, 1.4))).toFixed(1));
      floatText(`+${gain.toFixed(1).replace(/\.0$/, '')} XP · ${ks.map((k) => `${['SPD', 'POW', 'STA'][k]} ${Math.round(m.st[k])}`).join(' ')}`, a.obj.position, 2.3, 'star');
      a.state = 'leave';
    } else { m.xp++; tutFlags.trained = 1; a.state = 'queue'; a.arrived = false; queue.push(a); relayoutQueue(); }
    const after = starsOf(m);
    if (after > before) { a.lvl = 1.5; a.lvlTier = after; a.lvlSwapped = false; startLevelUp(a); }
  }

  // level-up: glow burst, jump-spin, swap to the new skin mid-air
  function startLevelUp(a) {
    Snd.play('tier');
    emit('ring', a.obj.position.x, 1.0, a.obj.position.z, 1.0, 0.9, 5);
    emit('glow', a.obj.position.x, 1.0, a.obj.position.z, 0.8, 2.2, 1.5);
  }
  function levelUpAnim(a, dt) {
    a.lvl -= dt;
    const t = 1.5 - a.lvl;
    const u = a.char.userData;
    u.root.position.y = Math.max(0, Math.sin(Math.min(1, t / 0.9) * Math.PI)) * 1.1;
    if (t < 0.9) a.char.rotation.y += dt * 16; else faceTo(a, 0, dt);
    if (Math.random() < 0.5) emit('sparkle', a.obj.position.x + rand(-0.6, 0.6), rand(0.3, 2), a.obj.position.z + rand(-0.4, 0.4), 0.4, 0.5);
    if (!a.lvlSwapped && t > 0.45) {
      a.lvlSwapped = true;
      const tier = a.lvlTier, m = a.m;
      const rotY = a.char.rotation.y, rootY = u.root.position.y;
      a.obj.remove(a.char);
      a.char = charFor(m);
      a.char.rotation.y = rotY; a.char.userData.root.position.y = rootY;
      a.obj.add(a.char);
      a.starsSpr.material.map = starsFor(m);
      bounce(a.starsSpr);
      const isNew = unlockSkin(m.zone, tier);
      let label = `${ico(SK.TIERS[tier - 1].icon)} ${SK.TIERS[tier - 1].name}!`;
      if (tier === 5 && S.legends[m.zone] == null) {
        S.legends[m.zone] = m.id;
        m.title = SK.LEGENDS[m.zone].name;
        label = `${ico('crown')} ${m.title}!`;
        setTimeout(() => toast(`${ico('crown')} ${m.name} became the legend ${m.title}!`, 3000), 400);
        Snd.play('legend');
      }
      floatText(label, a.obj.position, 2.6, 'star');
      emit('ring', a.obj.position.x, 1.0, a.obj.position.z, 0.8, 0.8, 6);
      if (isNew) colDot.classList.remove('hidden');
      save();
    }
    if (a.lvl <= 0) { a.lvl = 0; a.char.userData.root.position.y = 0; }
    animChar(a.char, dt, a.lvl > 0 ? 'cheer' : 'idle');
  }

  let payT = 0;
  function updateDesk(dt) {
    payT -= dt;
    const coachHere = d2(coach.obj.position, STAFF.x, STAFF.z) < 1.2;
    const front = queue[0];
    if (front && front.arrived && front.lvl <= 0 && (coachHere || S.recep) && payT <= 0) {
      queue.shift(); relayoutQueue();
      const fee = feeFor(front.m);
      addCoins(fee); task('coins', fee);
      if (coachHere) tutFlags.collected = 1;
      const to = coachHere || !recepEnt ? coach : recepEnt;
      flyCoins(front.obj.position, to, Math.min(6, 2 + Math.floor(fee / 20)));
      floatText('+' + fmt(fee), front.obj.position, 2.0);
      front.state = 'leave';
      payT = coachHere ? 0.25 : 0.8;
    }
    if (recepEnt) animChar(recepEnt.char, dt, 'idle');
  }

  let spawnT = 0.4;
  function updateSpawner(dt) {
    for (const id in rosterRT) if (rosterRT[id].cool > 0) rosterRT[id].cool -= dt;
    spawnT -= dt;
    if (spawnT > 0) return;
    spawnT = 1.1;
    if (athletes.length >= walkCap) return;
    // resting athletes stay in the Recovery Room; during the tutorial only walk-ins come in
    const ready = (r, z) => r.zone === z && !rt(r).present && rt(r).cool <= 0 && !(r.team && (resting.has(r.id) || inTut()));
    // your team athletes come in to train now and then; walk-in members fill the rest and pay fees
    const avail = (z) => {
      const t = S.roster.find((r) => r.team && ready(r, z)), w = S.roster.find((r) => !r.team && ready(r, z));
      return t && (!w || Math.random() < 0.4) ? t : w;
    };
    const free = stations.filter((s) => !s.athlete);
    if (free.length) {
      const st0 = pick(free), z = st0.zone;
      let m = avail(z);
      if ((!m || m.team) && S.roster.filter((r) => r.zone === z && !r.team).length < S.zones[z].stations * 2 && (!m || Math.random() < 0.5)) m = newMember(z);
      if (m) assignStation(spawnAthlete(m), bestStation(m, free.filter((s) => s.zone === z)) || st0);
      return;
    }
    // every station busy: returning members wait in a visible line in the lobby
    if (line.length >= LINE_MAX) return;
    const zones = S.zones.map((z, i) => (z.unlocked ? i : -1)).filter((i) => i >= 0 && line.filter((a) => a.m.zone === i).length < 2);
    if (!zones.length) return;
    const m = avail(pick(zones));
    if (!m) return;
    const a = spawnAthlete(m);
    a.state = 'line'; line.push(a); relayoutLine();
    a.bubble.material.map = bubbleTex('hourglass'); a.bubble.visible = true;
  }

  function updateAssistant(a, dt) {
    const rack = racks.find((r) => r.zone === a.zone);
    let best = null, bd = 1e9;
    let needed = false;
    for (const s of stations) {
      if (s.zone !== a.zone || !s.athlete) continue;
      const st = s.athlete.state;
      if (st === 'wait' || st === 'enter') needed = true;
      if (!a.stack.length || st !== 'wait') continue;
      const d = d2(a.obj.position, s.pos.x, s.pos.z);
      if (d < bd) { bd = d; best = s; }
    }
    // carrying items nobody needs for a while: bin them instead of standing around with a full stack
    a.idleT = a.stack.length && !needed ? (a.idleT || 0) + dt : 0;
    if (a.idleT > 4.5) a.dumping = true;
    if (!a.stack.length) a.dumping = false;
    a.noPick = a.dumping || !needed;
    const bin = a.dumping ? nearestBin(a.obj.position, a.zone) : null;
    if (bin) a.target.set(bin.x + 0.75, 0.12, bin.z + 0.35);
    else if (best) a.target.set(best.pos.x + 0.9, 0.12, best.pos.z + 0.5);
    else a.target.set(rack.pos.x + 1.1, 0.12, rack.pos.z + 0.4);
    moveTo(a, a.target, a.speed || 3.3, dt);
    carrierInteract(a, dt, false);
    animChar(a.char, dt, a.moving ? 'walk' : 'idle');
    // Big Brutus shouts motivation now and then
    const info = coachInfo(a.zone);
    if (info.shouts && (a.shoutT -= dt) <= 0) { a.shoutT = rand(5, 9); if (!a.moving || Math.random() < 0.4) floatText(pick(info.shouts), a.obj.position, 2.9, 'say'); }
  }

  // ---------- coach: smoothed analog movement + collisions ----------
  const input = { x: 0, y: 0 };
  const keys = {};
  function updateCoach(dt) {
    let ix = input.x, iz = input.y;
    if (keys.ArrowLeft || keys.KeyA) ix -= 1;
    if (keys.ArrowRight || keys.KeyD) ix += 1;
    if (keys.ArrowUp || keys.KeyW) iz -= 1;
    if (keys.ArrowDown || keys.KeyS) iz += 1;
    const mag = Math.hypot(ix, iz);
    if (mag > 1) { ix /= mag; iz /= mag; }
    const k = 1 - Math.exp(-dt * 16); // quick but smooth acceleration
    coachVel.x += (ix * ST.speed - coachVel.x) * k;
    coachVel.y += (iz * ST.speed - coachVel.y) * k;
    const sp = coachVel.length();
    const p = coach.obj.position;
    if (sp > 0.02) {
      // sub-step so fast movement can't tunnel through thin colliders
      const steps = Math.ceil((sp * dt) / 0.15);
      for (let s = 0; s < steps; s++) {
        p.x += (coachVel.x * dt) / steps; p.z += (coachVel.y * dt) / steps;
        pushOut(p, 0.36); pushChars(p, 0.36); pushOut(p, 0.36);
        p.x = clamp(p.x, bounds.minX, bounds.maxX);
        p.z = clamp(p.z, bounds.minZ, bounds.maxZ);
      }
      if (mag > 0.1) faceTo(coach, Math.atan2(ix, iz), dt);
    }
    coach.moving = sp > 0.6;
    animChar(coach.char, dt, coach.moving ? 'walk' : 'idle');
    // the carried stack wobbles a little with every step (higher items sway more)
    const wob = coach.moving ? 1 : 0;
    coach.stackGroup.rotation.x += ((wob ? -0.12 + Math.sin(time * 11) * 0.04 : 0) - coach.stackGroup.rotation.x) * Math.min(1, dt * 10);
    coach.stackGroup.rotation.z += ((wob ? Math.sin(time * 5.6) * 0.06 : 0) - coach.stackGroup.rotation.z) * Math.min(1, dt * 10);
    coach.stackMeshes.forEach((m, i) => { m.position.x += ((wob ? Math.sin(time * 5.6 - i * 0.55) * 0.012 * i : 0) - m.position.x) * Math.min(1, dt * 8); });
  }

  // ======================================================================
  // PURCHASE TILES
  // ======================================================================
  function tileDefs() {
    const defs = [];
    const titles = titleCount();
    S.zones.forEach((z, i) => {
      const Z = ZONES[i], zc = zoneZ(i);
      if (!z.unlocked) return;
      if (z.stations < 4) {
        const k = z.stations, [ox, oz] = STATION_OFF[k];
        defs.push({ id: `st${i}_${k}`, x: ox, z: zc + oz, cost: Math.round(Z.unit * STATION_MULT[k]), icon: Z.icon, apply: () => (S.zones[i].stations = k + 1) });
      }
      if (z.stations >= 2 && z.assistants < 1 && feat('helpers')) {
        defs.push({ id: `as${i}`, x: RACK_X, z: zc + 3.0, cost: Z.unit * 5, icon: 'whistle', apply: () => { S.zones[i].assistants = 1; toast(`${ico('whistle')} ${coachInfo(i).name} joined the ${Z.name}!`, 2400); } });
      } else if (z.assistants >= 1 && z.assistants < 3 && z.stations >= 2 + z.assistants && feat('helpers')) {
        const lv = z.assistants + 1; // Head Coach needs 3 stations, Legendary Coach all 4
        defs.push({ id: `as${i}_${lv}`, x: RACK_X, z: zc + 3.0, cost: Z.unit * (lv === 2 ? 14 : 45), icon: lv === 2 ? 'star' : 'crown', apply: () => (S.zones[i].assistants = lv) });
      }
    });
    const n = nextLocked();
    if (n != null && S.zones[prevZone(n)].stations >= 2 && feat('sport2') && (slotOf(n) < 2 || feat('leagues'))) {
      const Z = ZONES[n];
      defs.push({
        id: `zone${n}`, x: 0.7, z: zoneZ(n) + 5.55, cost: Z.cost, icon: Z.icon,
        locked: titles < Z.need, lockText: `${Z.need} title${Z.need > 1 ? 's' : ''}`, need: Z.need,
        apply: () => { AT.perfHold(6); S.zones[n].unlocked = true; S.zones[n].stations = Math.max(1, S.zones[n].stations); toast(`${ico(Z.icon)} ${Z.name} open!`); panTo(0, zoneZ(n)); },
      });
    }
    if (!S.recep && S.zones[0].stations >= 2 && feat('helpers')) defs.push({ id: 'recep', x: -5.3, z: 10.85, cost: 220, icon: 'bell', apply: () => (S.recep = true) });
    if (!S.recov && feat('recovery')) defs.push({ id: 'recov', x: RPAD.x, z: RPAD.z, cost: RECOV_COST[0], icon: 'bed', apply: () => { S.recov = 1; rpadWas = true; toast(`${ico('bed')} Recovery Room open! Tired athletes rest here`, 2600); } });
    if (!S.office && S.zones[1].unlocked && feat('scouting')) defs.push({ id: 'scout', x: PAD.x, z: PAD.z, cost: OFFICE_COST[0], icon: 'scout', apply: () => { S.office = 1; S.scoutFree++; padWas = true; toast(`${ico('scout')} Scouting Office open! First trip is free`, 2600); } });
    return defs;
  }
  const borderMat = new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.9 });
  const tileBaseMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, depthWrite: false });
  const tileLockMat = new THREE.MeshBasicMaterial({ color: 0x868e96, transparent: true, opacity: 0.5, depthWrite: false });
  const tileFillMat = new THREE.MeshBasicMaterial({ color: 0xfab005, transparent: true, opacity: 0.9, depthWrite: false });
  function buildTileObj(t) {
    const g = new THREE.Group(); g.position.set(t.x, 0.14, t.z);
    const base = mesh(GEO('tile', () => new THREE.PlaneGeometry(1.7, 1.7)), t.locked ? tileLockMat : tileBaseMat); base.rotation.x = -Math.PI / 2; g.add(base);
    const fill = mesh(GEO('tilef', () => new THREE.PlaneGeometry(1.5, 1.5)), tileFillMat, 0, 0.01, 0); fill.rotation.x = -Math.PI / 2; g.add(fill);
    if (!t.locked) for (const [w, d, x, z] of [[1.8, 0.1, 0, -0.85], [1.8, 0.1, 0, 0.85], [0.1, 1.8, -0.85, 0], [0.1, 1.8, 0.85, 0]]) g.add(mesh(boxG(w, 0.06, d), borderMat, x, 0.02, z));
    const label = spr(drawTileLabel(t), 2.0, 1.45, 9); label.position.y = 1.55; g.add(label);
    t.obj = g; t.fill = fill; t.label = label;
    world.add(g);
  }
  function refreshTiles() {
    const defs = tileDefs();
    const ids = new Set(defs.map((d) => d.id));
    for (const [id, t] of tiles) if (!ids.has(id)) { dropTile(t); tiles.delete(id); }
    for (const d of defs) {
      const t = tiles.get(d.id);
      if (t && t.locked === d.locked) continue;
      if (t) dropTile(t);
      d.paid = Math.min(S.paid[d.id] || 0, d.cost);
      buildTileObj(d); tiles.set(d.id, d);
    }
  }
  function dropTile(t) { world.remove(t.obj); if (t.tex) t.tex.dispose(); t.label.material.dispose(); }
  let coinTrail = 0;
  function updateTiles(dt) {
    borderMat.opacity = 0.55 + 0.45 * Math.sin(time * 5);
    let done = null;
    for (const t of tiles.values()) {
      const on = d2(coach.obj.position, t.x, t.z) < 1.0;
      t.label.position.y = 1.55 + Math.sin(time * 3 + t.x) * 0.06;
      if (on && !t.locked) {
        if (t.cost - t.paid <= 0.5) done = t;                  // already (almost) paid: finish instantly
        else if (S.wallet.COINS > 0.01) {
          const remaining = t.cost - t.paid;
          const rate = Math.max(t.cost / 1.4, 20);
          let amt = Math.min(rate * dt, S.wallet.COINS, remaining);
          // don't leave a fraction of a coin hanging: pay the remainder in one go when we can
          if (S.wallet.COINS >= remaining && remaining - amt < 1) amt = remaining;
          spendCoins(amt); t.paid += amt; S.paid[t.id] = t.paid;
          if (S.wallet.COINS < 1e-6) S.wallet.COINS = 0;
          coinTrail -= dt;
          if (coinTrail <= 0) { coinTrail = 0.07; flyCoinTo(coach.obj.position, t.x, t.z); Snd.play('tick', 60); }
          if (t.cost - t.paid <= 0.5) done = t;
        }
      } else if (on && t.locked && !t.warned) {
        t.warned = true; toast(`${ico('lock')} Win ${t.need} league title${t.need > 1 ? 's' : ''} to open · ${ico('trophy')} ${titleCount()}/${t.need}`, 2400);
      }
      if (!on) t.warned = false;
      if (t.wasOn && !on && t.paid > 0) save(); // paid progress is kept (and saved) when the coach walks away
      t.wasOn = on;
      const k = t.cost ? clamp(t.paid / t.cost, 0, 1) : 1;
      t.fill.scale.set(Math.max(0.001, k), Math.max(0.001, k), 1);
      // live countdown on the label
      if (!t.locked && (Math.ceil(t.cost - t.paid - 1e-6) !== t.shownRem || Math.floor(k * 100) !== t.shownK)) drawTileLabel(t);
    }
    if (done) completeTile(done);
  }
  function completeTile(t) {
    delete S.paid[t.id];
    dropTile(t); tiles.delete(t.id);
    t.apply();
    Snd.play('buy'); AT.coachEmote('thumbs');
    confetti(t.x, 0.5, t.z);
    syncWorld(); refreshTiles(); save(true);
  }

  function syncWorld() {
    if (coach && coachTierNow() !== coachTier) {
      const up = coachTierNow() > coachTier;
      refreshCoachLook(up);
      if (up && built.ready) toast(`${ico('jersey')} New coach outfit: ${['', 'Tracksuit', 'Premium jacket', 'Golden coach jacket'][coachTier]}!`, 2600);
    }
    S.zones.forEach((z, i) => {
      if (!z.unlocked) return;
      if (!built.zone[i]) {
        if (built.preview[i]) { world.remove(built.preview[i]); delete built.preview[i]; }
        buildZone(i); built.zone[i] = true;
      }
      while (built.stations[i] < z.stations) addStation(i, built.stations[i]++);
      restyleZone(i);
      if (z.assistants && !built.assist[i]) { addAssistant(i); built.assist[i] = 1; }
      else if (z.assistants) { const a = assistants.find((c) => c.zone === i); if (a) promoteAssistant(a); }
    });
    const n = nextLocked();
    let top = S.zones.reduce((acc, z, i) => (z.unlocked && slotOf(i) > slotOf(acc) ? i : acc), 0);
    if (n != null && S.zones[prevZone(n)].stations >= 2 && feat('sport2')) { if (!built.preview[n]) buildPreview(n); if (slotOf(n) > slotOf(top)) top = n; }
    bounds.minZ = zoneZ(top) - 4.4;
    const gt = gateTier();
    if (gt !== mainTier) { buildMainGate(gt, built.ready && mainTier >= 0); mainTier = gt; }
    for (const k in entrances) { const e = entrances[k]; if (e.locked && e.fx.tagNeed && titleCount() >= ZONES[k].need) buildEntrance(+k, true); }
    built.ready = true;
    if (S.recep && !recepEnt) addRecep();
    buildOffice();
    buildRecovery();
  }

  // ======================================================================
  // FX (all pooled): tweens, coins, confetti, particles, floating text, guide
  // ======================================================================
  const tweens = [];
  const easeBack = (k) => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
  function tween(t) { t.t = 0; tweens.push(t); return t; }
  function bounce(o) {
    if (o.userData.bouncing) return;
    o.userData.bouncing = true;
    const s = o.scale.clone();
    tween({ dur: 0.3, step: (k) => o.scale.copy(s).multiplyScalar(1 + Math.sin(k * Math.PI) * 0.35), done: () => { o.scale.copy(s); o.userData.bouncing = false; } });
  }
  const coinGeo = new THREE.CylinderGeometry(0.17, 0.17, 0.06, 12);
  const coinMat = new THREE.MeshPhongMaterial({ color: 0xffd43b, emissive: 0x5c3d00, shininess: 80, flatShading: true });
  const coinPool = [];
  const getCoin = () => { const c = coinPool.pop() || new THREE.Mesh(coinGeo, coinMat); c.rotation.set(Math.PI / 2, 0, 0); return c; };
  function arcTween(m, from, target, follow, dur, h, onDone) {
    world.add(m); m.position.copy(from);
    const a = from.clone(), b = new THREE.Vector3();
    tween({
      dur, step: (k) => {
        if (follow) b.copy(follow.position).setY(target.y); else b.copy(target);
        m.position.lerpVectors(a, b, k); m.position.y += Math.sin(k * Math.PI) * h;
        m.rotation.y += 0.3;
      }, done: () => { world.remove(m); onDone && onDone(); },
    });
  }
  function flyCoins(from, toEnt, n) {
    for (let i = 0; i < n; i++) {
      const c = getCoin();
      const f = new THREE.Vector3(from.x + rand(-0.3, 0.3), 1.2, from.z + rand(-0.3, 0.3));
      arcTween(c, f, new THREE.Vector3(0, 1.6, 0), toEnt.obj, 0.45 + i * 0.06, 1.6, () => { coinPool.push(c); Snd.play('coin', 45); bumpCoins(); });
    }
  }
  function flyCoinTo(from, x, z) {
    const c = getCoin();
    arcTween(c, new THREE.Vector3(from.x, 1.5, from.z), new THREE.Vector3(x, 0.2, z), null, 0.3, 0.8, () => coinPool.push(c));
  }
  function flyItem(m, wp, ath) {
    m.scale.setScalar(1);
    arcTween(m, wp, new THREE.Vector3(0, 1.0, 0), ath.obj, 0.28, 0.8, () => { releaseItem(m); bounce(ath.bar); });
  }
  // confetti
  const confGeo = new THREE.BoxGeometry(0.14, 0.14, 0.04);
  const confCols = [0xff6b6b, 0xffd43b, 0x51cf66, 0x4dabf7, 0xcc5de8, 0xff922b].map((c) => new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide }));
  const confLive = [], confPool = [];
  function confetti(x, y, z, n = 26) {
    for (let i = 0; i < n; i++) {
      if (confLive.length > 120) break;
      const m = confPool.pop() || new THREE.Mesh(confGeo, pick(confCols));
      m.position.set(x, y, z);
      m.userData.v = (m.userData.v || new THREE.Vector3()).set(rand(-3, 3), rand(5, 9), rand(-3, 3));
      m.userData.life = rand(0.9, 1.4);
      world.add(m); confLive.push(m);
    }
  }
  const poof = (pos) => confetti(pos.x, 0.6, pos.z, 14);
  // additive sprite particles (trails, glow bursts)
  const partLive = [], partPool = [];
  function emit(type, x, y, z, life, size, grow = 0) {
    if (partLive.length > partMax) return;
    let s = partPool.pop();
    if (!s) { s = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })); s.renderOrder = 5; }
    s.material.map = PTEX[type]; s.material.opacity = 1; s.material.rotation = type === 'lightning' ? rand(-0.5, 0.5) : rand(0, 6);
    s.position.set(x, y, z);
    s.scale.set(size, size, 1);
    s.userData.life = s.userData.max = life; s.userData.size = size; s.userData.grow = grow;
    s.userData.vy = type === 'sparkle' ? 0.6 : type === 'wave' ? -0.2 : 0.1;
    world.add(s); partLive.push(s);
  }
  function updateFX(dt) {
    for (let i = tweens.length - 1; i >= 0; i--) {
      const t = tweens[i];
      t.t += dt;
      const k = Math.min(1, t.t / t.dur);
      t.step(k);
      if (k >= 1) { tweens.splice(i, 1); t.done && t.done(); }
    }
    for (let i = confLive.length - 1; i >= 0; i--) {
      const m = confLive[i], u = m.userData;
      u.life -= dt; u.v.y -= 18 * dt;
      m.position.addScaledVector(u.v, dt);
      m.rotation.x += dt * 8; m.rotation.y += dt * 6;
      if (m.position.y < 0.15) { m.position.y = 0.15; u.v.set(u.v.x * 0.5, 0, u.v.z * 0.5); }
      if (u.life <= 0) { world.remove(m); confLive.splice(i, 1); confPool.push(m); }
    }
    for (let i = partLive.length - 1; i >= 0; i--) {
      const s = partLive[i], u = s.userData;
      u.life -= dt;
      const k = Math.max(0, u.life / u.max);
      s.material.opacity = k;
      s.position.y += u.vy * dt;
      const sz = u.size * (1 + (1 - k) * u.grow);
      s.scale.set(sz, sz, 1);
      if (u.life <= 0) { world.remove(s); partLive.splice(i, 1); partPool.push(s); }
    }
  }
  // floating DOM text (pooled elements)
  const fxEl = $('fx');
  const ftPool = [];
  const _v = new THREE.Vector3();
  function floatText(text, pos, h = 2, cls = '') {
    _v.copy(pos); _v.y += h; _v.project(camera);
    const el = ftPool.pop() || document.createElement('div');
    el.className = 'ft ' + cls; el.innerHTML = text;
    el.style.left = ((_v.x + 1) / 2) * gameEl.clientWidth + 'px';
    el.style.top = ((1 - _v.y) / 2) * gameEl.clientHeight + 'px';
    fxEl.appendChild(el);
    setTimeout(() => { el.remove(); ftPool.push(el); }, cls === 'say' ? 1650 : 1000);
  }

  // guide arrow (tutorial)
  const guideMat = new THREE.MeshBasicMaterial({ color: 0xffd43b });
  const guideOutline = new THREE.MeshBasicMaterial({ color: 0xe8590c });
  const guideDown = new THREE.Group();
  {
    const c = mesh(new THREE.ConeGeometry(0.4, 0.8, 4), guideMat); c.rotation.x = Math.PI; guideDown.add(c);
    const o = mesh(new THREE.ConeGeometry(0.48, 0.95, 4), guideOutline, 0, 0.05, 0); o.rotation.x = Math.PI; guideDown.add(o);
  }
  const guideFlat = new THREE.Group();
  { const c = mesh(new THREE.ConeGeometry(0.3, 0.6, 3), guideMat); c.rotation.x = Math.PI / 2; guideFlat.add(c); }
  scene.add(guideDown, guideFlat);
  // full stack: "FULL" tag over the coach + pulsing arrow to the nearest trash can
  const fullSpr = spr(ctex('fullTag', 256, 104, (g, w, h) => {
    rr(g, 8, 12, w - 16, h - 22, 38); g.fillStyle = 'rgba(0,0,0,.22)'; g.fill();
    rr(g, 8, 4, w - 16, h - 22, 38); g.fillStyle = '#fa5252'; g.fill(); g.lineWidth = 10; g.strokeStyle = '#fff'; g.stroke();
    g.fillStyle = '#fff'; g.font = `900 56px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; boldText(g, 'FULL', w / 2, h / 2 - 6, 0, 3);
  }), 1.6, 0.65, 14);
  fullSpr.visible = false; scene.add(fullSpr);
  const binArrow = new THREE.Group();
  {
    const red = new THREE.MeshBasicMaterial({ color: 0xff6b6b }), white = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const o = mesh(new THREE.ConeGeometry(0.42, 0.8, 3), white, 0, 0, 0); o.rotation.x = Math.PI / 2; binArrow.add(o);
    const c = mesh(new THREE.ConeGeometry(0.32, 0.62, 3), red, 0, 0.04, 0.02); c.rotation.x = Math.PI / 2; binArrow.add(c);
  }
  binArrow.visible = false; scene.add(binArrow);
  function updateFull() {
    const p = coach.obj.position, n = coach.stack.length;
    const full = n >= ST.cap;
    fullSpr.visible = full;
    if (full) {
      const sp = Math.min(0.3, 4.2 / Math.max(1, n));
      const top = 0.12 + (0.85 + (n - 1) * sp + 0.35) * 1.05;
      fullSpr.position.set(p.x, Math.max(2.6, top + 0.5), p.z);
      const k = 1 + 0.1 * Math.sin(time * 9);
      fullSpr.scale.set(1.6 * k, 0.65 * k, 1);
    }
    const bin = full && !binNear(p) ? nearestBin(p) : null;
    binArrow.visible = !!bin;
    if (bin) {
      const dx = bin.x - p.x, dz = bin.z - p.z, d = Math.hypot(dx, dz) || 1;
      const r = 1.9 + Math.abs(Math.sin(time * 6)) * 0.3;
      binArrow.position.set(p.x + (dx / d) * r, 0.35, p.z + (dz / d) * r);
      binArrow.rotation.y = Math.atan2(dx, dz);
      binArrow.scale.setScalar(1.7 * (1 + 0.22 * Math.abs(Math.sin(time * 6))));
      bin.obj.userData.ico.scale.set(0.66 * (1 + 0.18 * Math.abs(Math.sin(time * 6))), 0.72 * (1 + 0.18 * Math.abs(Math.sin(time * 6))), 1);
    }
  }
  const hintEl = $('hint');
  let hintTxt = '';
  const _gp = new THREE.Vector3();
  function guideTarget() {
    if (S.zones[1].unlocked && S.played > 0) return null;
    const waiting = stations.filter((s) => s.athlete && s.athlete.state === 'wait');
    for (const s of waiting) if (coach.stack.includes(s.item)) return { p: s.pos, h: `${ico(ITEMS[s.item].icon)} ${ico('arrow')} Deliver` };
    const staffed = new Set(assistants.map((a) => a.zone));
    const needy = waiting.find((s) => !staffed.has(s.zone));
    if (needy) { const r = racks.find((r) => r.zone === needy.zone); return { p: r.pos, h: `Grab ${ico(ITEMS[needy.item].icon)}` }; }
    if (queue.length && !S.recep) return { p: STAFF, h: `${ico('coin')} Collect` };
    let best = null;
    for (const t of tiles.values()) if (!t.locked && (!best || t.cost - t.paid < best.cost - best.paid)) best = t;
    if (best && S.wallet.COINS >= Math.min(best.cost - best.paid, 30)) return { p: _gp.set(best.x, 0, best.z), h: `${ico('plus')} Build ${ico(best.icon)}` };
    return null;
  }
  function updateGuide() {
    let g = inTut() ? tutTarget() : goalGuideT > 0 ? goalTarget() : null; // tutorial first, then a tapped goal
    if (!g && !inTut()) g = guideTarget();
    // full stack with nothing deliverable: point the way to the trash
    const full = coach.stack.length >= ST.cap;
    if (full && !stations.some((s) => s.athlete && s.athlete.state === 'wait' && coach.stack.includes(s.item))) {
      const b = nearestBin(coach.obj.position);
      if (b) g = { p: _gp.set(b.x, 0, b.z), h: `${ico('trash')} Full! Drop extras in the trash` };
    }
    const txt = g && !inTut() ? g.h : '';
    if (txt !== hintTxt) { hintTxt = txt; hintEl.innerHTML = txt; hintEl.classList.toggle('hidden', !txt); }
    if (!g) { guideDown.visible = guideFlat.visible = false; return; }
    const p = coach.obj.position;
    const dx = g.p.x - p.x, dz = g.p.z - p.z, d = Math.hypot(dx, dz);
    guideDown.visible = true;
    guideDown.position.set(g.p.x, 3.5 + Math.abs(Math.sin(time * 4)) * 0.45, g.p.z);
    guideDown.rotation.y += 0.05;
    guideFlat.visible = d > 2.2 && !full;
    if (guideFlat.visible) {
      guideFlat.position.set(p.x + (dx / d) * 1.35, 0.3, p.z + (dz / d) * 1.35);
      guideFlat.rotation.y = Math.atan2(dx, dz);
    }
  }

  // the sport whose tournament is ready (or comes up next) among sports you have athletes for
  function nextSport() {
    let best = -1;
    S.lg.forEach((l, i) => { if (sportHasAthletes(i) && (best < 0 || l.next < S.lg[best].next)) best = i; });
    return best;
  }
  AT.nextSport = () => nextSport();

  // ======================================================================
  // RIVAL CHALLENGES: every few minutes a rival walks in and offers a 1-on-1 for a coin prize
  // ======================================================================
  const CHAL_SPOT = new THREE.Vector3(1.3, 0.12, 13.8);
  const CHAL_WAIT = 15;
  let chalT = rand(180, 300), chal = null;
  const chalEl = $('chal');
  const chalBubbleTex = (icon, color) => ctex('CB' + icon + color, 128, 140, (g) => {
    g.fillStyle = '#fff';
    g.beginPath(); g.arc(64, 60, 54, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.moveTo(48, 105); g.lineTo(64, 136); g.lineTo(80, 105); g.fill();
    g.lineWidth = 8; g.strokeStyle = color; g.beginPath(); g.arc(64, 60, 52, 0, Math.PI * 2); g.stroke();
    IC.draw(g, icon, 64, 58, 66);
    IC.draw(g, 'swords', 104, 22, 36);
  });
  function spawnChallenge() {
    // only sports where someone has the energy to fight
    const opts = SPORTS.map((_, i) => i).filter((i) => teamList().some((m) => SPORTS[i].zones.includes(m.zone) && S.zones[m.zone].unlocked && enOf(m) >= 20));
    if (!opts.length) return;
    const sp = pick(opts), R = pick(RIVALS), lvl = S.lg[sp].lvl;
    const mine = teamList().filter((m) => SPORTS[sp].zones.includes(m.zone) && S.zones[m.zone].unlocked);
    const best = Math.max(...mine.map(starsOf));
    const stars = clamp(Math.round(best + rand(-0.8, 1.4) + lvl * 0.25), 1, 5);
    const zone = SPORTS[sp].zones[0], Z = ZONES[zone];
    // stronger rivals put up bigger prizes; losing costs a little (never more than 10% of your coins)
    const prize = Math.max(50, Math.round(((70 + Z.fee * 16) * (0.45 + stars * 0.35) * Math.sqrt(LEAGUES[lvl].coin)) / 10) * 10);
    // same sport kit as your athletes, in the rival academy's colours
    const nm = pick(NAMES);
    const ch = SK.athlete({ zone, tier: stars, team: new THREE.Color(R.color).getHex(), shirt: Z.shirt, skin: pick(SKINS), hair: pick(HAIRS), num: ((Math.random() * 98) | 0) + 1, name: nm, seed: nm, kit: zone === 2 ? AT.rivalKit(RIVALS.indexOf(R), lvl) : null, scale: 0.9 });
    const ent = newEnt(ch, EXIT.x, EXIT.z);
    const bub = spr(chalBubbleTex(SPORTS[sp].icon, R.color), 1.05, 1.15, 11); bub.position.y = 2.75; ent.obj.add(bub);
    chal = { ent, bub, sp, R, stars, prize, name: nm, state: 'in', t: 0 };
    Snd.play('whistle');
  }
  function chalRisk() { return Math.min(Math.round(chal.prize * 0.25), Math.floor(S.wallet.COINS * 0.1)); }
  function showChalCard() {
    const c = chal, sp = SPORTS[c.sp];
    const mine = Math.max(...teamList().filter((m) => sp.zones.includes(m.zone) && S.zones[m.zone].unlocked).map(starsOf));
    const risk = chalRisk();
    chalEl.innerHTML = `<div class="ch-top"><span class="logo" style="background:${c.R.color}">${ico(c.R.logo)}</span>
        <div class="ch-who"><b>${c.name} · ${c.R.name}</b><span>${ico(sp.icon)} ${sp.name} challenge!</span></div></div>
      <div class="ch-vs"><span>Rival ${IC.stars(c.stars)}</span><span>Your best ${IC.stars(mine)}</span></div>
      <div class="ch-stakes"><span class="win">Win ${ico('coin')} +${fmt(c.prize)}</span><span class="lose">Lose ${risk ? `${ico('coin')} −${fmt(risk)}` : 'nothing'}</span></div>
      <div class="ch-bar"><i id="chalBar"></i></div>
      <div class="ch-btns"><button class="no" data-c="no">Decline</button><button class="yes" data-c="yes">Accept ${ico('swords')}</button></div>`;
    chalEl.classList.remove('hidden', 'out'); chalEl.classList.add('in');
    Snd.play('level');
  }
  function hideChalCard() { chalEl.classList.add('hidden'); chalEl.classList.remove('in'); }
  function chalLeave(msg) {
    if (!chal || chal.state === 'out') return;
    hideChalCard();
    chal.state = 'out'; chal.t = 0; chal.bub.visible = false;
    if (msg) toast(msg);
  }
  chalEl.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b || !chal || chal.state !== 'wait') return;
    e.stopPropagation(); Snd.unlock(); Snd.play('tap');
    if (b.dataset.c === 'no') { chalLeave(`${chal.R.name} walks off`); return; }
    if (AT.Tourney.active) return;
    chal.state = 'busy'; hideChalCard(); task('chal');
    const c = chal;
    AT.Tourney.openDuel({ sport: c.sp, academy: c.R, stars: c.stars, name: c.name, prize: c.prize, risk: chalRisk(), lvl: S.lg[c.sp].lvl }, (res) => {
      if (chal !== c) return;
      if (res === 'win') S.chalWins = (S.chalWins || 0) + 1;
      chalLeave(res == null ? `${c.R.name} walks off` : '');
    });
  });
  function updateChallenge(dt) {
    if (!chal) {
      if (AT.modalOpen() || AT.Tourney.active || !teamList().length || !feat('rivals')) return;
      if ((chalT -= dt) <= 0) spawnChallenge();
      return;
    }
    const c = chal; c.t += dt;
    c.bub.position.y = 2.75 + Math.abs(Math.sin(time * 4)) * 0.18;
    if (c.state === 'in') {
      if (moveTo(c.ent, CHAL_SPOT, 3.4, dt)) { c.state = 'wait'; c.t = 0; showChalCard(); }
      animChar(c.ent.char, dt, c.ent.moving ? 'walk' : 'idle');
    } else if (c.state === 'wait') {
      const p = coach.obj.position, q = c.ent.obj.position;
      faceTo(c.ent, Math.atan2(p.x - q.x, p.z - q.z), dt);
      animChar(c.ent.char, dt, 'idle');
      const left = CHAL_WAIT - c.t, bar = $('chalBar');
      if (bar) bar.style.width = `${clamp(left / CHAL_WAIT, 0, 1) * 100}%`;
      if (AT.Tourney.active) chalLeave('');
      else if (left <= 0) chalLeave(`${c.R.name} got bored and left`);
    } else if (c.state === 'busy') {
      animChar(c.ent.char, dt, 'idle');
      if (!AT.modalOpen() && !AT.Tourney.active) chalLeave(`${c.R.name} walks off`); // picker closed without a fight
    } else if (c.state === 'out') {
      const arrived = moveTo(c.ent, EXIT, 3.6, dt);
      animChar(c.ent.char, dt, 'walk');
      if (arrived || c.t > 8) { world.remove(c.ent.obj); chal = null; chalT = rand(180, 300); }
    }
  }

  // ======================================================================
  // HUD / UI
  // ======================================================================
  const coinTxt = $('coinTxt'), coinPill = $('coinPill'), trophyTxt = $('trophyTxt');
  const banner = $('banner'), bannerTxt = $('bannerTxt'), bannerIco = $('bannerIco'), upDot = $('upDot'), colDot = $('colDot');
  let shownCoins = -1, shownTrophies = -1, shownLeague = -1, hudT = 0;
  function bumpCoins() { coinPill.classList.remove('bump'); void coinPill.offsetWidth; coinPill.classList.add('bump'); }
  function updateHUD(dt) {
    const c = Math.floor(S.wallet.COINS);
    if (c !== shownCoins) { shownCoins = c; coinTxt.textContent = fmt(c); }
    hudT -= dt;
    if (hudT > 0) return;
    hudT = 0.25; // the rest only needs a few refreshes per second
    const t = trophyCount();
    if (t !== shownTrophies) { shownTrophies = t; trophyTxt.textContent = t; }
    const L = leagueIndex();
    if (L !== shownLeague) { shownLeague = L; $('leagueIco').innerHTML = ico(LEAGUES[L].icon); $('leagueTxt').textContent = LEAGUES[L].short; }
    const nx = nextSport(), ready = nx >= 0 && S.lg[nx].next <= 0;
    banner.classList.toggle('ready', ready);
    banner.classList.toggle('hidden', !(feat('leagues') || S.tut === 5));
    const tl = nx >= 0 ? S.lg[nx].next : 0;
    const txt = nx < 0 ? 'Leagues' : ready ? 'TOURNAMENT!' : `${Math.floor(tl / 60)}:${String(Math.floor(tl % 60)).padStart(2, '0')}`;
    if (bannerTxt.textContent !== txt) bannerTxt.textContent = txt;
    const bi = nx < 0 ? 'trophy' : SPORTS[nx].icon;
    if (bannerIco.dataset.i !== bi) { bannerIco.dataset.i = bi; bannerIco.innerHTML = ico(bi); }
    const canUp = UPGRADES.some((u) => (S.wallet[u.type] || 0) < u.max && Ledger.inTheBlack(Ledger.buy(u, S.wallet, S)));
    upDot.classList.toggle('hidden', !canUp);
    colDot.classList.toggle('hidden', !S.newSkins);
  }
  AT.refreshHUD = () => { shownCoins = shownTrophies = shownLeague = -1; hudT = 0; updateHUD(0); };

  const toastEl = $('toast');
  let toastTimer = 0;
  function toast(msg, ms = 1800) {
    toastEl.innerHTML = msg; toastEl.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.classList.remove('show'), ms);
  }
  AT.toast = toast;

  const modal = $('modal'), modalCard = $('modalCard');
  let modalHandler = null;
  function showModal(html, handler) {
    resetInput();
    modalCard.innerHTML = html; modalHandler = handler;
    modal.classList.remove('hidden'); modalCard.scrollTop = 0;
  }
  function hideModal() { modal.classList.add('hidden'); modalHandler = null; }
  modal.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (b) Snd.play('tap');
    if (b && b.classList.contains('x')) { hideModal(); return; }
    if (e.target === modal && modalCard.querySelector('.x')) { hideModal(); return; } // tap outside closes closable menus
    if (modalHandler) modalHandler(e, b);
  });
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && AT.modalOpen() && modalCard.querySelector('.x')) hideModal(); });
  AT.showModal = showModal; AT.hideModal = hideModal;
  AT.modalOpen = () => !modal.classList.contains('hidden');

  function upgradesHTML() {
    const rows = UPGRADES.map((u) => {
      const lvl = S.wallet[u.type] || 0, maxed = lvl >= u.max;
      const cost = -Ledger.cost(u, S).COINS;
      const can = !maxed && Ledger.inTheBlack(Ledger.buy(u, S.wallet, S));
      const pips = Array.from({ length: u.max }, (_, i) => `<i class="${i < lvl ? 'on' : ''}"></i>`).join('');
      return `<div class="up"><div class="upi">${ico(u.icon)}</div><div class="upt">${u.name}${u.type === 'UP_AWAY' ? ` <small>${ST.awayH}h</small>` : ''}<div class="pips">${pips}</div></div>
        <button class="buy ${can ? '' : 'off'}" data-t="${u.type}">${maxed ? 'MAX' : ico('coin') + ' ' + fmt(cost)}</button></div>`;
    }).join('');
    const gear = S.wallet.GOLD_GEAR || 0;
    return `<div class="mh"><span>${ico('up')} Upgrades</span><button class="x">${ico('close')}</button></div>${rows}
      <div class="gear">${gear ? `${ico('sparkle')} Gold Gear ×${gear} · +${gear * 6}% training` : ''}</div>
      <div class="sub">${ico('trophy')} Trophies: +${Math.round(ST.incomePct - (S.wallet.UP_PRICE || 0) * 15)}% income</div>`;
  }
  function openUpgrades() {
    showModal(upgradesHTML(), (e, b) => {
      if (!b || !b.dataset.t) return;
      const u = UPGRADES.find((x) => x.type === b.dataset.t);
      if ((S.wallet[u.type] || 0) >= u.max) return;
      const after = Ledger.buy(u, S.wallet, S);
      if (!Ledger.inTheBlack(after)) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); Snd.play('miss'); return; }
      S.wallet = Ledger.add(u, after);
      refreshStats(); task('upgrade');
      Snd.play('buy'); AT.coachEmote('thumbs');
      modalCard.innerHTML = upgradesHTML();
      save();
    });
  }

  // ---------- Athlete Collection ----------
  function collectionHTML() {
    const total = ZONES.length * 5;
    const got = Object.keys(S.skins).length;
    const rows = ZONES.map((Z, z) => {
      const cells = [1, 2, 3, 4, 5].map((t) => {
        const on = !!S.skins[`${z}-${t}`];
        const nm = t === 5 ? SK.LEGENDS[z].name : SK.TIERS[t - 1].name;
        return `<div class="skin ${on ? '' : 'locked'} ${t === 5 ? 'leg' : ''}">
          <img src="${AT.thumbSkin(z, t)}" alt="">
          <span class="sn">${on ? nm : '???'}</span><span class="ss">${IC.stars(t, t)}</span></div>`;
      }).join('');
      return `<div class="zrow"><div class="zh">${ico(Z.icon)} ${Z.name}${S.zones[z].unlocked ? '' : ' ' + ico('lock')}</div><div class="skins">${cells}</div></div>`;
    }).join('');
    return `<div class="mh"><span>${ico('jersey')} Collection</span><button class="x">${ico('close')}</button></div>
      <div class="sub">${got}/${total} skins unlocked · train athletes to earn stars</div>${rows}`;
  }
  function openCollection() {
    S.newSkins = 0; colDot.classList.add('hidden');
    showModal(collectionHTML(), null);
  }

  // ---------- input: floating joystick ----------
  const joyEl = $('joy'), knob = $('knob');
  const joy = { id: null, ox: 0, oy: 0 };
  const JOY_R = 48;
  function resetInput() {
    joy.id = null; input.x = input.y = 0; joyEl.style.display = 'none';
    for (const k in keys) keys[k] = false;
  }
  AT.resetInput = resetInput;
  gameEl.addEventListener('pointerdown', (e) => {
    Snd.unlock();
    if (e.target.closest('button, .card, #scene2d, #modal, #chal, #coinPill')) return;
    if (AT.modalOpen() || (AT.Tourney && AT.Tourney.active)) return;
    if (joy.id !== null) return;
    joy.id = e.pointerId;
    const r = gameEl.getBoundingClientRect();
    joy.ox = e.clientX - r.left; joy.oy = e.clientY - r.top;
    joyEl.style.transform = `translate(${joy.ox}px,${joy.oy}px)`; joyEl.style.display = 'block';
    knob.style.transform = 'translate(0px,0px)';
    input.x = input.y = 0;
    e.preventDefault();
  }, { passive: false });
  window.addEventListener('pointermove', (e) => {
    if (e.pointerId !== joy.id) return;
    const r = gameEl.getBoundingClientRect();
    const px = e.clientX - r.left, py = e.clientY - r.top;
    let dx = px - joy.ox, dy = py - joy.oy;
    let d = Math.hypot(dx, dy);
    if (d > JOY_R) {
      // base follows the finger so direction changes are instant
      joy.ox = px - (dx / d) * JOY_R; joy.oy = py - (dy / d) * JOY_R;
      dx = px - joy.ox; dy = py - joy.oy; d = JOY_R;
      joyEl.style.transform = `translate(${joy.ox}px,${joy.oy}px)`;
    }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    const mag = d < 5 ? 0 : clamp((d - 5) / (JOY_R * 0.75), 0.35, 1);
    input.x = d ? (dx / d) * mag : 0; input.y = d ? (dy / d) * mag : 0;
  }, { passive: true });
  const endJoy = (e) => { if (e.pointerId !== joy.id) return; joy.id = null; input.x = input.y = 0; joyEl.style.display = 'none'; };
  window.addEventListener('pointerup', endJoy);
  window.addEventListener('pointercancel', endJoy);
  // PINCH TO ZOOM (two fingers): spread = closer, pinch = overview; the mouse wheel does the same on desktop
  const pts = new Map();
  let pinch = null;
  const pinchDist = () => { const [a, b] = [...pts.values()]; return Math.max(20, Math.hypot(a.x - b.x, a.y - b.y)); };
  gameEl.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button, .card, #scene2d, #modal, #chal, #coinPill')) return;
    if (AT.modalOpen() || (AT.Tourney && AT.Tourney.active)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 2) {
      joy.id = 'pinch'; input.x = input.y = 0; joyEl.style.display = 'none'; tapStart = null; // no walking while zooming
      pinch = { d: pinchDist(), z: camZoom };
    }
  });
  window.addEventListener('pointermove', (e) => {
    const q = pts.get(e.pointerId); if (!q) return;
    q.x = e.clientX; q.y = e.clientY;
    if (pinch && pts.size >= 2) setZoom(pinch.z * pinch.d / pinchDist());
  }, { passive: true });
  const endPinch = (e) => {
    if (!pts.delete(e.pointerId)) return;
    if (pinch && pts.size < 2) { pinch = null; save(); }
    if (!pts.size && joy.id === 'pinch') joy.id = null;
  };
  window.addEventListener('pointerup', endPinch);
  window.addEventListener('pointercancel', endPinch);
  let wheelSave = 0;
  gameEl.addEventListener('wheel', (e) => {
    if (e.target.closest('.card, #modal, #scene2d') || AT.modalOpen() || (AT.Tourney && AT.Tourney.active)) return;
    e.preventDefault();
    setZoom(camZoom * Math.exp(e.deltaY * 0.0015));
    clearTimeout(wheelSave); wheelSave = setTimeout(() => save(), 600);
  }, { passive: false });
  // TAP A TEAM ATHLETE to send them to a specific training station
  let tapStart = null;
  gameEl.addEventListener('pointerdown', (e) => { tapStart = e.target.closest('button, .card, #scene2d, #modal, #chal, #coinPill') ? null : { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId }; });
  window.addEventListener('pointerup', (e) => {
    const t = tapStart; tapStart = null;
    if (!t || t.id !== e.pointerId || performance.now() - t.t > 350 || Math.hypot(e.clientX - t.x, e.clientY - t.y) > 14) return;
    if (AT.modalOpen() || AT.Tourney.active || inTut()) return;
    const r = gameEl.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
    let best = null, bd = 46;
    for (const a of athletes) {
      if (!a.m.team || a.lvl > 0 || !a.char) continue;
      _tap.set(a.obj.position.x, 1.0, a.obj.position.z).project(camera);
      const d = Math.hypot((_tap.x * 0.5 + 0.5) * r.width - px, (-_tap.y * 0.5 + 0.5) * r.height - py);
      if (d < bd) { bd = d; best = a; }
    }
    if (best) { Snd.play('tap'); openAssign(best); }
  });
  const _tap = new THREE.Vector3();
  function assignHTML(a) {
    const m = a.m, Z = ZONES[m.zone], list = DISC[Z.id];
    let rec = null, rv = -1;
    for (const s of stations) if (s.zone === m.zone) { const v = needScore(m, s.disc); if (v > rv) { rv = v; rec = s.kind; } }
    const rows = list.map((D, k) => {
      const st = stations.find((s) => s.zone === m.zone && s.idx === k);
      const statIc = ['speed', 'bolt', 'heart'].map((n, j) => (D.w[j] > 0 ? ico(n) : '')).join('');
      const who = !st ? `${ico('lock')} Buy its tile first` : st.athlete === a ? 'Training here now' : st.athlete ? `In use by ${displayName(st.athlete.m)}` : 'Free';
      return `<button class="trip stn ${!st ? 'lk' : ''} ${m.pref === D.id ? 'on' : ''}" data-k="${D.id}" ${!st ? 'disabled' : ''}>
        <span class="ti">${ico(ITEMS[D.item].icon)}</span>
        <span class="tm"><b>${D.name}${D.slow ? ' <em class="slow">slower</em>' : ''}</b><span>${statIc} ${D.all ? 'All stats' : ['Speed', 'Power', 'Stamina'].filter((_, j) => D.w[j] > 0).join(' + ')} · ${who}</span></span>
        ${rec === D.id ? '<span class="rec">Best</span>' : ''}</button>`;
    }).join('');
    return `<div class="mh"><span>${ico(Z.icon)} ${displayName(m)}</span><button class="x">${ico('close')}</button></div>
      <div class="sub">Pick where ${displayName(m)} trains. Each station raises different stats.</div>
      <div class="stline">${statBars(m)}</div>
      ${rows}
      <button class="trip stn ${m.pref ? '' : 'on'}" data-k="auto"><span class="ti">${ico('sparkle')}</span><span class="tm"><b>Automatic</b><span>Picks whatever they need most</span></span></button>`;
  }
  function openAssign(a) {
    showModal(assignHTML(a), (e, b) => {
      if (!b || !b.dataset.k) return;
      const m = a.m, k = b.dataset.k;
      hideModal();
      if (k === 'auto') { delete m.pref; toast(`${displayName(m)} picks stations automatically`); save(); return; }
      m.pref = k; save();
      const st = stations.find((s) => s.zone === m.zone && s.kind === k), D = st.disc;
      if (!athletes.includes(a) || a.lvl > 0) return;
      if (st === a.station) { toast(`${displayName(m)} is already at the ${D.name}`); return; }
      const movable = a.state === 'enter' || a.state === 'wait' || a.state === 'train' || a.state === 'line';
      const leaveOld = () => {
        if (a.station) { a.station.athlete = null; a.station = null; }
        const li = line.indexOf(a); if (li >= 0) { line.splice(li, 1); relayoutLine(); }
        a.bar.visible = false; a.t = 0;
      };
      if (movable && !st.athlete) { leaveOld(); assignStation(a, st); toast(`${ico(ITEMS[D.item].icon)} ${displayName(m)} → ${D.name}`); return; }
      const o = st.athlete;
      if (movable && a.station && o && !o.m.team && (o.state === 'enter' || o.state === 'wait')) { // swap with a walk-in
        const old = a.station; old.athlete = null; st.athlete = null; a.bar.visible = false; a.t = 0;
        assignStation(a, st); assignStation(o, old);
        toast(`${ico(ITEMS[D.item].icon)} ${displayName(m)} → ${D.name}`); return;
      }
      toast(`${displayName(m)} will use the ${D.name} next`);
    });
  }
  window.addEventListener('keydown', (e) => { if (!AT.modalOpen()) keys[e.code] = true; Snd.unlock(); });
  window.addEventListener('keyup', (e) => { keys[e.code] = false; });
  window.addEventListener('blur', resetInput);
  gameEl.addEventListener('contextmenu', (e) => e.preventDefault());

  const guard = (fn) => (e) => { e.stopPropagation(); if (AT.Tourney.active || AT.modalOpen()) return; Snd.unlock(); Snd.play('tap'); fn(); };
  $('upBtn').addEventListener('click', guard(openUpgrades));
  $('colBtn').addEventListener('click', guard(openCollection));
  $('leaguePill').addEventListener('click', guard(() => AT.Tourney.openLeague(nextSport())));
  $('trophyPill').addEventListener('click', guard(() => AT.Tourney.openLeague(nextSport())));
  banner.addEventListener('click', guard(() => {
    if (S.tut === 5) { banner.classList.remove('nudge'); AT.Tourney.openPicker(0); return; } // tutorial: straight to the mini tournament
    if (!teamList().some((m) => S.zones[m.zone].unlocked)) { toast(`${ico('scout')} Sign a team athlete at the Scouting Office first!`); return; }
    AT.Tourney.openLeague(nextSport());
  }));
  // settings (gear): separate music and sound-effect switches, saved with the game
  const settingRow = (k, on, icon, label) => `<button class="setrow" data-s="${k}">${ico(icon)}<span>${label}</span><b class="${on ? 'on' : ''}">${on ? 'ON' : 'OFF'}</b></button>`;
  const settingsHTML = () => `<div class="mh"><span>${ico('gear')} Settings</span><button class="x">${ico('close')}</button></div>
      ${settingRow('music', S.music, S.music ? 'music' : 'musicOff', 'Music')}
      ${settingRow('sound', S.sound, S.sound ? 'soundOn' : 'soundOff', 'Sound effects')}
      <button class="setrow" data-look="1">${ico('jersey')}<span>Coach look</span><b class="on">EDIT</b></button>
      <div class="sub">Progress saves automatically</div>`;
  const applyAudio = () => { Snd.musicOn = !!S.music; Snd.sfxOn = !!S.sound; Snd.apply(); };
  $('setBtn').addEventListener('click', guard(() => showModal(settingsHTML(), (e, b) => {
    if (b && b.dataset.look) { openCoachCreator(false); return; }
    if (!b || !b.dataset.s) return;
    S[b.dataset.s] = !S[b.dataset.s]; applyAudio(); Snd.unlock(); Snd.play('tap'); modalCard.innerHTML = settingsHTML(); save();
  })));
  // COACH CREATOR: skin tone, hairstyle, hair colour, male / female, cap or headband
  const HAIR_OPTS = { m: ['short', 'spiky', 'quiff', 'buzz', 'afro', 'mohawk', 'bald'], f: ['ponytail', 'buns', 'long', 'bob', 'braids', 'afro', 'short'] };
  const HAIR_NAMES = { short: 'Short', spiky: 'Spiky', quiff: 'Quiff', buzz: 'Buzz cut', afro: 'Afro', mohawk: 'Mohawk', bald: 'Bald', ponytail: 'Ponytail', buns: 'Buns', long: 'Long', bob: 'Bob', braids: 'Braids' };
  function openCoachCreator(first) {
    const L = Object.assign({}, S.look || DEFAULT_LOOK);
    const hex = (c) => '#' + c.toString(16).padStart(6, '0');
    const html = () => {
      const img = SK.thumb(renderer, `pl-${L.sex}${L.skin}${L.hair}${L.hairCol}${L.hat}-${coachTierNow()}`, () => SK.player({ look: L, tier: coachTierNow() }));
      const sw = (k, list, cur) => list.map((c, i) => `<button class="sw ${i === cur ? 'on' : ''}" data-k="${k}" data-v="${i}" style="background:${hex(c)}"></button>`).join('');
      const chips = (k, list, names, cur) => list.map((v) => `<button class="chip2 ${v === cur ? 'on' : ''}" data-k="${k}" data-v="${v}">${names[v]}</button>`).join('');
      return `<div class="mh"><span>${ico('jersey')} ${first ? 'Create your coach' : 'Coach look'}</span>${first ? '' : `<button class="x">${ico('close')}</button>`}</div>
        <div class="cc"><img class="ccimg" src="${img}" alt=""><div class="ccopt">
          <div class="cl">Coach</div><div class="row2">${chips('sex', ['m', 'f'], { m: 'Male', f: 'Female' }, L.sex)}</div>
          <div class="cl">Skin tone</div><div class="row2">${sw('skin', SK.PLAYER_SKINS, L.skin)}</div>
          <div class="cl">Hair colour</div><div class="row2">${sw('hairCol', SK.PLAYER_HAIRS, L.hairCol)}</div>
        </div></div>
        <div class="cl">Hairstyle</div><div class="row2">${chips('hair', HAIR_OPTS[L.sex], HAIR_NAMES, L.hair)}</div>
        <div class="cl">Headwear</div><div class="row2">${chips('hat', ['cap', 'band', 'none'], { cap: 'Cap', band: 'Headband', none: 'None' }, L.hat)}</div>
        <div class="sub">Your tracksuit upgrades as the academy grows: premium jacket at 3 zones, golden jacket at 5</div>
        <button class="go" data-go="1">${first ? "Let's go!" : 'Save'} ${ico('check')}</button>`;
    };
    showModal(html(), (e, b) => {
      if (!b) return;
      if (b.dataset.k) {
        const k = b.dataset.k, v = b.dataset.v;
        L[k] = k === 'skin' || k === 'hairCol' ? +v : v;
        if (k === 'sex' && !HAIR_OPTS[v].includes(L.hair)) L.hair = HAIR_OPTS[v][0];
        modalCard.innerHTML = html(); return;
      }
      if (b.dataset.go) { S.look = L; refreshCoachLook(false); SK.emote(coach.char, 'cheer', 1.6); hideModal(); save(true); toast(`${ico('whistle')} Looking sharp, Coach!`); }
    });
  }
  AT.openCoachCreator = openCoachCreator;
  const nudge = (b) => { if (b) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); } Snd.play('miss'); };
  const pulseEl = (el) => { el.classList.remove('nudge'); void el.offsetWidth; el.classList.add('nudge'); setTimeout(() => el.classList.remove('nudge'), 3200); };

  // ======================================================================
  // DAYS + POPUP QUEUE
  // ======================================================================
  const dayStr = (off = 0) => { const d = new Date(Date.now() + ((S.dayShift || 0) + off) * 864e5); return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`; };
  const topZone = () => S.zones.reduce((a, z, i) => (z.unlocked && ZONES[i].fee > ZONES[a].fee ? i : a), 0); // best-paying open zone
  const topFee = () => ZONES[topZone()].fee;
  const round10 = (n) => Math.max(10, Math.round(n / 10) * 10);
  const mmss = (s) => { s = Math.max(0, Math.ceil(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
  // popups (welcome back, login calendar) wait their turn: one at a time, never over a tournament
  const popups = [];
  const popup = (key, fn) => { if (!popups.some((p) => p.key === key)) popups.push({ key, fn }); };
  function pumpPopups() { if (popups.length && !AT.modalOpen() && !AT.Tourney.active && time > 0.8 && !inTut()) popups.shift().fn(); }

  // ======================================================================
  // TEAM: named athletes with rarity and Speed / Power / Stamina
  // ======================================================================
  function makeTalent(rar, zone, taken = []) {
    const R = RARITY[rar], w = STAT_W[Math.max(0, sportOfZone(zone))];
    const used = new Set(S.roster.map((m) => m.name).concat(taken));
    const free = NAMES.filter((n) => !used.has(n));
    const st = [0, 1, 2].map((k) => Math.min(R.cap, Math.round(rand(R.stat[0], R.stat[1]) + (w[k] >= 0.45 ? 6 : 0))));
    return { id: S.nextId++, name: free.length ? pick(free) : pick(NAMES) + ' ' + S.nextId, zone, xp: STAR_XP[R.stars - 1], skin: (Math.random() * SKINS.length) | 0, hair: (Math.random() * HAIRS.length) | 0, team: 1, rar, st, en: 100 };
  }
  function joinTeam(m) {
    m.team = 1; S.roster.push(m);
    for (let t = 1; t <= starsOf(m); t++) unlockSkin(m.zone, t);
    S.stat.signed++; S.stat.bestRar = Math.max(S.stat.bestRar, m.rar);
  }
  // new games start with one Common track athlete; older saves turn their best athlete per sport into team members
  function ensureTeam() {
    if (S.teamOK >= 2) return;
    const first = !S.teamOK;
    S.teamOK = 2;
    SPORTS.forEach((sp, i) => {
      if (teamList().length >= teamSlots() || !sportOpen(i) || sportHasAthletes(i)) return;
      const best = S.roster.filter((m) => !m.team && sp.zones.includes(m.zone) && S.zones[m.zone].unlocked).sort((a, b) => b.xp - a.xp)[0];
      if (!best) return;
      const s = starsOf(best), rar = s >= 4 ? 2 : s >= 3 ? 1 : 0, w = STAT_W[i];
      best.team = 1; best.rar = rar;
      best.st = [0, 1, 2].map((k) => Math.round(8 + s * 7 + rand(0, 6) + (w[k] >= 0.45 ? 6 : 0)));
    });
    if (!teamList().length) joinTeam(makeTalent(0, 0));
    if (first) S.stat.signed = 0;
  }
  const statBars = (m) => ['SPD', 'POW', 'STA'].map((n, k) => `<div class="sb"><span>${n}</span><i><b style="width:${Math.round(m.st[k])}%"></b></i><em>${Math.round(m.st[k])}</em></div>`).join('');
  // talent / team card: the athlete in their sport outfit, sport icon in the corner, rarity frame colour
  function talentCard(m, sel, attrs, foot = '', tag = 'button') {
    const R = RARITY[m.rar || 0], st = starsOf(m);
    return `<${tag} class="tal r${m.rar || 0} ${sel ? 'sel' : ''}" ${attrs} style="--rc:${R.col}"><span class="rt">${R.name}</span>
      <img class="ap" src="${AT.thumbFor(m)}" alt=""><span class="az">${ico(ZONES[m.zone].icon)}</span>
      <span class="an">${displayName(m)}</span><span class="as">${IC.stars(st)}</span>${statBars(m)}
      <span class="gr">${ico('up')} Grows ×${R.grow}</span>${foot}</${tag}>`;
  }
  function teamHTML() {
    const list = teamList().sort((a, b) => sportOfZone(a.zone) - sportOfZone(b.zone) || starsOf(b) - starsOf(a));
    const slots = teamSlots();
    const cards = list.map((m) => {
      const st = starsOf(m), p = st >= 5 ? 1 : clamp((m.xp - STAR_XP[st - 1]) / (STAR_XP[st] - STAR_XP[st - 1]), 0, 1);
      return talentCard(m, false, '', `${AT.energyBar(enOf(m))}<div class="xp"><i style="width:${Math.round(p * 100)}%"></i></div>
        <span class="pw">${ico('bolt')} ${Math.round(athPower(m))} power</span><button class="rel" data-rel="${m.id}">Release</button>`, 'div');
    }).join('') + Array.from({ length: Math.max(0, slots - list.length) }, () => `<div class="tal empty">${ico('plus')}<span>Empty slot</span></div>`).join('');
    return `<div class="mh"><span>${ico('team')} Team · ${list.length}/${slots}</span><button class="x">${ico('close')}</button></div>
      <div class="sub">Only team athletes play tournaments, leagues and challenges. They train in the academy to earn stars.</div>
      <div class="tgrid">${cards}</div>
      <div class="sub">${S.office ? `${ico('scout')} Scouting Office Lv ${S.office} · upgrade it for more slots` : `${ico('scout')} Build the Scouting Office in the lobby to sign new talent`}</div>`;
  }
  function openTeam() {
    showModal(teamHTML(), (e, b) => {
      if (!b || !b.dataset.rel) return;
      const m = S.roster.find((x) => x.id === +b.dataset.rel);
      if (m) confirmRelease(m);
    });
  }
  function confirmRelease(m) {
    showModal(`<div class="mh"><span>${ico('team')} Release athlete?</span></div>
      <div class="conf">${talentCard(m, false, '', '', 'div')}<p>Release <b>${displayName(m)}</b> from your team? This frees a slot and can't be undone.</p></div>
      <div class="ch-btns"><button class="no" data-c="no">Keep</button><button class="yes danger" data-c="yes">Release</button></div>`, (e, b) => {
      if (!b) return;
      if (b.dataset.c === 'yes') {
        const i = S.roster.indexOf(m);
        if (i >= 0) S.roster.splice(i, 1);
        Snd.play('release'); toast(`${displayName(m)} left the team`); save(true);
      }
      openTeam();
    });
  }

  // ======================================================================
  // SCOUTING OFFICE: trips take real time, then 3 talent cards to pick from
  // ======================================================================
  const OFFICE = { x: -5.0, z: 13.0 }, PAD = { x: -3.05, z: 13.0 };
  let officeObj = null, officeBub = null, officeShown = '', padWas = true, offSel = -1, officeT = 0;
  const offCanvas = document.createElement('canvas'); offCanvas.width = 640; offCanvas.height = 300;
  let offTex = null;
  function drawOfficeBub(state, text) {
    const g = offCanvas.getContext('2d');
    g.setTransform(4, 0, 0, 4, 0, 0); g.clearRect(0, 0, 160, 75);
    const gold = state === 'back';
    rr(g, 6, 8, 148, 52, 26); g.fillStyle = 'rgba(0,0,0,.18)'; g.fill();
    rr(g, 6, 4, 148, 52, 26); g.fillStyle = gold ? '#ffd43b' : '#fff'; g.fill(); g.lineWidth = 6.5; g.strokeStyle = gold ? '#fff' : '#15aabf'; g.stroke();
    g.fillStyle = gold ? '#fff' : '#fff'; g.beginPath(); g.moveTo(70, 56); g.lineTo(80, 72); g.lineTo(90, 56); g.fill();
    IC.draw(g, state === 'trip' ? 'hourglass' : state === 'back' ? 'star' : 'scout', 34, 30, 36);
    g.fillStyle = '#2b2d42'; g.font = `900 30px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; boldText(g, text, 98, 31, 96, 1.6);
    if (!offTex) offTex = crispTex(new THREE.CanvasTexture(offCanvas)); else offTex.needsUpdate = true;
    return offTex;
  }
  function buildOffice() {
    if (officeObj || !S.office) return;
    const g = new THREE.Group(); g.position.set(OFFICE.x, 0.12, OFFICE.z);
    g.add(B(2.3, 0.14, 1.6, 0xe3fafc, 0, 0.07, 0));
    g.add(B(2.1, 1.6, 1.36, 0x66d9e8, -0.05, 0.94, 0));
    g.add(B(2.34, 0.16, 1.62, 0x1864ab, 0, 1.82, 0), B(2.0, 0.12, 1.3, 0x1c7ed6, 0, 1.96, 0));
    g.add(B(0.05, 1.05, 0.62, 0x1864ab, 1.0, 0.66, 0.1), B(0.06, 0.9, 0.48, 0xfff3bf, 1.02, 0.6, 0.1));  // door
    for (const x of [-0.6, 0.2]) g.add(B(0.56, 0.5, 0.05, 0xffffff, x, 1.12, 0.7), B(0.46, 0.4, 0.06, 0xa5d8ff, x, 1.12, 0.71)); // windows
    g.add(B(0.9, 0.55, 0.05, 0xfff9db, 0.55, 0.5, 0.7), B(0.08, 0.12, 0.06, 0xe03131, 0.35, 0.6, 0.72), B(0.08, 0.12, 0.06, 0x1c7ed6, 0.7, 0.42, 0.72)); // map board with pins
    const globe = new THREE.Group(); globe.position.set(-0.55, 2.45, 0);
    globe.add(mesh(sphG(0.36, 12, 8), M(0x4dabf7, 'shiny')));
    const land = mesh(sphG(0.365, 6, 4), M(0x51cf66)); land.scale.set(0.7, 0.9, 0.6); land.position.x = 0.06; globe.add(land);
    g.add(mesh(cylG(0.04, 0.04, 0.4, 6), M(0xadb5bd), -0.55, 2.12, 0), globe);
    g.userData.globe = globe;
    const sign = spr(labelTex('Scouting', '#15aabf', 'scout'), 2.2, 0.55, 8); sign.position.set(0.25, 2.6, 0.3); g.add(sign);
    officeBub = spr(drawOfficeBub('idle', 'Scout'), 1.3, 0.61, 12); officeBub.position.set(1.95, 2.0, 0); g.add(officeBub);
    const pad = mesh(GEO('pad', () => new THREE.CircleGeometry(0.8, 24)), new THREE.MeshBasicMaterial({ color: 0x3bc9db, transparent: true, opacity: 0.5, depthWrite: false }), PAD.x - OFFICE.x, 0.025, 0);
    pad.rotation.x = -Math.PI / 2; g.add(pad);
    world.add(g); officeObj = g;
    addCol(OFFICE.x, OFFICE.z, 1.15, 0.78);
    officeShown = '';
  }
  const tripOdds = (i) => {
    const o = TRIPS[i].odds.slice(), b = (Math.max(1, S.office) - 1) * 3; // each office level moves 3% from Common to the rarer tiers
    o[0] = Math.max(5, o[0] - b); o[1] += b * 0.5; o[2] += b * 0.33; o[3] += b * 0.17;
    const sum = o.reduce((a, v) => a + v, 0);
    return o.map((v) => (v / sum) * 100);
  };
  function rollRar(o) { let r = Math.random() * 100; for (let k = 0; k < 4; k++) { if (r < o[k]) return k; r -= o[k]; } return 0; }
  function sendScout(i) {
    const T = TRIPS[i];
    if (S.scout) return 'busy';
    if (S.office < T.lvl) return 'lvl';
    const free = S.scoutFree > 0;
    if (!free && S.wallet.COINS < T.cost) return 'coins';
    if (free) S.scoutFree--; else spendCoins(T.cost);
    S.scout = { trip: i, ends: Date.now() + T.min * 60000, cards: null, odds: tripOdds(i) };
    S.stat.trips++; task('scout'); save(true);
    return 'ok';
  }
  function scoutCheck() {
    const c = S.scout;
    if (!c || c.cards || Date.now() < c.ends) return;
    const zones = S.zones.map((z, i) => (z.unlocked ? i : -1)).filter((i) => i >= 0), taken = [];
    c.cards = [0, 1, 2].map(() => { const m = makeTalent(rollRar(c.odds || TRIPS[c.trip].odds), pick(zones), taken); taken.push(m.name); return m; });
    Snd.play('scout');
    toast(`${ico('scout')} Your scout is back with 3 talents!`, 2800);
    if (officeBub) bounce(officeBub);
    save();
  }
  function officeHTML() {
    const lvl = S.office, sc = S.scout, team = teamList().length, slots = teamSlots();
    let body;
    if (sc && sc.cards) {
      const full = team >= slots;
      body = `<div class="sub">${ico(TRIPS[sc.trip].icon)} ${TRIPS[sc.trip].name} trip · pick ONE talent to sign</div>
        <div class="tgrid">${sc.cards.map((m, i) => talentCard(m, i === offSel, `data-pick="${i}"`)).join('')}</div>
        ${full ? `<div class="next lk">${ico('team')} Team full (${team}/${slots}) · release an athlete to sign</div><button class="go alt" data-team="1">Open Team</button>`
          : `<button class="go ${offSel >= 0 ? '' : 'off'}" data-sign="1">${offSel >= 0 ? `Sign ${sc.cards[offSel].name}` : 'Pick a talent'} ${ico('check')}</button>`}
        <button class="link" data-pass="1">Pass on all three</button>`;
    } else if (sc) {
      const T = TRIPS[sc.trip], left = (sc.ends - Date.now()) / 1000;
      body = `<div class="trip on"><span class="ti">${ico(T.icon)}</span><div class="tm"><b>${T.name} trip</b><span>Your scout is looking for talent…</span></div><b class="tc" id="scoutT">${mmss(left)}</b></div>
        <div class="bar"><i id="scoutBar" style="width:${Math.round(clamp(1 - left / (T.min * 60), 0, 1) * 100)}%"></i></div>
        <div class="sub">The trip keeps going while the game is closed</div>`;
    } else {
      body = `<div class="sub">Send your scout on a trip${S.scoutFree ? ` · ${ico('ticket')} ${S.scoutFree} free trip${S.scoutFree > 1 ? 's' : ''}` : ''}</div>` + TRIPS.map((T, i) => {
        const locked = lvl < T.lvl, odds = tripOdds(i);
        return `<button class="trip ${locked ? 'lk' : ''}" data-trip="${i}"><span class="ti">${ico(T.icon)}</span>
          <div class="tm"><b>${T.name}</b><span>${ico('stopwatch')} ${T.min} min</span>
          <div class="odds">${odds.map((o, k) => `<i style="background:${RARITY[k].col};flex:${Math.max(o, 2.5).toFixed(1)}"></i>`).join('')}</div>
          <span class="op">${odds.map((o, k) => `${RARITY[k].name[0]} ${o < 1 ? o.toFixed(1) : Math.round(o)}%`).join(' · ')}</span></div>
          <span class="tc">${locked ? `${ico('lock')} Lv ${T.lvl}` : S.scoutFree ? 'FREE' : `${ico('coin')} ${fmt(T.cost)}`}</span></button>`;
      }).join('');
    }
    const nextTrip = TRIPS.find((T) => T.lvl === lvl + 1);
    const up = lvl < OFFICE_MAX
      ? `<div class="up"><div class="upi">${ico('scout')}</div><div class="upt">Office Lv ${lvl + 1}<span class="ud">+1 team slot · better odds${nextTrip ? ` · ${nextTrip.name} trips` : ''}</span></div>
        <button class="buy ${S.wallet.COINS >= OFFICE_COST[lvl] ? '' : 'off'}" data-up="1">${ico('coin')} ${fmt(OFFICE_COST[lvl])}</button></div>`
      : `<div class="sub">${ico('crown')} Office at max level</div>`;
    return `<div class="mh"><span>${ico('scout')} Scouting · Lv ${lvl}</span><button class="x">${ico('close')}</button></div>
      <div class="slots"><span>${ico('team')} Team ${team}/${slots}</span><span class="leg">${RARITY.map((R) => `<i style="background:${R.col}"></i>${R.name}`).join(' ')}</span></div>${body}${up}`;
  }
  const officeOpen = () => AT.modalOpen() && !!modalCard.querySelector('.slots');
  const renderOffice = () => { if (officeOpen()) { const y = modalCard.scrollTop; modalCard.innerHTML = officeHTML(); modalCard.scrollTop = y; } };
  function openOffice() {
    offSel = -1;
    showModal(officeHTML(), (e, b) => {
      if (!b) return;
      const d = b.dataset;
      if (d.trip != null) {
        const r = sendScout(+d.trip);
        if (r === 'ok') { Snd.play('buy'); renderOffice(); }
        else { nudge(b); toast(r === 'coins' ? `${ico('coin')} Not enough coins` : `${ico('lock')} Upgrade the office to Lv ${TRIPS[+d.trip].lvl}`); }
      } else if (d.pick != null) { offSel = +d.pick; renderOffice(); }
      else if (d.sign && S.scout && S.scout.cards) {
        if (offSel < 0 || teamList().length >= teamSlots()) { nudge(b); return; }
        const m = S.scout.cards[offSel];
        joinTeam(m); S.scout = null;
        hideModal(); Snd.play('sign'); confetti(coach.obj.position.x, 1, coach.obj.position.z, 30);
        toast(`${ico('team')} ${m.name} joined your team! <b style="color:${RARITY[m.rar].col}">${RARITY[m.rar].name}</b>`, 2600);
        save(true);
      } else if (d.pass) { S.scout = null; offSel = -1; renderOffice(); save(); }
      else if (d.team) openTeam();
      else if (d.up) {
        if (S.office >= OFFICE_MAX) return;
        const c = OFFICE_COST[S.office];
        if (S.wallet.COINS < c) { nudge(b); return; }
        spendCoins(c); S.office++; Snd.play('level'); renderOffice(); save(true);
        toast(`${ico('scout')} Scouting Office Lv ${S.office}! Team slots: ${teamSlots()}`);
      }
    });
  }
  function updateOffice(dt) {
    if (!officeObj) return;
    officeObj.userData.globe.rotation.y += dt * 0.8;
    officeBub.position.y = 2.0 + Math.sin(time * 3) * 0.07;
    // walking onto the pad opens the office (step off and back on to reopen)
    const on = d2(coach.obj.position, PAD.x, PAD.z) < 0.8;
    if (on && !padWas && !AT.modalOpen() && !AT.Tourney.active) { Snd.play('tap'); openOffice(); }
    padWas = on;
    if ((officeT -= dt) > 0) return;
    officeT = 0.25;
    const sc = S.scout;
    const state = sc ? (sc.cards ? 'back' : 'trip') : 'idle';
    const left = sc && !sc.cards ? (sc.ends - Date.now()) / 1000 : 0;
    const text = state === 'trip' ? mmss(left) : state === 'back' ? '3 new!' : S.scoutFree ? 'FREE' : 'Scout';
    if (state + text !== officeShown) { officeShown = state + text; drawOfficeBub(state, text); }
    officeBub.scale.setScalar(1).set(1.3, 0.61, 1);
    if (state === 'back') officeBub.scale.multiplyScalar(1 + 0.08 * Math.abs(Math.sin(time * 5)));
    if (officeOpen()) {
      const t = $('scoutT');
      if (t && sc && !sc.cards) { t.textContent = mmss(left); const bar = $('scoutBar'); if (bar) bar.style.width = `${Math.round(clamp(1 - left / (TRIPS[sc.trip].min * 60), 0, 1) * 100)}%`; }
      else if (t && sc && sc.cards) renderOffice();
    }
  }

  // ======================================================================
  // DAILY TASKS, BONUS CHEST AND THE 7-DAY LOGIN CALENDAR
  // ======================================================================
  const TASKS = {
    win: { goals: [2, 3], txt: (g, sp) => `Win ${g} ${SPORT_EVENT[sp]}`, icon: (sp) => SPORTS[sp].icon },
    train: { goals: [20, 30, 40], txt: (g) => `Train ${g} athletes`, icon: () => 'stopwatch' },
    deliver: { goals: [30, 50, 80], txt: (g) => `Deliver ${g} items`, icon: () => 'boxes' },
    coins: { goals: [1], txt: (g) => `Earn ${fmt(g)} coins at reception`, icon: () => 'coin' },
    chal: { goals: [1], txt: () => 'Accept 1 rival challenge', icon: () => 'swords' },
    scout: { goals: [1], txt: () => 'Send a scout on a trip', icon: () => 'scout' },
    tourney: { goals: [1, 2], txt: (g) => `Play ${g} tournament${g > 1 ? 's' : ''}`, icon: () => 'trophy' },
    upgrade: { goals: [1], txt: () => 'Buy 1 upgrade', icon: () => 'up' },
  };
  const LOGIN_MULT = [1, 1.5, 2, 2.5, 3, 4, 8];
  const taskBase = () => round10(40 + topFee() * 10);
  const loginReward = (d) => round10((50 + topFee() * 10) * LOGIN_MULT[d - 1]);
  const loginReady = () => S.login.day !== dayStr();
  const loginNext = () => (S.login.day === dayStr(-1) ? (S.login.streak % 7) + 1 : 1);
  function newDaily() {
    const sports = SPORTS.map((_, i) => i).filter(sportHasAthletes);
    const pool = ['train', 'deliver', 'coins', 'upgrade'];
    if (feat('leagues')) pool.push('tourney');
    if (feat('rivals')) pool.push('chal');
    if (S.office) pool.push('scout', 'scout');
    const keys = sports.length && feat('leagues') ? ['win'] : [];
    while (keys.length < 3) { const k = pick(pool); if (!keys.includes(k)) keys.push(k); }
    const base = taskBase();
    S.daily = {
      day: dayStr(), chest: false,
      tasks: keys.map((k) => ({ k, sp: k === 'win' ? pick(sports) : null, goal: k === 'coins' ? round10(topFee() * 40) : pick(TASKS[k].goals), prog: 0, reward: round10(base * rand(0.9, 1.4)), claimed: false })),
    };
  }
  function task(k, n = 1, sp) {
    if (!S || !S.daily) return;
    for (const t of S.daily.tasks) {
      if (t.k !== k || t.prog >= t.goal || (t.sp != null && sp !== t.sp)) continue;
      t.prog = Math.min(t.goal, t.prog + n);
      if (t.prog >= t.goal) { toast(`${ico('check')} Task done: ${TASKS[k].txt(t.goal, t.sp)}`, 2200); Snd.play('level'); }
    }
  }
  AT.task = task;
  let loginShown = '', dayT = 0;
  function dayCheck() {
    const today = dayStr();
    if (!S.daily || S.daily.day !== today) { const had = !!S.daily; newDaily(); if (had) toast(`${ico('calendar')} New daily tasks!`); save(); }
    if (loginReady() && loginShown !== today) { loginShown = today; popup('login', openDaily); }
  }
  const dailyReady = () => loginReady() || S.daily.tasks.some((t) => t.prog >= t.goal && !t.claimed) || (!S.daily.chest && S.daily.tasks.every((t) => t.claimed));
  function dailyHTML() {
    const ready = loginReady(), todayN = ready ? loginNext() : 0, done = ready ? todayN - 1 : S.login.streak;
    const cal = [1, 2, 3, 4, 5, 6, 7].map((d) => `<div class="cd ${d <= done ? 'got' : ''} ${d === todayN ? 'now' : ''} ${d === 7 ? 'big' : ''}">
      <span>Day ${d}</span>${ico(d === 7 ? 'chest' : 'coin')}<b>${fmt(loginReward(d))}</b>${d === 7 ? `<em>${ico('ticket')}${ico('sparkle')}</em>` : ''}${d <= done ? `<s>${ico('check')}</s>` : ''}</div>`).join('');
    const now = new Date(Date.now() + (S.dayShift || 0) * 864e5), mid = new Date(now); mid.setHours(24, 0, 0, 0);
    const left = (mid - now) / 1000, hh = Math.floor(left / 3600), mm = Math.floor((left % 3600) / 60);
    const D = S.daily, allClaimed = D.tasks.every((t) => t.claimed);
    const tasks = D.tasks.map((t, i) => {
      const T = TASKS[t.k], p = clamp(t.prog / t.goal, 0, 1);
      return `<div class="task ${t.claimed ? 'done' : ''}"><span class="tk">${ico(T.icon(t.sp))}</span>
        <div class="tt"><b>${T.txt(t.goal, t.sp)}</b><div class="bar"><i style="width:${Math.round(p * 100)}%"></i></div><span>${t.k === 'coins' ? `${fmt(t.prog)}/${fmt(t.goal)}` : `${t.prog}/${t.goal}`}</span></div>
        ${t.claimed ? `<span class="ok">${ico('check')}</span>` : `<button class="buy ${t.prog >= t.goal ? '' : 'off'}" data-claim="${i}">${ico('coin')} ${fmt(t.reward)}</button>`}</div>`;
    }).join('');
    return `<div class="mh"><span>${ico('calendar')} Daily</span><button class="x">${ico('close')}</button></div>
      <div class="sec">Login streak · day 7 is the big one</div>
      <div class="cal">${cal}</div>
      ${ready ? `<button class="go" data-login="1">Claim day ${todayN} ${ico('coin')} ${fmt(loginReward(todayN))}</button>` : `<div class="sub">Come back tomorrow for day ${(S.login.streak % 7) + 1}</div>`}
      <div class="sec">Daily tasks · new in ${hh}h ${mm}m</div>${tasks}
      <div class="chestrow ${D.chest ? 'done' : allClaimed ? 'ready' : ''}"><span class="ci">${ico('chest')}</span>
        <div><b>Bonus chest</b><span>${D.chest ? 'Opened · new tasks tomorrow' : 'Finish all 3 tasks · coins + a chance at a free scouting trip'}</span></div>
        ${D.chest ? `<span class="ok">${ico('check')}</span>` : `<button class="buy ${allClaimed ? '' : 'off'}" data-chest="1">Open</button>`}</div>`;
  }
  const coinBurst = (n) => flyCoins(_v.set(coach.obj.position.x + rand(-1, 1), 0, coach.obj.position.z - 2.5), coach, n);
  function openDaily() {
    showModal(dailyHTML(), (e, b) => {
      if (!b) return;
      const d = b.dataset, D = S.daily;
      if (d.login && loginReady()) {
        const n = loginNext(), amt = loginReward(n);
        S.login = { day: dayStr(), streak: n };
        addCoins(amt); coinBurst(6);
        let extra = '';
        if (n === 7) { S.scoutFree++; addItem('GOLD_GEAR'); extra = ` + ${ico('ticket')} free scouting trip + ${ico('sparkle')} Gold Gear`; Snd.play('chest'); } else Snd.play('buy');
        toast(`Day ${n}: +${fmt(amt)} ${ico('coin')}${extra}`, 2600);
      } else if (d.claim != null) {
        const t = D.tasks[+d.claim];
        if (!t || t.claimed || t.prog < t.goal) { nudge(b); return; }
        t.claimed = true; addCoins(t.reward); coinBurst(4); Snd.play('buy');
      } else if (d.chest) {
        if (D.chest || !D.tasks.every((t) => t.claimed)) { nudge(b); return; }
        D.chest = true;
        const amt = round10(taskBase() * 4), trip = Math.random() < 0.4;
        addCoins(amt); coinBurst(8); Snd.play('chest');
        if (trip) S.scoutFree++;
        toast(`${ico('chest')} +${fmt(amt)} ${ico('coin')}${trip ? ` + ${ico('ticket')} free scouting trip!` : ''}`, 2800);
      } else return;
      const y = modalCard.scrollTop; modalCard.innerHTML = dailyHTML(); modalCard.scrollTop = y;
      save(true);
    });
  }

  // ======================================================================
  // OFFLINE EARNINGS: staff and open zones keep earning (capped, upgradeable)
  // ======================================================================
  function offlineRate() {
    let r = 0;
    S.zones.forEach((z, i) => { if (z.unlocked) r += ((z.stations * ZONES[i].fee * ST.income) / 16) * (0.3 + 0.7 * Math.min(1, z.assistants)); });
    return r * (S.recep ? 1 : 0.6);
  }
  function awayEarnings(ms) {
    const secs = Math.min(Math.max(0, ms) / 1000, ST.awayH * 3600);
    if (secs < 60) return;
    const amt = Math.floor(offlineRate() * secs);
    if (amt < 1) return;
    S.offlinePend = (S.offlinePend || 0) + amt;
    S.offlineSecs = Math.min(ST.awayH * 3600, (S.offlineSecs || 0) + secs);
    popup('away', openAway);
  }
  function openAway() {
    const amt = S.offlinePend || 0;
    if (amt < 1) return;
    const s = S.offlineSecs || 0, h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    const rain = Array.from({ length: 14 }, (_, i) => `<i style="left:${4 + i * 6.8}%;animation-delay:${(i * 0.37) % 1.6}s;animation-duration:${1.4 + (i % 4) * 0.25}s">${ico('coin')}</i>`).join('');
    showModal(`<div class="mh"><span>${ico('hand')} Welcome back!</span></div>
      <div class="away"><div class="rain">${rain}</div><div class="al">While you were away</div>
        <div class="amt">${ico('coin')} <b id="awayN">0</b></div>
        <div class="sub">${h ? `${h}h ` : ''}${m}m away · your staff kept earning (up to ${ST.awayH}h; more with Away Time upgrades)</div></div>
      <button class="go" data-go="1">Collect</button>`, (e, b) => {
      if (!b || !b.dataset.go) return;
      const got = S.offlinePend || 0;
      S.offlinePend = 0; S.offlineSecs = 0;
      addCoins(got); hideModal(); coinBurst(10); Snd.play('buy');
      toast(`+${fmt(got)} ${ico('coin')}`); save(true);
    });
    // count-up animation
    const t0 = performance.now();
    const iv = setInterval(() => {
      const el = $('awayN'); if (!el) { clearInterval(iv); return; }
      const k = Math.min(1, (performance.now() - t0) / 1100);
      el.textContent = fmt(amt * (1 - Math.pow(1 - k, 3)));
      if (k < 1) Snd.play('tick', 70); else clearInterval(iv);
    }, 40);
  }

  // ======================================================================
  // GOALS: the bar at the top always shows the next goal; tap it for an arrow
  // ======================================================================
  const upCount = () => UPGRADES.reduce((a, u) => a + (S.wallet[u.type] || 0), 0);
  const zoneGoal = (i, t) => ({ t, ok: () => S.zones[i].unlocked, tile: 'zone' + i, hint: i === 1 ? 'Build a 3rd Track station or hire a helper first' : `Build 2 stations in the ${ZONES[prevZone(i)].name} first` });
  const GOALS = [
    { t: 'Build a 2nd Track station', ok: () => S.zones[0].stations >= 2, tile: 'st0_' },
    { t: 'Hire a receptionist', ok: () => S.recep, tile: 'recep' },
    zoneGoal(1, 'Open the Gym'),
    { t: 'Play your first tournament', ok: () => S.played >= 1, ui: 'banner', hint: 'Tap the banner when a tournament is ready' },
    { t: 'Build the Scouting Office', ok: () => S.office > 0, tile: 'scout' },
    { t: 'Send a scout on a trip', ok: () => S.stat.trips >= 1, at: 'office' },
    { t: 'Sign a new talent', ok: () => S.stat.signed >= 1, at: 'office', hint: 'Wait for your scout to come back' },
    { t: 'Build 4 Track stations', ok: () => S.zones[0].stations >= 4, tile: 'st0_' },
    { t: 'Hire a Track assistant', ok: () => S.zones[0].assistants >= 1, tile: 'as0' },
    { t: 'Reach Regional League in Track', ok: () => S.lg[0].best >= 1, ui: 'banner', hint: 'Score 8 points in the Track league' },
    { t: 'Build the Recovery Room', ok: () => S.recov > 0, tile: 'recov', hint: 'It unlocks after a few tournaments' },
    zoneGoal(2, 'Open the Football pitch'),
    { t: 'Buy 3 upgrades', ok: () => upCount() >= 3, ui: 'up' },
    { t: 'Upgrade the Scouting Office', ok: () => S.office >= 2, at: 'office' },
    { t: 'Reach Regional League in Gym', ok: () => S.lg[1].best >= 1, ui: 'banner' },
    zoneGoal(3, 'Open the Swimming Pool'),
    { t: 'Sign a Rare talent', ok: () => S.stat.bestRar >= 1, at: 'office' },
    { t: 'Win a rival challenge', ok: () => (S.chalWins || 0) >= 1, hint: 'Rivals visit the lobby every few minutes' },
    zoneGoal(4, 'Open the Boxing gym'),
    { t: 'Reach National League in Track', ok: () => S.lg[0].best >= 2, ui: 'banner' },
    { t: 'Train a team athlete to 5 stars', ok: () => teamList().some((m) => starsOf(m) >= 5), hint: 'Team athletes earn XP every time they train' },
    { t: 'Sign an Epic talent', ok: () => S.stat.bestRar >= 2, at: 'office' },
    zoneGoal(6, 'Open the Basketball court'),
    { t: 'Promote a coach to Head Coach', ok: () => S.zones.some((z) => z.assistants >= 2), tile: 'as', hint: 'Walk onto the coach tile next to a rack' },
    zoneGoal(5, 'Open the Stadium'),
    { t: 'Reach the European Championship', ok: () => leagueIndex() >= 3, ui: 'banner' },
    { t: 'Sign a Legendary talent', ok: () => S.stat.bestRar >= 3, at: 'office' },
    { t: 'Reach the World Championship', ok: () => leagueIndex() >= 4, ui: 'banner' },
    { t: 'Reach the Diamond League', ok: () => leagueIndex() >= 5, ui: 'banner' },
  ];
  const goalAt = (i) => {
    if (i < GOALS.length) return GOALS[i];
    const n = i - GOALS.length + 1; // endless: Diamond trophies
    return { t: `Win ${n} Diamond troph${n > 1 ? 'ies' : 'y'}`, ok: () => (S.wallet.TROPHY_DIAMOND || 0) >= n, ui: 'banner' };
  };
  const goalReward = (i) => round10((25 + topFee() * 5) * (1 + Math.min(i, 40) * 0.1));
  const goalEl = $('goal');
  let goalShown = '', goalGuideT = 0, goalCool = 0;
  const _gp2 = new THREE.Vector3();
  const tileAt = (pre) => { for (const t of tiles.values()) if (t.id.startsWith(pre)) return t; return null; };
  function goalTarget() {
    const g = goalAt(S.goal);
    if (g.at === 'office' && S.office) return { p: _gp2.set(PAD.x, 0, PAD.z), h: `${ico('scout')} Scouting Office` };
    const t = tileAt(g.tile || (g.at === 'office' ? 'scout' : '\u0000'));
    if (t && !t.locked) return { p: _gp2.set(t.x, 0, t.z), h: `${ico('target')} ${g.t}` };
    return null;
  }
  function renderGoal() {
    const g = goalAt(S.goal), key = S.goal + g.t + topFee();
    if (key === goalShown) return;
    goalShown = key;
    goalEl.innerHTML = `<span class="gi">${ico('target')}</span><span class="gt">${g.t}</span><span class="gr">${ico('coin')}${fmt(goalReward(S.goal))}</span>`;
  }
  function checkGoals(dt) {
    if ((goalCool -= dt) > 0 || inTut()) return;
    const g = goalAt(S.goal);
    if (!g.ok()) { renderGoal(); return; }
    const amt = goalReward(S.goal);
    addCoins(amt); bumpCoins(); Snd.play('level');
    toast(`${ico('check')} Goal done: ${g.t} · +${fmt(amt)} ${ico('coin')}`, 2200);
    S.goal++; goalGuideT = 0; goalCool = 1.2;
    goalEl.classList.remove('flash'); void goalEl.offsetWidth; goalEl.classList.add('flash');
    renderGoal(); save();
  }
  goalEl.addEventListener('click', (e) => {
    e.stopPropagation(); Snd.unlock(); Snd.play('tap');
    if (AT.Tourney.active || AT.modalOpen()) return;
    const g = goalAt(S.goal), t = goalTarget();
    if (t) { goalGuideT = 14; return; }
    const tile = g.tile && tileAt(g.tile);
    if (tile && tile.locked) { toast(`${ico('lock')} Win ${tile.need} league title${tile.need > 1 ? 's' : ''} first · ${ico('trophy')} ${titleCount()}/${tile.need}`, 2400); return; }
    if (g.ui === 'banner') { pulseEl(banner); toast(g.hint || `${ico('trophy')} Play tournaments: tap the banner when one is ready`, 2400); return; }
    if (g.ui === 'up') { pulseEl($('upBtn')); toast(`${ico('up')} Open Upgrades`); return; }
    toast(g.hint || g.t, 2400);
  });

  // ======================================================================
  // TEST MODE (tap the coin counter 10 times quickly). Turn off with TEST_MODE = false.
  // ======================================================================
  let coinTaps = [];
  const testHTML = () => `<div class="mh"><span>${ico('gear')} Test mode</span><button class="x">${ico('close')}</button></div>
    <button class="setrow" data-t="coins">${ico('coin')}<span>+10,000 coins</span></button>
    <button class="setrow" data-t="scout">${ico('scout')}<span>Instant scout return</span></button>
    <button class="setrow" data-t="day">${ico('calendar')}<span>Skip day</span></button>
    <button class="setrow" data-t="tourney">${ico('trophy')}<span>Tournament ready now</span></button>
    <button class="setrow" data-t="chal">${ico('swords')}<span>Rival challenge now</span></button>
    <button class="setrow" data-t="away">${ico('hand')}<span>Simulate 1h away</span></button>
    <div class="sub">Turn off before publishing: TEST_MODE = false in game.js</div>`;
  function openTest() {
    showModal(testHTML(), (e, b) => {
      if (!b || !b.dataset.t) return;
      const k = b.dataset.t;
      if (k === 'coins') { addCoins(10000); bumpCoins(); toast('+10,000 coins'); }
      if (k === 'scout') { if (S.scout && !S.scout.cards) { S.scout.ends = Date.now(); scoutCheck(); } else toast(S.scout ? 'Talents are already waiting' : 'No scout on a trip'); }
      if (k === 'day') { S.dayShift = (S.dayShift || 0) + 1; hideModal(); dayCheck(); toast(`${ico('calendar')} Skipped to ${dayStr()}`); }
      if (k === 'tourney') { const sp = nextSport(); if (sp >= 0) S.lg[sp].next = 0.1; hideModal(); }
      if (k === 'chal') { chalT = 0.05; hideModal(); }
      if (k === 'away') { hideModal(); awayEarnings(3600 * 1000); }
      save();
    });
  }
  coinPill.addEventListener('pointerdown', (e) => {
    if (!TEST_MODE) return;
    e.stopPropagation();
    const now = performance.now();
    coinTaps = coinTaps.filter((t) => now - t < 4000); coinTaps.push(now);
    if (coinTaps.length >= 10 && !AT.modalOpen() && !AT.Tourney.active) { coinTaps = []; openTest(); }
  });

  $('teamBtn').addEventListener('click', guard(openTeam));
  $('dailyBtn').addEventListener('click', guard(openDaily));
  const dailyDot = $('dailyDot');

  // ======================================================================
  // ENERGY + RECOVERY ROOM / SPA
  // ======================================================================
  const PASSIVE_RATE = 4;                       // % per minute, everywhere, also offline
  const RECOV = [{ beds: 2, rate: 12 }, { beds: 3, rate: 15 }, { beds: 4, rate: 18 }, { beds: 5, rate: 21 }, { beds: 6, rate: 24 }];
  const RECOV_COST = [1500, 5000, 15000, 40000, 100000]; // build, then Lv 2..5
  const SPA = { tubs: 2, rate: 40, cost: 60000, need: 3 };
  const RPOS = { x: 4.85, z: 15.65 }, RPAD = { x: 2.7, z: 15.6 };
  const enOf = (m) => (m.en == null ? 100 : m.en);
  const enCol = (en) => (en >= 60 ? '#40c057' : en >= 20 ? '#fab005' : '#fa5252');
  AT.energyBar = (en) => `<span class="enb" title="Energy"><i style="width:${Math.round(en)}%;background:${enCol(en)}"></i><b>${Math.round(en)}%</b></span>`;
  const resting = new Map(); // member id -> 'spa' | 'bed' (runtime)
  // the most tired athletes who aren't in the academy get the spa tubs first, then the beds; everyone else recovers slowly
  function recoverEnergy(secs) {
    if (!S || secs <= 0) return;
    const tubs = S.spa ? SPA.tubs : 0, beds = S.recov ? RECOV[S.recov - 1].beds : 0, bedRate = S.recov ? RECOV[S.recov - 1].rate : 0;
    resting.clear();
    let k = 0;
    for (const m of teamList().filter((x) => enOf(x) < 100).sort((a, b) => enOf(a) - enOf(b))) {
      let r = PASSIVE_RATE;
      if (!rt(m).present && k < tubs + beds) { const spa = k < tubs; r = spa ? SPA.rate : bedRate; resting.set(m.id, spa ? 'spa' : 'bed'); k++; }
      m.en = Math.min(100, enOf(m) + (r * secs) / 60);
    }
  }
  let recovObj = null, recovKey = '';
  const zzTex = () => ctex('zz', 64, 64, (g) => { g.fillStyle = '#fff'; g.strokeStyle = '#1864ab'; g.lineWidth = 5; g.font = `900 34px ${FONT}`; g.textAlign = 'center'; g.strokeText('z', 22, 50); g.fillText('z', 22, 50); g.font = `900 24px ${FONT}`; g.strokeText('z', 46, 26); g.fillText('z', 46, 26); });
  function buildRecovery() {
    const key = S.recov + '-' + (S.spa ? 1 : 0);
    if (!S.recov || key === recovKey) return;
    recovKey = key;
    if (recovObj) world.remove(recovObj);
    else addCol(RPOS.x + 0.15, RPOS.z, 1.35, 0.62);
    const g = new THREE.Group(); g.position.set(RPOS.x, 0.12, RPOS.z);
    g.add(B(2.9, 0.12, 1.3, 0xe6fcf5, 0, 0.06, 0));
    g.add(B(2.9, 0.7, 0.1, 0x63e6be, 0, 0.4, -0.62), B(0.1, 0.7, 1.3, 0x63e6be, -1.42, 0.4, 0), B(0.1, 0.7, 1.3, 0x63e6be, 1.42, 0.4, 0));
    const sign = spr(labelTex(S.spa ? 'Recovery + Spa' : 'Recovery', '#20c997', 'bed'), 2.4, 0.6, 8); sign.position.set(0, 1.75, -0.4); g.add(sign);
    const n = RECOV[S.recov - 1].beds, slots = [];
    for (let i = 0; i < n; i++) {
      const x = -0.95 + (i % 3) * 0.72, z = i < 3 ? -0.3 : 0.32;
      const bed = new THREE.Group(); bed.position.set(x, 0.12, z);
      bed.add(B(0.55, 0.16, 0.56, 0xffffff, 0, 0.08, 0), B(0.5, 0.06, 0.5, 0x74c0fc, 0, 0.19, 0), B(0.36, 0.08, 0.14, 0xffffff, 0, 0.24, -0.17));
      const sleeper = new THREE.Group();
      sleeper.add(B(0.5, 0.1, 0.36, 0x20c997, 0, 0.27, 0.07));
      const head = mesh(sphG(0.12, 8, 6), M(SKINS[i % SKINS.length]), 0, 0.33, -0.17); sleeper.add(head);
      const zz = spr(zzTex(), 0.4, 0.4, 9); zz.position.set(0.15, 0.85, -0.1); sleeper.add(zz);
      sleeper.userData = { head, zz }; sleeper.visible = false; bed.add(sleeper);
      g.add(bed); slots.push({ kind: 'bed', sleeper });
    }
    if (S.spa) {
      const tub = new THREE.Group(); tub.position.set(1.0, 0.12, 0.05);
      tub.add(mesh(cylG(0.4, 0.42, 0.34, 14), M(0xf8f9fa), 0, 0.17, 0), mesh(cylG(0.34, 0.34, 0.04, 14), M(0x66d9e8, 'shiny'), 0, 0.33, 0));
      for (let i = 0; i < SPA.tubs; i++) {
        const sl = new THREE.Group(); const head = mesh(sphG(0.11, 8, 6), M(SKINS[(i + 2) % SKINS.length]), i ? 0.15 : -0.15, 0.42, 0); sl.add(head);
        sl.userData = { head }; sl.visible = false; tub.add(sl); slots.push({ kind: 'spa', sleeper: sl });
      }
      g.add(tub); g.userData.tub = tub;
    }
    const pad = mesh(GEO('pad', () => new THREE.CircleGeometry(0.8, 24)), new THREE.MeshBasicMaterial({ color: 0x20c997, transparent: true, opacity: 0.5, depthWrite: false }), RPAD.x - RPOS.x, 0.025, 0);
    pad.rotation.x = -Math.PI / 2; g.add(pad);
    g.userData.slots = slots;
    world.add(g); recovObj = g;
  }
  let rpadWas = true, steamT = 0;
  function updateRecovery(dt) {
    if (!recovObj) return;
    const on = d2(coach.obj.position, RPAD.x, RPAD.z) < 0.8;
    if (on && !rpadWas && !AT.modalOpen() && !AT.Tourney.active) { Snd.play('tap'); openRecovery(); }
    rpadWas = on;
    // show who is resting: sleepers in beds, heads in the spa tub
    const occ = { bed: [], spa: [] };
    for (const [id, k] of resting) { const m = S.roster.find((x) => x.id === id); if (m) occ[k].push(m); }
    const used = { bed: 0, spa: 0 };
    for (const sl of recovObj.userData.slots) {
      const m = occ[sl.kind][used[sl.kind]++];
      sl.sleeper.visible = !!m;
      if (m) { sl.sleeper.userData.head.material = M(SKINS[m.skin]); if (sl.sleeper.userData.zz) sl.sleeper.userData.zz.position.y = 0.85 + Math.sin(time * 2 + used.bed) * 0.08; }
    }
    if (recovObj.userData.tub && (steamT -= dt) <= 0) { steamT = 0.25; emit('glow', RPOS.x + 1.0 + rand(-0.3, 0.3), 0.7, RPOS.z + rand(-0.2, 0.3), 0.9, 0.35, 1.5); }
  }
  function recoveryHTML() {
    const lvl = S.recov, R = RECOV[lvl - 1];
    const list = teamList().sort((a, b) => enOf(a) - enOf(b));
    const rows = list.map((m) => {
      const en = enOf(m), where = resting.get(m.id), rate = where === 'spa' ? SPA.rate : where === 'bed' ? R.rate : PASSIVE_RATE;
      const mins = en >= 100 ? 0 : Math.ceil((100 - en) / rate);
      const status = en >= 100 ? 'Ready' : where === 'spa' ? `${ico('spa')} Spa` : where === 'bed' ? `${ico('bed')} In bed` : rt(m).present ? 'Training' : 'Resting';
      return `<div class="erow"><img src="${AT.thumbFor(m)}" alt=""><div class="en"><b>${displayName(m)} ${ico(ZONES[m.zone].icon)}</b>${AT.energyBar(en)}</div>
        <span class="es">${status}<small>${en >= 100 ? '' : `full in ~${mins} min`}</small></span></div>`;
    }).join('');
    const up = lvl < RECOV.length
      ? `<div class="up"><div class="upi">${ico('bed')}</div><div class="upt">Room Lv ${lvl + 1}<span class="ud">${RECOV[lvl].beds} beds · +${RECOV[lvl].rate}%/min</span></div>
         <button class="buy ${S.wallet.COINS >= RECOV_COST[lvl] ? '' : 'off'}" data-up="1">${ico('coin')} ${fmt(RECOV_COST[lvl])}</button></div>` : '';
    const spa = S.spa ? '' : `<div class="up"><div class="upi">${ico('spa')}</div><div class="upt">Spa<span class="ud">${SPA.tubs} hot tubs · +${SPA.rate}%/min, the fastest recovery${lvl < SPA.need ? ` · needs Room Lv ${SPA.need}` : ''}</span></div>
         <button class="buy ${lvl >= SPA.need && S.wallet.COINS >= SPA.cost ? '' : 'off'}" data-spa="1">${lvl < SPA.need ? ico('lock') : ico('coin') + ' ' + fmt(SPA.cost)}</button></div>`;
    return `<div class="mh"><span>${ico('bed')} Recovery · Lv ${lvl}</span><button class="x">${ico('close')}</button></div>
      <div class="rinfo"><span>${ico('bed')} ${R.beds} beds · +${R.rate}%/min</span>${S.spa ? `<span>${ico('spa')} ${SPA.tubs} tubs · +${SPA.rate}%/min</span>` : ''}<span>${ico('battery')} Elsewhere +${PASSIVE_RATE}%/min</span></div>
      <div class="sub">The most tired athletes rest first. Energy also recovers while the game is closed. Under 20% an athlete can't compete.</div>
      ${rows}${up}${spa}`;
  }
  const recovOpen = () => AT.modalOpen() && !!modalCard.querySelector('.rinfo');
  function openRecovery() {
    showModal(recoveryHTML(), (e, b) => {
      if (!b) return;
      if (b.dataset.up) {
        const c = RECOV_COST[S.recov];
        if (S.recov >= RECOV.length || S.wallet.COINS < c) { nudge(b); return; }
        spendCoins(c); S.recov++; Snd.play('level'); buildRecovery();
        toast(`${ico('bed')} Recovery Room Lv ${S.recov}: ${RECOV[S.recov - 1].beds} beds`); save(true);
      } else if (b.dataset.spa) {
        if (S.spa || S.recov < SPA.need || S.wallet.COINS < SPA.cost) { nudge(b); if (S.recov < SPA.need) toast(`${ico('lock')} Upgrade the room to Lv ${SPA.need} first`); return; }
        spendCoins(SPA.cost); S.spa = 1; Snd.play('chest'); buildRecovery();
        toast(`${ico('spa')} Spa open! The fastest recovery`); save(true);
      } else return;
      modalCard.innerHTML = recoveryHTML();
    });
  }

  // ======================================================================
  // TUTORIAL (new players, one step at a time) + FEATURES THAT UNLOCK GRADUALLY
  // ======================================================================
  const TUT_DONE = 99;
  const TUT = [
    { t: 'Drag to move', icon: 'hand' },
    { t: 'Grab water at the rack', icon: 'drop' },
    { t: 'Bring it to the runner', icon: 'arrow' },
    { t: 'Collect coins at the desk', icon: 'coin' },
    { t: 'Stand on the tile to buy', icon: 'plus' },
    { t: 'Tap the tournament', icon: 'trophy' },
  ];
  const inTut = () => S && S.tut < TUT_DONE;
  AT.tutEasy = () => S && S.tut === 5;
  const tutEl = $('tut'), hudEl = $('hud');
  let tutShown = -1, tutStart = null, tutFlags = { delivered: 0, collected: 0 };
  function tutRender() {
    if (tutShown === S.tut) return;
    tutShown = S.tut;
    hudEl.classList.toggle('tut', inTut());
    if (!inTut()) { tutEl.classList.add('hidden'); layoutTop(true); return; }
    const st = TUT[S.tut];
    const dots = TUT.map((_, i) => `<i class="${i < S.tut ? 'done' : i === S.tut ? 'on' : ''}"></i>`).join('');
    tutEl.innerHTML = `<span class="ti">${ico(st.icon)}</span><span class="tt">${st.t}</span><span class="tdots">${dots}</span><button class="skip" data-skip="1" aria-label="Skip tutorial">${ico('close')}</button>`;
    tutEl.classList.remove('hidden', 'mini', 'dodge'); tutEl.classList.remove('pop'); void tutEl.offsetWidth; tutEl.classList.add('pop');
    tutIdle = 0;
    layoutTop(true);
  }
  // the pill shrinks to a round icon after 4 s without progress (tap it to read it again), and steps aside when the
  // coach or the current target would be hidden behind it
  let tutIdle = 0, tutDodgeT = 0, tutLastT = 0;
  const _tq = new THREE.Vector3();
  function tutCovers(x, y, z) {
    _tq.set(x, y, z).project(camera);
    if (_tq.z > 1) return false;
    const r = tutEl.getBoundingClientRect(), g = gameEl.getBoundingClientRect();
    const sx = g.left + (_tq.x + 1) / 2 * g.width, sy = g.top + (1 - _tq.y) / 2 * g.height;
    return sx > r.left - 26 && sx < r.right + 26 && sy > r.top - 20 && sy < r.bottom + 24;
  }
  function tutTick() {
    const now = performance.now(), dt = Math.min(0.25, (now - (tutLastT || now)) / 1000); tutLastT = now;
    if (!inTut() || tutEl.classList.contains('hidden')) return;
    if (!tutEl.classList.contains('mini') && (tutIdle += dt) > 4) { tutEl.classList.add('mini'); layoutTop(true); }
    if ((tutDodgeT -= dt) > 0) return;
    tutDodgeT = 0.2;
    // check against the full pill's spot (centre) so dodging doesn't flip back and forth
    const was = tutEl.classList.contains('dodge');
    if (was) tutEl.classList.remove('dodge');
    const p = coach.obj.position, g = tutTarget();
    const cover = tutCovers(p.x, 1.2, p.z) || (g && tutCovers(g.p.x, 0.5, g.p.z));
    if (cover) tutEl.classList.add('dodge');
  }
  // TOP HUD STACK: goal bar / tutorial pill, tournament banner, hint and challenge popup sit under each other by their
  // real heights, so they never overlap
  const topEls = ['goal', 'tut', 'banner', 'hint', 'chal'].map((id) => $(id));
  const topBar = $('topbar');
  let topT = 0;
  function layoutTop(force) {
    const now = performance.now();
    if (!force && now - topT < 150) return;
    topT = now;
    let y = topBar.offsetTop + topBar.offsetHeight + 6;
    for (const el of topEls) {
      if (el.classList.contains('hidden') || getComputedStyle(el).display === 'none') continue;
      const t = Math.round(y) + 'px';
      if (el.style.top !== t) el.style.top = t;
      y += el.offsetHeight + (el.id === 'banner' ? 10 : 6); // the banner's drop shadow is 4 px
    }
  }
  AT.layoutTop = layoutTop;
  function tutNext() {
    S.tut++; Snd.play('level');
    if (S.tut === 1) tutStart = null;
    if (S.tut === 4) { // make sure the first tile is affordable
      const t = tiles.get('st0_1'), need = t ? Math.ceil(t.cost - t.paid) : 0;
      if (need > S.wallet.COINS) { addCoins(need - S.wallet.COINS); bumpCoins(); toast(`${ico('coin')} Starter bonus!`); }
    }
    if (S.tut === 5) S.lg[0].next = 0;
    if (S.tut >= TUT.length) tutFinish(true);
    else setTimeout(() => { const g = tutTarget(); if (g) panTo(g.p.x, g.p.z); }, 350); // show where to go next
    save();
  }
  function tutFinish(done) {
    S.tut = TUT_DONE;
    S.lg.forEach((l) => (l.next = Math.max(l.next, AT.TOURNEY_INTERVAL)));
    tutRender();
    if (done) { confetti(coach.obj.position.x, 1, coach.obj.position.z, 40); toast(`${ico('crown')} Tutorial complete! New features unlock as you grow`, 3000); }
    save(true);
  }
  tutEl.addEventListener('pointerdown', (e) => e.stopPropagation()); // taps on the pill don't start the joystick
  tutEl.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!e.target.closest('[data-skip]')) { // tap the small icon: show the full text again
      if (tutEl.classList.contains('mini')) { tutEl.classList.remove('mini'); tutIdle = 0; layoutTop(true); Snd.unlock(); Snd.play('tap'); }
      return;
    }
    Snd.unlock(); Snd.play('tap');
    showModal(`<div class="mh"><span>${ico('hand')} Skip the tutorial?</span></div><div class="sub">You can still follow the goal bar at the top.</div>
      <div class="ch-btns"><button class="no" data-c="no">Keep going</button><button class="yes" data-c="yes">Skip</button></div>`, (ev2, b) => {
      if (!b) return;
      hideModal();
      if (b.dataset.c === 'yes') tutFinish(false);
    });
  });
  // where the tutorial arrow points
  function tutTarget() {
    if (!inTut()) return null;
    const rack = racks.find((r) => r.zone === 0);
    switch (S.tut) {
      case 1: return rack ? { p: rack.pos, h: '' } : null;
      case 2: {
        const st = stations.find((s) => s.zone === 0 && s.athlete && (s.athlete.state === 'wait' || s.athlete.state === 'enter' || s.athlete.state === 'train'));
        if (coach.stack.length && st) return { p: st.pos, h: '' };
        return rack ? { p: rack.pos, h: '' } : null;
      }
      case 3: return { p: STAFF, h: '' };
      case 4: { const t = tiles.get('st0_1'); return t ? { p: _gp.set(t.x, 0, t.z), h: '' } : null; }
    }
    return null;
  }
  function updateTutorial() {
    tutRender();
    layoutTop();
    tutTick();
    if (!inTut()) return;
    const p = coach.obj.position;
    if (S.tut === 0) { if (!tutStart) tutStart = p.clone(); else if (d2(p, tutStart.x, tutStart.z) > 1.6) tutNext(); }
    else if (S.tut === 1 && coach.stack.length) tutNext();
    else if (S.tut === 2 && tutFlags.trained) tutNext();
    else if (S.tut === 3 && tutFlags.collected) tutNext();
    else if (S.tut === 4 && S.zones[0].stations >= 2) tutNext();
    else if (S.tut === 5) { if (!banner.classList.contains('nudge')) banner.classList.add('nudge'); if (S.played >= 1) { banner.classList.remove('nudge'); tutNext(); } }
  }

  const FEATS = [
    { id: 'helpers', icon: 'cap', name: 'Helpers', txt: 'Hire an assistant to carry items for you, and a receptionist to collect fees.', ok: () => S.zones[0].stations >= 2 },
    { id: 'sport2', icon: 'dumbbell', name: 'A second sport', txt: 'Build the Gym to train a new kind of athlete.', ok: () => S.zones[0].stations >= 3 || S.zones[0].assistants >= 1 },
    { id: 'rivals', icon: 'swords', name: 'Rival challenges', txt: 'Rival athletes now visit the lobby. Beat them 1-on-1 for coins.', ok: () => S.zones[1].unlocked },
    { id: 'scouting', icon: 'scout', name: 'Scouting Office', txt: 'Build it in the lobby and sign named talent for your team.', ok: () => S.zones[1].stations >= 2 || (S.chalWins || 0) >= 1 },
    { id: 'leagues', icon: 'trophy', name: 'Leagues', txt: 'Every sport now has its own league. Win tournaments to climb from Local all the way to the Diamond League.', ok: () => S.office > 0 },
    { id: 'recovery', icon: 'bed', name: 'Recovery Room', txt: 'Matches cost energy. Build the Recovery Room so tired athletes bounce back much faster.', ok: () => S.played >= 3 || teamList().some((m) => enOf(m) < 50) },
  ];
  const feat = (id) => !!(S && S.feat && S.feat[id]);
  AT.feat = feat;
  function checkFeatures() {
    if (inTut()) return;
    const f = FEATS.find((x) => !feat(x.id));
    if (!f || !f.ok()) return;
    S.feat[f.id] = 1;
    if (f.id === 'leagues') S.lg.forEach((l) => (l.next = Math.min(l.next, 60)));
    refreshTiles(); save(true);
    popup('feat-' + f.id, () => {
      Snd.play('tier');
      showModal(`<div class="newf"><div class="nb">New feature!</div><div class="ni">${ico(f.icon)}</div><b>${f.name}</b><p>${f.txt}</p></div>
        <button class="go" data-go="1">Got it!</button>`, (e, b) => { if (b && b.dataset.go) hideModal(); });
    });
  }

  let enT = 0;
  function updateMeta(dt) {
    updateTutorial();
    updateRecovery(dt);
    if ((enT += dt) >= 1) { recoverEnergy(enT); enT = 0; if (recovOpen()) { const y = modalCard.scrollTop; modalCard.innerHTML = recoveryHTML(); modalCard.scrollTop = y; } }
    checkFeatures();
    updateOffice(dt);
    checkGoals(dt);
    if (goalGuideT > 0) { goalGuideT -= dt; const t = goalTarget(); if (!t || d2(coach.obj.position, t.p.x, t.p.z) < 1.1) goalGuideT = 0; }
    if ((dayT -= dt) <= 0) { dayT = 1; scoutCheck(); dayCheck(); dailyDot.classList.toggle('hidden', !dailyReady()); }
    pumpPopups();
  }

  // ======================================================================
  // SAVE / LOAD
  // ======================================================================
  const KEY = 'athlete-tycoon-v1';
  let lastYTSave = 0;
  function save(force) {
    if (!S) return;
    S.saved = Date.now(); delete S.fresh;
    let data;
    try { data = JSON.stringify(S); } catch (e) { return; }
    try { localStorage.setItem(KEY, data); } catch (e) { /* storage blocked */ }
    if (inYT && (force || Date.now() - lastYTSave > 5000)) {
      lastYTSave = Date.now();
      try { YT.game.saveData(data).catch(() => {}); } catch (e) { /* ignore */ }
    }
  }
  AT.save = save;
  function parseSave(raw) {
    try { const o = JSON.parse(raw); return o && o.v === 1 && o.wallet ? o : null; } catch (e) { return null; }
  }
  async function load() {
    // (a missing save returns newState() with fresh = true)
    let cloud = null, local = null;
    if (inYT) { try { cloud = parseSave(await YT.game.loadData()); } catch (e) { /* ignore */ } }
    try { local = parseSave(localStorage.getItem(KEY)); } catch (e) { /* ignore */ }
    // keep whichever copy is newest
    const o = cloud && local ? ((cloud.saved || 0) >= (local.saved || 0) ? cloud : local) : cloud || local;
    if (!o) return Object.assign(newState(), { fresh: true });
    const s = Object.assign(newState(), o);
    s.zones = ZONES.map((z, i) => Object.assign({ unlocked: i === 0, stations: i === 0 ? 1 : 0, assistants: 0 }, (o.zones || [])[i]));
    s.wallet = Object.assign({ COINS: 0 }, o.wallet);
    if (!isFinite(s.wallet.COINS) || s.wallet.COINS < 0) s.wallet.COINS = 0;
    s.skins = s.skins || {}; s.legends = s.legends || {}; s.paid = s.paid || {};
    s.roster = (s.roster || []).filter((m) => m && ZONES[m.zone]);
    for (const m of s.roster) for (let t = 1; t <= starsOf(m); t++) s.skins[`${m.zone}-${t}`] = 1; // migrate older saves
    if (Array.isArray(o.lg)) s.lg = SPORTS.map((_, i) => Object.assign(newLeague(0), o.lg[i]));
    else {
      // older saves had one global league (Bronze/Silver/Gold/Champion): start each open sport at that level
      const p = (o.league && o.league.player) || 0, L = p >= 36 ? 3 : p >= 20 ? 2 : p >= 8 ? 1 : 0;
      s.lg = SPORTS.map((sp) => {
        const lv = sp.zones.some((z) => s.zones[z].unlocked) ? L : 0, l = newLeague(lv);
        l.won = Array.from({ length: lv }, (_, k) => k); l.next = clamp(o.tourneyT == null ? 60 : o.tourneyT, 0, 150);
        return l;
      });
      s.wallet.DECOR = s.lg.reduce((a, l) => a + l.won.length, 0) || undefined;
      if (!s.wallet.DECOR) delete s.wallet.DECOR;
    }
    for (const l of s.lg) { l.rp = (l.rp || [0, 0, 0]).slice(0, 3); l.lvl = clamp(l.lvl | 0, 0, LEAGUES.length - 1); }
    // trophy hall log: older saves only had counts, so fill in any missing trophies as Local-league ones
    s.trophyLog = Array.isArray(o.trophyLog) ? o.trophyLog.filter((e) => e && e.t >= 0 && e.t <= 2) : [];
    [['TROPHY_GOLD', 0], ['TROPHY_SILVER', 1], ['TROPHY_BRONZE', 2]].forEach(([k, t]) => {
      const have = s.trophyLog.filter((e) => e.t === t).length;
      for (let i = have; i < (s.wallet[k] || 0); i++) s.trophyLog.push({ t, l: 0 });
    });
    delete s.league; delete s.tourneyT;
    s.stat = Object.assign({ trips: 0, signed: 0, bestRar: 0 }, o.stat);
    s.login = Object.assign({ day: '', streak: 0 }, o.login);
    s.office = clamp(s.office | 0, 0, OFFICE_MAX);
    for (const m of s.roster) if (m.team) { m.rar = clamp(m.rar | 0, 0, 3); if (!Array.isArray(m.st)) m.st = [20, 20, 20]; m.en = isFinite(m.en) ? clamp(m.en, 0, 100) : 100; }
    s.recov = clamp(s.recov | 0, 0, 5); s.spa = s.spa ? 1 : 0;
    if (s.scout && (!TRIPS[s.scout.trip] || !isFinite(s.scout.ends))) s.scout = null;
    return s;
  }
  // ======================================================================
  // MAIN LOOP
  // ======================================================================
  let time = 0, last = performance.now(), paused = false, firstFrame = false, saveT = 0;
  let perfT = 0, perfN = 0;
  function update(dt) {
    time += dt;
    updateCoach(dt);
    carrierInteract(coach, dt, true);
    updateBins(dt);
    updateFull();
    for (const a of assistants) updateAssistant(a, dt);
    updateAthletes(dt);
    updateDesk(dt);
    updateTiles(dt);
    updateSpawner(dt);
    updateFX(dt);
    updateEntrances(dt);
    updateGuide();
    // camera: soft follow, a little ahead in the walking direction, never past the academy's edges
    const p = coach.obj.position, lk = 1 - Math.exp(-dt * 2.5);
    camLead.x += (clamp(coachVel.x * 0.3, -1.3, 1.3) - camLead.x) * lk;
    camLead.y += (clamp(coachVel.y * 0.3, -1.6, 1.6) - camLead.y) * lk;
    let tx = p.x + camLead.x, tz = p.z - 1.2 + camLead.y, k = 1 - Math.exp(-dt * 4);
    if (camPan) {
      camPan.t += dt;
      if (camPan.t < 2.2 && !AT.modalOpen()) { tx = camPan.x; tz = camPan.z; k = 1 - Math.exp(-dt * 3); } else camPan = null;
    }
    const slide = Math.max(0, 6.65 - camExt.half);
    tx = clamp(tx, -slide, slide);
    const zLo = bounds.minZ - 2.4 + camExt.ahead, zHi = 17.15 + 3.4 - camExt.behind;
    tz = zLo <= zHi ? clamp(tz, zLo, zHi) : (zLo + zHi) / 2;
    camLook.x += (tx - camLook.x) * k;
    camLook.z += (tz - camLook.z) * k;
    camera.position.copy(camLook).addScaledVector(CAM_DIR, camDist);
    camera.lookAt(camLook);
    // the shadow box follows the camera in steps (whole shadow-map texels, so edges don't shimmer); between steps it
    // stays put, which lets the static shadows be drawn once and reused
    const lx = camLook.dot(SUN_X), ly = camLook.dot(SUN_Y), lz = camLook.dot(SUN_Z);
    if (!shadowC.set || Math.abs(lx - shadowC.x) > SHADOW_SLACK || Math.abs(ly - shadowC.y) > SHADOW_SLACK) {
      shadowC.x = Math.round(lx / shadowTexel) * shadowTexel; shadowC.y = Math.round(ly / shadowTexel) * shadowTexel; shadowC.z = lz; shadowC.set = true;
      sun.target.position.set(0, 0, 0).addScaledVector(SUN_X, shadowC.x).addScaledVector(SUN_Y, shadowC.y).addScaledVector(SUN_Z, shadowC.z);
      sun.position.copy(sun.target.position).add(SUN_OFF);
      if (BATCH) AT.Batch.staticDirty = true;
    }
    markShadows(dt);
    // each sport's next league tournament counts down while you play
    if (!AT.modalOpen()) S.lg.forEach((l, i) => {
      if (l.next <= 0 || !sportHasAthletes(i) || !feat('leagues')) return;
      l.next -= dt;
      if (l.next <= 0) { l.next = 0; toast(`${ico(SPORTS[i].icon)} ${SPORTS[i].name} tournament ready! Tap the banner`, 2400); Snd.play('whistle'); }
    });
    updateChallenge(dt);
    updateMeta(dt);
    updateHUD(dt);
    saveT += dt;
    if (saveT > 3) { saveT = 0; save(); }
  }
  // ADAPTIVE QUALITY — only steps down when the frame rate stays below 40 FPS for 5 s in a row (one slow moment is
  // ignored), and not during the first 6 s after loading, a tournament or a zone unlock (shader compiles).
  // Savings in this order: 1 fewer particles, 2 smaller tournament crowd, 3 smaller shadow map (1536),
  // 4 blob shadows, 5 fewer walk-in athletes, and only then the 3D resolution (never below 2x on 2x+ screens).
  // HUD, menus and the minigame canvas always stay at full sharpness.
  let quality = 3, partMax = 90, walkCap = MAX_ATHLETES, degrade = 0, slowT = 0, goodT = 0, perfHold = 6;
  const triedUp = {};
  AT.perfHold = (sec = 6) => { perfHold = Math.max(perfHold, sec); slowT = 0; perfT = 0; perfN = 0; };
  function setQuality(q) { // shadows: 3 = 2048 soft shadows, 2 = 1536, 1 and 0 = blob shadows
    quality = q;
    const sh = q >= 2;
    if (renderer.shadowMap.enabled !== sh) {
      renderer.shadowMap.enabled = sh;
      scene.traverse((o) => { if (o.material) [].concat(o.material).forEach((m) => (m.needsUpdate = true)); });
    }
    SK.shadowMat.visible = !sh; // cheap blob shadows replace the real ones
    const size = q >= 3 ? 2048 : 1536;
    if (sun.shadow.mapSize.x !== size) { sun.shadow.mapSize.set(size, size); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
    fitShadow();
    shadowC.set = false;
    if (BATCH) AT.Batch.staticDirty = true;
  }
  function setDegrade(d) {
    degrade = d;
    partMax = d >= 1 ? 36 : 90;
    AT.crowdLow = d >= 2;
    const q = d >= 4 ? 1 : d >= 3 ? 2 : 3;
    if (q !== quality) setQuality(q);
    walkCap = d >= 5 ? 9 : MAX_ATHLETES;
  }
  function stepDown() {
    if (degrade < 5) setDegrade(degrade + 1);
    else if (pixelRatio > pxFloor() + 0.01) { pixelCap = Math.max(pxFloor(), pixelRatio - 0.25); resize(); }
  }
  function stepUp() { // running smoothly for a while: try one step back up (once per step, to avoid flip-flopping)
    if (pixelCap < dpr() - 0.01) { if (!triedUp['px' + pixelCap]) { triedUp['px' + pixelCap] = 1; pixelCap = Math.min(dpr(), pixelCap + 0.25); resize(); } }
    else if (degrade > 0 && !triedUp['d' + degrade]) { triedUp['d' + degrade] = 1; setDegrade(degrade - 1); }
  }
  function perf(dt) {
    if (perfHold > 0) { perfHold -= dt; return; }
    perfT += dt; perfN++;
    if (perfT < 1) return;
    const fps = perfN / perfT, win = perfT; perfT = 0; perfN = 0;
    if (fps < 40) {
      goodT = 0;
      if ((slowT += win) >= 5) { slowT = 0; stepDown(); }
    } else {
      slowT = 0;
      if (fps > 57) { if ((goodT += win) >= 24) { goodT = 0; stepUp(); } } else goodT = 0;
    }
  }
  // real shadows: every solid mesh casts and lit ones receive (new objects are picked up as they appear)
  let shadowScanT = 0;
  function markShadows(dt) {
    if ((shadowScanT -= dt) > 0 || quality < 2) return;
    shadowScanT = 0.5;
    // only characters (their merged batches) and big objects cast shadows; floors, small props, decoration and labels
    // only receive them
    world.traverse((o) => {
      if (!o.isMesh || o.userData.shd || o.userData.__b) return;
      o.userData.shd = 1;
      const m = o.material;
      if (Array.isArray(m) || m.transparent || m === SK.shadowMat) return;
      o.receiveShadow = !m.isMeshBasicMaterial;
      o.castShadow = AT.Batch ? AT.Batch.isBig(o) : true;
      if (o.castShadow && BATCH) o.layers.enable(2);
    });
  }
  function loop(now) {
    requestAnimationFrame(loop);
    const raw = (now - last) / 1000;
    const dt = Math.min(0.05, Math.max(0, raw)); // never step backwards in time
    last = now;
    if (paused) return;
    try {
      if (BATCH) renderer.info.reset();
      if (AT.Tourney.active) {
        AT.Tourney.update(dt);
        if (!AT.Tourney.playing()) { if (BATCH) AT.Batch.frame(dt, camera); renderer.render(scene, camera); } // results screen sits over the academy
      } else {
        update(dt);
        if (BATCH) AT.Batch.frame(dt, camera);
        renderer.render(scene, camera);
        if (raw < 0.5) perf(raw);
      }
      if (BATCH) AT.Batch.stat(raw);
    } catch (err) {
      console.error(err); // never let one bad frame freeze the game
    }
    if (!firstFrame) {
      firstFrame = true;
      const ld = $('loading'); ld.style.opacity = 0; setTimeout(() => ld.remove(), 450);
      if (inYT) { try { YT.game.firstFrameReady(); YT.game.gameReady(); } catch (e) { /* ignore */ } }
    }
  }

  // pause when the tab is hidden, the window loses focus or YouTube says so; everything time-based stops with the
  // loop (music, tournament countdowns, rivals). Scouting trips run on the real clock by design.
  const pauseWhy = { hidden: false, blur: false, yt: false };
  let pausedAt = 0;
  function setPause(why, on) {
    pauseWhy[why] = on;
    const p = pauseWhy.hidden || pauseWhy.blur || pauseWhy.yt;
    if (p === paused) return;
    paused = p; last = performance.now();
    Snd.setPaused(p);
    if (p) { resetInput(); pausedAt = Date.now(); save(true); return; }
    if (!S) return;
    if (pausedAt) recoverEnergy((Date.now() - pausedAt) / 1000);
    if (pausedAt && Date.now() - pausedAt > 60000) awayEarnings(Date.now() - pausedAt); // long break: welcome-back coins
    pausedAt = 0;
    dayCheck(); scoutCheck();
  }
  const setPaused = (p) => setPause('yt', p);
  document.addEventListener('visibilitychange', () => setPause('hidden', document.hidden));
  window.addEventListener('blur', () => setPause('blur', true));
  window.addEventListener('focus', () => setPause('blur', false));
  window.addEventListener('pagehide', () => save(true));
  window.addEventListener('beforeunload', () => save(true));

  AT.afterTourney = () => { AT.perfHold(6); Snd.music('academy'); refreshTrophyHall(); syncWorld(); refreshTiles(); AT.refreshHUD(); save(true); last = performance.now(); resetInput(); };
  AT.sendScore = (v) => { if (inYT) { try { YT.engagement.sendScore({ value: Math.floor(v) }); } catch (e) { /* ignore */ } } };
  // leaderboard score: league progress summed over every sport, plus Diamond titles
  AT.leagueScore = () => S.lg.reduce((a, l) => a + l.best * 25 + l.won.length * 10 + l.pts, 0) + (S.wallet.TROPHY_DIAMOND || 0) * 50;

  AT.boot = async function () {
    resize();
    buildStatic();
    S = await load();
    const fresh = !S.saved || S.fresh;
    // tutorial + gradual features: new players start the tutorial; older saves already have everything
    if (S.tut == null) { S.tut = fresh ? 0 : TUT_DONE; S.feat = fresh ? {} : Object.fromEntries(FEATS.map((f) => [f.id, 1])); }
    S.feat = S.feat || {};
    if (!fresh && !S.goalV) { if (S.goalOK && S.goal >= 10) S.goal++; } // a goal was added at #11
    if (!fresh && (S.goalV || 0) < 3 && S.goalOK && S.goal >= 22) S.goal += 2; // two goals were added at #23
    S.goalV = 3;
    refreshStats();
    makeCoach();
    syncWorld();
    refreshTiles();
    refreshTrophyHall();
    ensureTeam();
    // saves from before the goal bar: skip goals that are already done (no reward flood)
    if (!S.goalOK) { S.goalOK = 1; while (S.goal < 500 && goalAt(S.goal).ok()) S.goal++; }
    applyAudio();
    recoverEnergy(Math.max(0, (Date.now() - (S.saved || Date.now())) / 1000)); // energy recovers offline too
    if (S.offlinePend > 0) popup('away', openAway);           // unclaimed coins from last time
    else awayEarnings(Date.now() - (S.saved || Date.now()));
    if (fresh) loginShown = dayStr(); // brand-new players start playing first; the calendar waits behind the Daily button
    dayCheck(); scoutCheck(); renderGoal();
    IC.mount();
    if (inYT) {
      try {
        Snd.ytOn = YT.system.isAudioEnabled();
        YT.system.onAudioEnabledChange((on) => { Snd.ytOn = on; Snd.apply(); });
        YT.system.onPause(() => setPaused(true));
        YT.system.onResume(() => setPaused(false));
      } catch (e) { /* ignore */ }
    }
    if (S.zoomV !== ZOOM_VER) { delete S.zoom; S.zoomV = ZOOM_VER; } // older saves: back to the new default once
    if (S.zoom) setZoom(S.zoom);
    camLook.set(0, 0, coach.obj.position.z - 1.2);
    AT.refreshHUD();
    if (!S.look) setTimeout(() => { if (!AT.modalOpen() && !AT.Tourney.active) openCoachCreator(true); }, 700);
    requestAnimationFrame(loop);
  };
  // debug helpers for testing from the browser console
  AT._debug = { camDist: (d) => (camDist = d), cam: () => ({ look: camLook, dist: camDist, zoom: camZoom, ext: camExt, pan: camPan, setZoom, panTo, camera }), assign: (a) => openAssign(a), quality: (q) => (q == null ? { quality, degrade, pixelRatio, pixelCap, partMax, walkCap, perfHold } : setDegrade(q)), bins, assistants, fill: (item, n) => { for (let i = 0; i < n; i++) pushStack(coach, item || 'water'); }, frame: (now) => loop(now), give: (n) => addCoins(n), state: () => S, tourneyNow: (sp = 0) => (S.lg[sp].next = 0.1), unpause: () => { for (const k in pauseWhy) pauseWhy[k] = false; paused = false; }, openOffice: () => openOffice(), openRecovery: () => openRecovery(), recover: (s) => recoverEnergy(s), tut: () => S.tut, openDaily: () => openDaily(), openTeam: () => openTeam(), openTest: () => openTest(), scoutNow: () => { if (S.scout) { S.scout.ends = Date.now(); scoutCheck(); } }, away: (h) => awayEarnings(h * 3600e3), goals: () => GOALS, chal: () => chal, chalNow: () => (chalT = 0.05), coach: () => coach, input, stations, queue, line, athletes, tiles, colliders };
})();
