/* Athlete Tycoon — tournament mode: athlete picker, one skill minigame per sport,
   race/match scene against the 3 rival academies, podium, league table. */
'use strict';
(function () {
  const AT = window.AT;
  const { $, rand, clamp, pick, fmt, rr, FONT, ZONES, LEAGUES, SPORTS, PLACE_PTS, PLAYER, RIVALS, NAMES } = AT;
  const IC = AT.Icon, ico = (n, c) => IC.svg(n, c);
  const T = (AT.Tourney = { active: false });
  const cv = $('scene2d');
  const g = cv.getContext('2d');
  let W = 360, H = 640;

  const EVENTS = {
    sprint: { name: '100m Sprint', kind: 'race', game: 'sprint', top: '#69db7c', lane: '#f4845f' },
    relay: { name: 'Stadium Relay', kind: 'race', game: 'sprint', top: '#40c057', lane: '#e8590c' },
    swim: { name: '50m Swim', kind: 'race', game: 'swim', top: '#1971c2', lane: '#4dabf7', swim: true },
    lift: { name: 'Power Lift', kind: 'lift', game: 'lift' },
    boxing: { name: 'Punch-Off', kind: 'box', game: 'boxing' },
    penalty: { name: 'Penalty Shootout', kind: 'pen', game: 'penalty' },
    hoops: { name: 'Hoops Shootout', kind: 'hoop', game: 'hoops' },
  };
  const INTRO = {
    sprint: ['shoe', 'Tap when the marker is in the green!'],
    penalty: ['football', 'Tap when the arrow points at a corner!'],
    swim: ['wave', 'Tap left, right, left… keep a steady rhythm!'],
    boxing: ['glove', 'Tap the glowing targets. Swipe down on red!'],
    lift: ['dumbbell', 'Hold to power up. Release in the green!'],
    hoops: ['basketball', 'Swipe up to shoot! Longer swipe = longer shot'],
  };
  const ACAD = [PLAYER, ...RIVALS];
  const PLACE = ['1st', '2nd', '3rd', '4th'];
  const MEDALS = ['medalGold', 'medalSilver', 'medalBronze'];
  const EVENT_PTS = [4, 3, 2, 1];
  const SKIN = ['#ffd6b0', '#f1c27d', '#e0ac69', '#c68642', '#8d5524'];
  // which stats help in each minigame (index: 0 Speed, 1 Power, 2 Stamina) and what they do
  const STAT_NAMES = [['Speed', 'speed'], ['Power', 'bolt'], ['Stamina', 'heart']];
  const STAT_HELP = {
    sprint: { 0: 'Wider PERFECT zone', 2: 'Slower marker on tap 3' },
    penalty: { 1: 'Faster, harder shots', 0: 'Slower aiming arrow' },
    swim: { 2: 'Easier rhythm', 0: 'Higher top speed' },
    boxing: { 0: 'More time to hit', 1: 'More damage', 2: 'Take more hits' },
    lift: { 1: 'Slower, steadier bar', 2: 'Wider green zone' },
    hoops: { 1: 'Longer shot range', 0: 'Slower moving hoop', 2: 'Steady aim on the last shots' },
  };
  const ENERGY_COST = { tourney: 35, duel: 30 };
  const enOf = (m) => (m.en == null ? 100 : m.en);
  // low energy shrinks zones and slows things down (full effect from 60% up, weakest at 20%)
  const energyFactor = (en) => clamp(0.65 + (0.35 * (en - 20)) / 40, 0.65, 1);
  T.ENERGY_COST = ENERGY_COST;

  T.resize = function () {
    const r = cv.getBoundingClientRect();
    if (!r.width) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 3); // the 2D minigame canvas always renders at full sharpness
    W = r.width; H = r.height;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  const logo = (a, size) => `<span class="logo" style="background:${a.color};${size ? `width:${size}px;height:${size}px` : ''}">${ico(a.logo)}</span>`;

  // ======================================================================
  // PICKER
  // ======================================================================
  let picks = [];
  // only team athletes (signed at the Scouting Office) can compete
  const sportRoster = (S, sp) => S.roster.filter((m) => m.team && S.zones[m.zone].unlocked && SPORTS[sp].zones.includes(m.zone))
    .sort((a, b) => AT.athPower(b) - AT.athPower(a));
  // cfg: { sport, max, head (html), go (label), onGo(members) }
  function picker(cfg) {
    const S = AT.S();
    const list = sportRoster(S, cfg.sport);
    const ok = (m) => enOf(m) >= 20; // too tired below 20% energy
    picks = list.filter(ok).slice(0, cfg.max).map((m) => m.id); // best rested athletes pre-selected for one-tap play
    const render = () => {
      const cards = !list.length ? `<div class="next lk">${ico('scout')} No ${SPORTS[cfg.sport].name} athletes on your team yet</div>` : list.map((m) => {
        const st = AT.starsOf(m);
        const R = AT.RARITY[m.rar || 0], en = enOf(m);
        return `<button class="ath t${st} r${m.rar || 0} ${picks.includes(m.id) ? 'sel' : ''} ${ok(m) ? '' : 'tired'}" data-id="${m.id}" style="--rc:${R.col}">
          ${AT.energyBar(en)}
          <img class="ap" src="${AT.thumbFor(m)}" alt=""><span class="az">${ico(ZONES[m.zone].icon)}</span>
          <span class="an">${AT.displayName(m)}</span>
          <span class="as">${IC.stars(st)}</span><span class="ae">${R.name} · ${ico('bolt')}${Math.round(AT.athPower(m))}</span>
          <span class="ast">${m.st.map((v, k) => `${['S', 'P', 'St'][k]}${Math.round(v)}`).join(' ')}</span></button>`;
      }).join('');
      AT.showModal(`${cfg.head}
        <div class="sub">${cfg.max > 1 ? `Pick up to ${cfg.max} ${SPORTS[cfg.sport].name} athletes · ${picks.length}/${cfg.max}` : `Pick your ${SPORTS[cfg.sport].name} athlete`} · costs ${ico('battery')} ${cfg.cost}% energy</div>
        <div class="grid">${cards}</div>
        <button class="go ${picks.length ? '' : 'off'}" data-go="1">${cfg.go} ${ico('play')}</button>`, (e, b) => {
        if (!b) return;
        if (b.dataset.id) {
          const id = +b.dataset.id;
          if (!ok(list.find((m) => m.id === id))) { AT.toast(`${ico('battery')} Too tired (under 20% energy). Let them rest!`); return; }
          if (picks.includes(id)) picks = picks.filter((x) => x !== id);
          else if (picks.length < cfg.max) picks.push(id);
          else { picks.shift(); picks.push(id); }
          render();
        } else if (b.dataset.go && picks.length) {
          const members = picks.map((id) => S.roster.find((m) => m.id === id)).filter(Boolean);
          AT.hideModal();
          if (members.length) cfg.onGo(members);
        }
      });
    };
    render();
  }
  // league tournament for one sport: up to 3 of that sport's athletes, one event each, vs the 3 rival academies
  T.openPicker = function (sp) {
    const S = AT.S(), l = S.lg[sp], L = LEAGUES[l.lvl];
    picker({
      sport: sp, max: 3, go: 'GO!', cost: ENERGY_COST.tourney,
      head: `<div class="mh"><span>${ico(L.icon)} ${L.short} · ${ico(SPORTS[sp].icon)} ${SPORTS[sp].name}</span><button class="x">${ico('close')}</button></div>
        <div class="rivals">${RIVALS.map((r) => `<span class="chip">${logo(r)}${r.name} ${IC.stars(Math.round(rivalStars(r, l.lvl, l.played)), 5, 'xs')}</span>`).join('')}</div>
        <div class="sub">Tournament ${l.played + 1}/${L.events} · ${l.pts}/${L.target} pts</div>`,
      onGo: (members) => start(members, { sport: sp, lvl: l.lvl }),
    });
  };
  // 1-on-1 rival challenge
  T.openDuel = function (c, onDone) {
    picker({
      sport: c.sport, max: 1, go: 'Fight!', cost: ENERGY_COST.duel,
      head: `<div class="mh"><span>${ico('swords')} Challenge</span><button class="x">${ico('close')}</button></div>
        <div class="rivals"><span class="chip">${logo(c.academy)}${c.name} · ${c.academy.name} ${IC.stars(c.stars, 5, 'xs')}</span></div>
        <div class="sub">Win ${ico('coin')} +${fmt(c.prize)} · Lose ${c.risk ? ico('coin') + ' −' + fmt(c.risk) : 'nothing'}</div>`,
      onGo: (members) => start(members.slice(0, 1), { sport: c.sport, lvl: c.lvl, duel: c, onDone }),
    });
  };

  // ======================================================================
  // RUN
  // ======================================================================
  let run = null, ev = null, pendingCollect = null;
  const TN = AT.Toon, FX = TN.FX, PZ = TN.P;
  const SPORT_OF = { sprint: 'track', penalty: 'football', swim: 'swim', boxing: 'boxing', lift: 'gym', hoops: 'hoops' };
  T._start = (m) => start(m);
  function start(members, cfg = {}) {
    if (T.active || !members || !members.length) return;
    const sport = cfg.sport != null ? cfg.sport : AT.sportOfZone(members[0].zone);
    const lg = AT.S().lg[sport];
    run = { members, idx: 0, totals: [0, 0, 0, 0], pow: [0, 0, 0, 0], log: [], sport, lvl: cfg.lvl != null ? cfg.lvl : lg.lvl, played: lg.played, duel: cfg.duel || null, onDone: cfg.onDone, easy: !cfg.duel && AT.tutEasy && AT.tutEasy() };
    T.active = true;
    Q.hold = 1.5; Q.t = Q.n = Q.slow = 0; setQ(Q.lvl); // short warm-up; picks up the academy's crowd setting
    AT.resetInput();
    AT.Audio.music('tourney');
    cv.classList.remove('hidden');
    T.resize();
    AT.sfx('whistle');
    startEvent();
  }
  T.playing = () => !!ev;
  T.phase = () => (ev ? ev.phase : null);
  T._ev = () => ev; // debug/testing
  // safety net: whatever happens, get the player back to the academy
  T.abort = function () {
    const r = run;
    ev = null; run = null; T.active = false; pendingCollect = null;
    cv.classList.add('hidden');
    if (AT.modalOpen()) AT.hideModal();
    if (r && !r.duel) { const l = AT.S().lg[r.sport]; if (l.next <= 0) l.next = 20; }
    AT.afterTourney();
    if (r && r.onDone) r.onDone(null);
  };
  // rivals get stronger in higher leagues (and a little through the season)
  function rivalStars(r, lvl, played) {
    if (run && run.easy) return 1; // tutorial mini tournament
    return clamp(1.0 + lvl * 0.85 + r.skill + Math.min(0.5, played * 0.12), 1, 6);
  }
  function startEvent() {
    const m = run.members[run.idx];
    const type = ZONES[m.zone].event;
    const E = EVENTS[type];
    // the athlete's stats (0-1) and energy shape this minigame; then the match costs energy
    const st = m.st || [20, 20, 20], en = enOf(m);
    const mod = { s: st[0] / 100, p: st[1] / 100, a: st[2] / 100, ef: energyFactor(en), en };
    if (run.easy) { mod.s = Math.max(mod.s, 0.7); mod.p = Math.max(mod.p, 0.7); mod.a = Math.max(mod.a, 0.7); mod.ef = 1; }
    m.en = Math.max(0, en - (run.duel ? ENERGY_COST.duel : ENERGY_COST.tourney));
    ev = {
      type, E, m, mod, stars: AT.starsOf(m), phase: 'swoop', t: 0, rt: 0, skill: 0,
      fb: '', fbSub: '', fbCol: '#fff', fbT: 9, fbY: H * 0.36,
      sport: SPORT_OF[E.game] || 'track', ts: 1, tsT: 1, excite: 0.7, exT: 0.9, fade: 0, fadeCol: '20,24,40', flash: 0, letterbox: 0, ci: -1, goT: 9,
      // minigame difficulty: faster keeper / marker, tighter windows in higher leagues and vs stronger rivals
      diff: run.easy ? 0.8 : 1 + run.lvl * 0.08 + (run.duel ? (run.duel.stars - 3) * 0.04 : 0),
      comps: run.duel
        ? [{ a: PLAYER, j: 0, name: AT.displayName(m), stars: AT.starsOf(m), power: 0, rank: 0, tier: AT.starsOf(m) },
          { a: run.duel.academy, j: 1, name: run.duel.name, stars: run.duel.stars, power: 0, rank: 0, tier: 0 }]
        : ACAD.map((a, j) => ({ a, j, name: j === 0 ? AT.displayName(m) : pick(NAMES), stars: j === 0 ? AT.starsOf(m) : rivalStars(RIVALS[j - 1], run.lvl, run.played), power: 0, rank: 0, tier: j === 0 ? AT.starsOf(m) : 0 })),
    };
    ev.comps.forEach((c) => (c.L = lookFor(c)));
    ev.game = GAMES[E.game](ev);
    FX.clear();
    // intro: the camera swoops from the cheering stands down to the line-up
    cam.x = W / 2; cam.y = H * 0.16; cam.z = 1.75; cam.sh = 0; camTo(W / 2, H / 2, 1, 2.3);
    AT.sfx('crowd');
  }
  // each competitor's cartoon look: their sport's kit in academy colours (football: national styles for rivals)
  const TRACK_BOOTS = ['#dee2e6', '#fa5252', '#212529', '#94d82d', '#fcc419'];
  function lookFor(c) {
    const m = ev.m, me = c.j === 0, sp = ev.sport;
    const name = me ? m.name : c.name;
    const L = TN.look(name, me ? m.id : c.name + c.j, sp);
    const hs = TN.hash(name + ':' + c.j);
    const tier = me ? ev.stars : clamp(Math.round(c.stars), 1, 4);
    const sportCol = '#' + ZONES[m.zone].shirt.toString(16).padStart(6, '0');
    const team = me ? sportCol : c.a.color, trim = me ? '#ffa94d' : sportCol, dark = TN.shade(team, 0.66);
    const num = me ? ((m.id * 7) % 98) + 1 : (hs % 98) + 1;
    const gold = tier >= 5;
    Object.assign(L, { skin: me ? SKIN[m.skin] || SKIN[1] : SKIN[hs % 5], hair: me ? TN.HAIRS[m.hair] || TN.HAIRS[0] : TN.HAIRS[(hs >> 3) % 5], tier, crown: gold, aura: gold ? 'rgba(255,224,102,.8)' : null, logo: me ? '#ffa94d' : null });
    switch (sp) {
      case 'football': {
        const kid = me ? AT.myKit && AT.myKit() : AT.rivalKit(c.j - 1, run.lvl);
        const K = kid && TN.KITS[kid];
        L.kit = K ? { shirt: K.shirt, shorts: K.shorts, socks: K.socks, trim: K.trim, stripes: K.stripes, num, numCol: K.num, name }
          : { shirt: tier === 1 ? '#ced4da' : team, shorts: tier >= 3 ? dark : '#f8f9fa', socks: team, trim: [trim], num, numCol: '#fff', name };
        L.kit.boots = gold ? '#fcc419' : ['#2b2d42', '#fa5252', '#339af0', '#ffd43b'][tier - 1]; L.kit.studs = true;
        L.gold = gold && !K;
        break;
      }
      case 'swim': L.swim = gold ? '#fcc419' : tier === 1 ? '#495057' : team; L.goggles = tier >= 3 ? '#66d9e8' : '#ced4da'; L.kit = { shorts: tier === 1 ? '#343a40' : team }; L.gold = gold; break;
      case 'boxing': L.kit = { shirt: tier >= 3 ? L.skin : '#f8f9fa', shorts: team, boots: team }; L.sleeves = 'none'; L.tank = tier < 3; L.gloves = gold ? '#fcc419' : tier === 1 ? '#adb5bd' : team; L.belt = gold ? null : '#f8f9fa'; L.headgear = tier === 2 ? team : null; L.gold = gold; break;
      case 'gym': L.kit = { shirt: tier === 1 ? '#adb5bd' : team, shorts: dark, boots: '#2b2d42' }; L.tank = true; L.sleeves = 'none'; L.belt = tier >= 2 ? '#8d5524' : null; L.chalk = true; L.gold = gold; break;
      case 'hoops': L.kit = { shirt: tier === 1 ? '#adb5bd' : team, shorts: tier === 1 ? '#868e96' : dark, boots: '#f8f9fa', num, numCol: '#fff', name }; L.tank = true; L.sleeves = 'none'; L.band = tier >= 2 ? trim : null; L.gold = gold; break;
      default: L.kit = { shirt: tier === 1 ? '#adb5bd' : team, shorts: tier === 1 ? '#495057' : dark, boots: TRACK_BOOTS[tier - 1], num, numCol: '#fff' }; L.tank = true; L.sleeves = 'none'; L.gold = gold;
    }
    return L;
  }
  const fig = (c, x, y, s, pose) => TN.char(g, x, y, s, c.L, pose);
  const meC = () => ev.comps[0];
  const cheer = (a) => { ev.exT = Math.max(ev.exT, a); };
  const flagCols = () => ev.comps.map((c) => c.a.color);

  // ---------- 2D camera: smooth pans and zooms, screen shake ----------
  const cam = { x: 180, y: 320, z: 1, tx: 180, ty: 320, tz: 1, k: 4, sh: 0 };
  function camTo(x, y, z, k = 4) { cam.tx = x; cam.ty = y; cam.tz = z; cam.k = k; }
  const camHome = (k = 4) => camTo(W / 2, H / 2, 1, k);
  function shake(a) { cam.sh = Math.max(cam.sh, a); }
  function camUpdate(dt) {
    const f = 1 - Math.exp(-dt * cam.k);
    cam.x += (cam.tx - cam.x) * f; cam.y += (cam.ty - cam.y) * f; cam.z += (cam.tz - cam.z) * f;
    cam.sh = Math.max(0, cam.sh - dt * 28);
  }
  function camApply() {
    const z = cam.z, hx = W / 2 / z, hy = H / 2 / z;
    const x = z >= 1 ? clamp(cam.x, hx, W - hx) : W / 2, y = z >= 1 ? clamp(cam.y, hy, H - hy) : H / 2;
    const sx = cam.sh ? rand(-1, 1) * cam.sh : 0, sy = cam.sh ? rand(-1, 1) * cam.sh : 0;
    g.translate(W / 2 + sx, H / 2 + sy); g.scale(z, z); g.translate(-x, -y);
  }
  // ---------- automatic quality: fewer particles and fans when the frame rate drops (characters stay full quality) ----------
  // the minigame canvas keeps full resolution; if the frame rate stays below 40 FPS for 5 s it first draws fewer
  // particles, then a smaller crowd (the academy's own quality steps can also ask for a smaller crowd)
  const Q = { lvl: 2, dens: 1, t: 0, n: 0, good: 0, slow: 0, hold: 0 };
  function setQ(l) { Q.lvl = l; FX.cap = [70, 90, 220][l]; Q.dens = (l === 0 ? 0.55 : 1) * (AT.crowdLow ? 0.65 : 1); }
  function perfTick(dt) {
    if (Q.hold > 0) { Q.hold -= dt; return; }
    Q.t += dt; Q.n++;
    if (Q.t < 1) return;
    const fps = Q.n / Q.t, win = Q.t; Q.t = 0; Q.n = 0;
    if (fps < 40) { Q.good = 0; if ((Q.slow += win) >= 5 && Q.lvl > 0) { Q.slow = 0; setQ(Q.lvl - 1); } }
    else { Q.slow = 0; if (fps > 57 && Q.lvl < 2 && (Q.good += win) > 12) { setQ(Q.lvl + 1); Q.good = 0; } }
  }
  T.quality = (l) => (l == null ? Q.lvl : setQ(l));

  // big bouncy PERFECT / GOOD / MISS
  function feedback(kind, sub = '', y) {
    ev.fb = kind === 'perfect' ? 'PERFECT!' : kind === 'good' ? 'GOOD!' : 'MISS';
    ev.fbCol = kind === 'perfect' ? '#51cf66' : kind === 'good' ? '#ffd43b' : '#ff6b6b';
    ev.fbSub = sub; ev.fbT = 0; ev.fbY = y || H * 0.36;
    AT.sfx(kind === 'perfect' ? 'perfect' : kind === 'good' ? 'good' : 'miss');
    if (kind === 'perfect') cheer(1); else if (kind === 'good') cheer(0.75);
  }
  function setPhase(p) {
    ev.phase = p; ev.t = 0; ev.fade = 0; ev.fadeCol = p === 'podium' || p === 'action' ? '255,255,255' : '20,24,40';
    if (p !== 'play') ev.fb = '';
    if (p === 'action' || p === 'podium' || p === 'result') camHome(5);
    if (p === 'podium') { ev.pod = { medal: [] }; FX.clear(); }
  }

  // ---------- input ----------
  let ptr = null;
  const local = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  function tapPhase() { // taps that move the show along; true = handled
    if (ev.phase === 'swoop') { if (ev.t > 0.25) setPhase('intro'); return true; }
    if (ev.phase === 'intro') { if (ev.t > 0.35) setPhase('count'); return true; }
    if (ev.phase === 'count') return true;
    if (ev.phase === 'result') { if (ev.t > 0.8) setPhase('podium'); return true; }
    if (ev.phase === 'podium') { if (ev.t > 1.0) nextEvent(); return true; }
    return false;
  }
  cv.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    if (!ev) return;
    const [x, y] = local(e);
    ptr = { id: e.pointerId, x, y, t: performance.now() };
    if (tapPhase()) { ptr = null; return; }
    if (ev.phase === 'play' && ev.game.down) ev.game.down(x, y);
  });
  const endPtr = (e) => {
    if (!ptr || e.pointerId !== ptr.id) return;
    const [x, y] = local(e);
    const p = ptr; ptr = null;
    if (ev && ev.phase === 'play' && ev.game.up) ev.game.up(x, y, x - p.x, y - p.y);
  };
  window.addEventListener('pointerup', endPtr);
  window.addEventListener('pointercancel', endPtr);
  // keyboard fallback for desktop testing: space = tap/hold, arrows = swipe
  window.addEventListener('keydown', (e) => {
    if (!ev || e.repeat) return;
    if (e.code === 'Space') {
      if (tapPhase()) return;
      if (ev.phase === 'play' && ev.game.down) ev.game.down(W / 2, H * 0.5, true);
    }
    if (ev.phase === 'play' && ev.game.up) {
      const sw = { ArrowLeft: [-60, -80], ArrowRight: [60, -80], ArrowUp: [0, -90], ArrowDown: [0, 90] }[e.code];
      if (sw) ev.game.up(W / 2, H * 0.6, sw[0], sw[1]);
    }
  });
  window.addEventListener('keyup', (e) => { if (ev && e.code === 'Space' && ev.phase === 'play' && ev.game.up) ev.game.up(W / 2, H * 0.5, 0, 0, true); });

  // ======================================================================
  // MINIGAMES — each returns { update(dt), draw() (the scene, under the camera), ui() (overlay),
  // down(x,y), up(x,y,dx,dy), done, skill }
  // ======================================================================
  const GAMES = {};
  const stands = (h, bg) => { TN.crowd(g, 0, 0, W, h, ev.rt, ev.excite, Q.dens, flagCols(), bg); g.fillStyle = '#fff'; g.fillRect(0, h - 4, W, 4); };

  // ---------- SPRINT: random PERFECT/GOOD zone, 3 taps ----------
  GAMES.sprint = (ev) => {
    const M = ev.mod;
    const G = { round: 0, results: [], mode: 'aim', t: 0, speed: M.ef, run: 0, ph: 0, scroll: 0, done: false, started: false, burst: 0 };
    // Speed widens the PERFECT / GOOD zones; low energy shrinks them
    const pw = (0.034 + ev.stars * 0.004) * (0.8 + M.s * 0.6) * M.ef, gw = 0.115 * (0.8 + M.s * 0.45) * (0.85 + 0.15 * M.ef);
    const ty = () => H * 0.17, th = () => H * 0.24, rx = () => W * 0.36, ry = () => ty() + th() * 0.8;
    function newRound() {
      G.c = rand(0.2, 0.8); G.m = Math.random() < 0.5 ? 0 : 1; G.dir = G.m ? -1 : 1;
      G.v = rand(1.05, 1.55) * ev.diff;
      if (G.round === 2) G.v *= 1 - M.a * 0.4; // Stamina: the marker slows down on the last tap
      G.mode = 'aim'; G.t = 0;
    }
    newRound();
    function score(r, sub) {
      G.results.push(r);
      const kind = r === 1 ? 'perfect' : r > 0 ? 'good' : 'miss';
      feedback(kind, sub, H * 0.47);
      G.speed += r === 1 ? 1.3 : r > 0 ? 0.5 : -0.7;
      G.mode = 'fb'; G.t = 0;
      if (!G.started) { G.started = true; G.burst = 1; FX.add('dust', rx() - 8, ry(), 10, { ang: Math.PI, spread: 1.3, speed: 110, size: 4, life: 0.7 }); shake(3); AT.sfx('whoosh'); }
      else if (r > 0) { G.burst = Math.max(G.burst, r === 1 ? 0.7 : 0.35); FX.add('dust', rx() - 8, ry(), 6, { ang: Math.PI, spread: 1, speed: 90, size: 3 }); }
      if (r === 1) FX.ring(rx(), ry() - 50, 30, '#fff3bf');
    }
    G.down = () => {
      if (G.mode !== 'aim') return;
      const d = Math.abs(G.m - G.c);
      score(d <= pw ? 1 : d <= gw ? 0.55 : 0, d <= gw ? '' : 'Runner slows down');
    };
    G.update = (dt) => {
      G.t += dt; G.burst = Math.max(0, G.burst - dt * 1.4);
      G.speed += (M.ef - G.speed) * Math.min(1, dt * 0.9); // tired runners settle at a lower speed
      G.speed = Math.max(0.25, G.speed);
      if (G.started) { G.ph += dt * (6 + G.speed * 7); G.scroll += dt * G.speed * 260; }
      if (G.mode === 'aim') {
        G.m += G.dir * G.v * dt;
        if (G.m > 1) { G.m = 2 - G.m; G.dir = -1; } else if (G.m < 0) { G.m = -G.m; G.dir = 1; }
        if (G.t > 3.4) score(0, 'Too slow!');
      } else if (G.mode === 'fb' && G.t > 0.65) {
        G.round++;
        if (G.round >= 3) { G.mode = 'end'; G.t = 0; } else newRound();
      } else if (G.mode === 'end' && G.t > 0.4) {
        G.done = true; G.skill = G.results.reduce((a, b) => a + b, 0) / 3;
      }
    };
    G.draw = () => {
      const E = ev.E, TY = ty(), TH = th();
      g.fillStyle = E.top; g.fillRect(0, 0, W, H);
      stands(TY - 2);
      g.fillStyle = E.lane; g.fillRect(0, TY, W, TH);
      g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 3;
      for (const y of [TY, TY + TH / 2, TY + TH]) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
      g.fillStyle = 'rgba(255,255,255,.55)';
      for (let x = -(G.scroll % 70); x < W; x += 70) g.fillRect(x, TY + TH * 0.9, 26, 5);
      // speed lines when boosted
      if (G.speed > 1.4) { g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 3; for (let k = 0; k < 4; k++) { const y = TY + TH * (0.3 + k * 0.12); const x = W * 0.06 + ((G.scroll * 1.7 + k * 50) % 90); g.beginPath(); g.moveTo(x, y); g.lineTo(x + 30 * G.speed, y); g.stroke(); } }
      // crouched in the blocks until the first tap, then explosive steps and pumping arms
      let pose;
      if (!G.started) pose = Object.assign(PZ.crouch(1), { by: 5 + Math.sin(ev.rt * 3) * 0.4 });
      else { pose = PZ.run(G.ph, clamp(0.65 + G.speed * 0.3, 0.6, 1.3), 1); pose.lean += G.burst * 0.55; if (G.speed < 0.6) pose.expr = 'sad'; }
      if (!G.started) { g.fillStyle = '#495057'; g.fillRect(rx() - 22, ry() - 4, 16, 5); }
      fig(meC(), rx(), ry(), 1.7, pose);
    };
    G.ui = () => {
      const TY = ty(), TH = th();
      txt('SPEED', W * 0.08, TY + TH + 26, 13, '#fff', 'left');
      rr(g, W * 0.26, TY + TH + 18, W * 0.66, 16, 8); g.fillStyle = 'rgba(0,0,0,.25)'; g.fill();
      rr(g, W * 0.26, TY + TH + 18, W * 0.66 * clamp(G.speed / 3, 0.05, 1), 16, 8); g.fillStyle = G.speed > 1.4 ? '#51cf66' : '#fff'; g.fill();
      // timing bar
      const y = H * 0.66, bw = W * 0.86, bx = (W - bw) / 2, bh = 42;
      rr(g, bx - 5, y - bh / 2 - 5, bw + 10, bh + 10, 22); g.fillStyle = '#fff'; g.fill();
      rr(g, bx, y - bh / 2, bw, bh, 18); g.fillStyle = '#ff8787'; g.fill();
      g.save(); rr(g, bx, y - bh / 2, bw, bh, 18); g.clip();
      g.fillStyle = '#ffe066'; g.fillRect(bx + bw * (G.c - gw), y - bh / 2, bw * gw * 2, bh);
      g.fillStyle = '#51cf66'; g.fillRect(bx + bw * (G.c - pw), y - bh / 2, bw * pw * 2, bh);
      g.restore();
      const mx = bx + bw * clamp(G.m, 0, 1);
      g.fillStyle = '#2b2d42'; rr(g, mx - 4, y - bh / 2 - 12, 8, bh + 24, 4); g.fill();
      g.beginPath(); g.moveTo(mx - 11, y - bh / 2 - 20); g.lineTo(mx + 11, y - bh / 2 - 20); g.lineTo(mx, y - bh / 2 - 6); g.fill();
      for (let k = 0; k < 3; k++) dot(W / 2 + (k - 1) * 34, y + 52, 13, G.results[k]);
      if (G.mode === 'aim') txt(G.started ? 'TAP!' : 'TAP TO START!', W / 2, y + 96, 30 + Math.sin(ev.t * 10) * 3, '#fff');
    };
    return G;
  };

  // ---------- PENALTY: run-up, kick, keeper dive, net bulge, slow-motion replay of a PERFECT shot. 5 shots ----------
  GAMES.penalty = (ev) => {
    const M = ev.mod;
    const G = { shot: 0, shots: [], mode: 'aim', t: 0, done: false, aph: rand(0, 6), rt: 0 };
    const gx = () => W * 0.12, gw = () => W * 0.76, gy = () => H * 0.2, gh = () => H * 0.15;
    // Speed: the aiming arrow sweeps slower. Power: faster shots and a slower keeper dive.
    const aimV = (2.5 - M.s * 1.4) * ev.diff * (1 + (1 - M.ef) * 0.6);
    const aimOf = () => Math.sin(G.aph) * 1.3; // -1.3..1.3 of the half goal width (beyond ~1.17 is wide)
    const reach = () => gw() * (0.15 - ev.stars * 0.009);
    G.kph = rand(0, 6); G.ks = rand(1.8, 2.8) * ev.diff; G.kx = W / 2;
    const keeperX = () => W / 2 + Math.sin(G.kph) * gw() * 0.34;
    const KEEPER = Object.assign(TN.look('Keeper', 'gk' + run.lvl), { skin: SKIN[2], hair: '#3b2a1a', style: 'buzz', hands: '#f8f9fa', kit: { shirt: '#fab005', shorts: '#212529', socks: '#fab005', boots: '#2b2d42', num: 1, numCol: '#212529' } });
    const bx0 = () => W / 2, by0 = () => H * 0.7;
    function shoot(dx, dy) {
      if (G.mode !== 'aim') return;
      const ty = gy() + gh() * 0.55;
      const up = Math.max(30, -dy);
      G.tx = bx0() + clamp(dx / up, -1.4, 1.4) * gw() * 0.42; G.ty = ty; // steep diagonal = corner, very flat = wide
      G.flight = Math.max(0.18, 0.5 - ev.stars * 0.035 - M.p * 0.13) * (1 + (1 - M.ef) * 0.5);
      G.kx = keeperX(); G.kx0 = G.kx;
      G.mode = 'runup'; G.t = 0; // the keeper stays set during the short run-up
    }
    // tap = shoot where the arrow points; a swipe still aims by hand
    G.up = (x, y, dx, dy) => { if (Math.hypot(dx, dy) < 18) shoot(aimOf() * 100, -100); else if (dy < -10) shoot(dx, dy); };
    G.update = (dt) => {
      G.t += dt;
      const half = gw() / 2, cx = W / 2;
      if (G.mode === 'aim') {
        G.kph += dt * G.ks; G.kx = keeperX(); G.aph += dt * aimV;
        if (G.t > 4.5) shoot(aimOf() * 100, -100); // never stall
      } else if (G.mode === 'runup') {
        if (G.t >= 0.3) { G.mode = 'fly'; G.t = 0; AT.sfx('kick'); shake(3); FX.add('dust', bx0(), by0() + 8, 7, { ang: -Math.PI / 2, spread: 2.4, speed: 70, size: 3 }); }
      } else if (G.mode === 'fly') {
        // the keeper dives toward the ball; faster, harder shots from higher stars are harder to reach
        const dive = gw() * (0.62 - ev.stars * 0.07) * ev.diff * (1.1 - M.p * 0.45);
        G.kx += clamp(G.tx - G.kx, -dive * dt, dive * dt);
        if (G.t >= G.flight) {
          const off = Math.abs(G.tx - cx);
          let r, sub;
          if (off > half - 6) { r = 0; sub = 'Wide!'; }
          else if (Math.abs(G.kx - G.tx) < reach() + 10) { r = 0; sub = 'Saved!'; }
          else if (off > gw() * 0.3) { r = 1; sub = 'GOAL! Top corner'; }
          else { r = 0.8; sub = 'GOAL!'; }
          G.shots.push(r); G.res = r; G.sub = sub; feedback(r === 1 ? 'perfect' : r > 0 ? 'good' : 'miss', sub, H * 0.5);
          G.rec = { tx: G.tx, ty: G.ty, kx0: G.kx0, kx1: G.kx, flight: G.flight };
          if (r > 0) { G.bulgeT = 0; AT.sfx('net'); shake(r === 1 ? 8 : 5); FX.add('spark', G.tx, G.ty, 8, { speed: 160, life: 0.4 }); }
          else if (sub === 'Saved!') { AT.sfx('punch'); shake(4); FX.add('spark', G.tx, G.ty, 10, { speed: 180, col: '#fff', life: 0.35 }); }
          G.mode = 'fb'; G.t = 0;
        }
      } else if (G.mode === 'fb') {
        if (G.bulgeT != null) G.bulgeT += dt;
        if (G.res === 1 && !G.replayed && G.t > 0.75) { G.mode = 'replay'; G.rt = 0; G.replayed = true; G.bulgeT = null; G.rpNet = false; AT.sfx('whoosh'); camTo((G.rec.tx + W / 2) / 2, H * 0.42, 1.25, 3); }
        else if (G.t > (G.res > 0 ? 1.45 : 1.0)) {
          G.shot++; G.bulgeT = null; G.replayed = false;
          if (G.shot >= 5) { G.done = true; G.goals = G.shots.filter((s) => s > 0).length; G.skill = G.shots.reduce((a, b) => a + b, 0) / 5; }
          else { G.mode = 'aim'; G.t = 0; G.ks = rand(1.8, 3.1) * ev.diff * (Math.random() < 0.5 ? -1 : 1); }
        }
      } else if (G.mode === 'replay') { // slow-motion replay of a PERFECT shot
        G.rt += dt * 0.33; ev.letterboxT = 1;
        if (G.rt > 0.12 + G.rec.flight && !G.rpNet) { G.rpNet = true; G.bulgeT = 0; shake(5); }
        if (G.bulgeT != null && G.rpNet) G.bulgeT += dt * 0.5;
        if (G.rt > G.rec.flight + 0.42) { G.mode = 'fb'; G.t = 1.05; G.rpNet = false; camHome(4); }
      }
    };
    function net(X, Y, GW, GH) {
      // the net bulges backwards (up the screen) around where the ball hit
      const bt = G.bulgeT, R = G.rec;
      const amp = bt != null && R && G.res > 0 ? 17 * Math.exp(-bt * 3.2) * (0.65 + 0.35 * Math.cos(bt * 17)) : 0;
      const disp = (px, py) => { if (amp < 0.2) return [px, py]; const k = Math.exp(-((px - R.tx) ** 2 + (py - R.ty) ** 2) / (2 * 30 * 30)) * amp; return [px + (px - R.tx) * k * 0.01, py - k]; };
      g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1;
      for (let x = X; x <= X + GW + 0.1; x += 12) { g.beginPath(); for (let y = Y; y <= Y + GH + 0.1; y += 6) { const [a, b] = disp(x, y); if (y === Y) g.moveTo(a, b); else g.lineTo(a, b); } g.stroke(); }
      for (let y = Y; y <= Y + GH + 0.1; y += 12) { g.beginPath(); for (let x = X; x <= X + GW + 0.1; x += 6) { const [a, b] = disp(x, y); if (x === X) g.moveTo(a, b); else g.lineTo(a, b); } g.stroke(); }
    }
    function ballPos(k, rec) { // along the shot (k 0..1) with a slight lift
      const sx = bx0(), sy = by0();
      return [sx + (rec.tx - sx) * k, sy + (rec.ty - sy) * k - Math.sin(k * Math.PI) * 30, 11 - k * 4];
    }
    const football = (x, y, r) => { IC.draw(g, 'football', x, y, r * 3); };
    G.draw = () => {
      for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#40c057' : '#51cf66'; g.fillRect(0, (i * H) / 8, W, H / 8); }
      const X = gx(), Y = gy(), GW = gw(), GH = gh();
      stands(Y - 14);
      g.fillStyle = 'rgba(255,255,255,.22)'; g.fillRect(X, Y, GW, GH);
      net(X, Y, GW, GH);
      g.strokeStyle = '#fff'; g.lineWidth = 7; g.lineCap = 'round'; g.beginPath(); g.moveTo(X, Y + GH); g.lineTo(X, Y); g.lineTo(X + GW, Y); g.lineTo(X + GW, Y + GH); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 3; g.strokeRect(W * 0.3, Y + GH, W * 0.4, H * 0.08);
      circle(W / 2, by0() + 2, 3, 'rgba(255,255,255,.8)'); // penalty spot
      const replay = G.mode === 'replay', R = G.rec;
      // keeper: set stance, then a full stretch dive toward the shot
      const ky = Y + GH * 0.98;
      let kx = G.kx, kp;
      if (replay) { const k = clamp((G.rt - 0.12) / R.flight, 0, 1); kx = R.kx0 + (R.kx1 - R.kx0) * k; kp = PZ.dive(k, Math.sign(R.tx - R.kx0) || 1); }
      else if (G.mode === 'fly' || G.mode === 'fb') { const k = G.mode === 'fb' ? 1 : clamp((G.t / G.flight) * 1.3, 0, 1); kp = PZ.dive(k, Math.sign(G.tx - G.kx0) || 1); if (G.mode === 'fb' && G.res === 0 && G.sub === 'Saved!') kp.expr = 'proud'; }
      else kp = PZ.keeper(ev.rt);
      TN.char(g, kx, ky, 1.3, KEEPER, kp);
      // ball (with motion blur trail while flying)
      let b = [bx0(), by0(), 11], trail = 0;
      if (replay) { const k = clamp((G.rt - 0.12) / R.flight, 0, 1); b = k >= 1 ? [R.tx, R.ty + Math.min(18, (G.rt - 0.12 - R.flight) * 60), 7] : ballPos(k, R); trail = k > 0 && k < 1 ? 1 : 0; }
      else if (G.mode === 'fly') { b = ballPos(clamp(G.t / G.flight, 0, 1), G); trail = 1; }
      else if (G.mode === 'fb' && R) {
        const t = G.t;
        if (G.res > 0) b = [R.tx, R.ty + Math.min(22, t * 50), 7];
        else if (G.sub === 'Saved!') { const d = R.tx >= W / 2 ? 1 : -1; b = [R.tx + d * t * 160, R.ty + t * 200 - Math.sin(Math.min(1, t * 2) * Math.PI) * 40, 8]; }
        else { const d = R.tx >= W / 2 ? 1 : -1; b = [R.tx + d * t * 140, R.ty - t * 50, 7]; }
      }
      if (trail) {
        const src = replay ? R : G, k0 = replay ? clamp((G.rt - 0.12) / R.flight, 0, 1) : clamp(G.t / G.flight, 0, 1);
        for (let i = 4; i >= 1; i--) { const p = ballPos(Math.max(0, k0 - i * 0.06), src); g.globalAlpha = 0.12 * (5 - i); circle(p[0], p[1], p[2], '#fff'); }
        g.globalAlpha = 1;
        g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 2; for (const o of [-6, 0, 6]) { g.beginPath(); g.moveTo(b[0] + o, b[1] + 14); g.lineTo(b[0] + o * 0.6, b[1] + 30); g.stroke(); }
      }
      football(b[0], b[1], b[2]);
      // shooter: run-up from behind, big kick with a blurred leg, then the celebration
      const me = meC(), sx = W / 2 - 18, sy = by0() + 34;
      if (G.mode === 'aim') fig(me, sx - 14, sy + 12, 1.5, Object.assign(PZ.stand(ev.rt), { view: 'back' }));
      else if (G.mode === 'runup') { const k = clamp(G.t / 0.3, 0, 1); fig(me, sx - 14 + k * 14, sy + 12 - k * 12, 1.5, PZ.runBack(ev.rt * 16, 1)); }
      else if (G.mode === 'fly' || replay) { const k = replay ? clamp(G.rt / 0.16, 0, 1) : clamp(G.t / 0.22, 0, 1); const p = PZ.kickBack(0.5 + k * 0.5); p.blur = { leg: 1, dA: 0.9 }; fig(me, sx, sy, 1.5, p); }
      else if (G.mode === 'fb' && G.res > 0) fig(me, sx, sy, 1.5, Object.assign(PZ.victory('football', G.t, me.L), { view: 'front' }));
      else fig(me, sx, sy, 1.5, Object.assign(PZ.sad(G.t), { view: 'front' }));
    };
    G.ui = () => {
      if (G.mode === 'aim') {
        // sweeping aim arrow: dashed line to where the shot will go
        const ax = W / 2 + aimOf() * gw() * 0.42, ay = gy() + gh() * 0.55, ang = Math.atan2(ay - by0(), ax - bx0());
        g.save(); g.setLineDash([8, 8]); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 4;
        g.beginPath(); g.moveTo(bx0(), by0() - 14); g.lineTo(ax, ay); g.stroke(); g.restore();
        circle(ax, ay, 9, Math.abs(aimOf()) > 1.17 ? '#ff6b6b' : '#ffe066');
        g.save(); g.translate(bx0() + Math.cos(ang) * 52, by0() + Math.sin(ang) * 52); g.rotate(ang); IC.draw(g, 'arrow', 0, 0, 42); g.restore();
        txt('TAP TO SHOOT!', W / 2, H * 0.88, 24, '#fff');
        txt('or swipe to aim', W / 2, H * 0.88 + 24, 13, '#fff');
      }
      if (G.mode === 'replay') { circle(22, H * 0.14 + 12, 6, Math.sin(ev.rt * 8) > 0 ? '#fa5252' : '#c92a2a'); txt('REPLAY', 34, H * 0.14 + 12, 18, '#fff', 'left'); }
      for (let k = 0; k < 5; k++) dot(W / 2 + (k - 2) * 38, H * 0.95, 14, G.shots[k] == null ? null : G.shots[k] > 0 ? 1 : 0);
    };
    return G;
  };

  // ---------- HOOPS: swipe up to shoot; swipe length = distance, angle = direction. 5 shots ----------
  // Power: the same swipe carries farther. Speed: the moving hoop (shots 3-5) moves slower. Stamina: steadier aim on shots 4-5.
  // Dribbling while aiming, a jump shot with a high arc, the net swishes; a PERFECT shot becomes a dunk.
  GAMES.hoops = (ev) => {
    const M = ev.mod;
    const DIST = [0.5, 0.6, 0.7, 0.78, 0.86];
    const G = { shot: 0, shots: [], mode: 'aim', t: 0, done: false, hph: rand(0, 6), sw: 0, ball: null, msg: '', netT: 9 };
    const reachK = (0.62 + M.p * 0.55) * (0.85 + 0.15 * M.ef);         // distance per half-screen of swipe
    const hoopV = (k) => (k < 2 ? 0 : (1.1 + (k - 2) * 0.35) * ev.diff * (1.15 - M.s * 0.6) * (1 + (1 - M.ef) * 0.5));
    const swayAmp = (k) => (k < 3 ? 0 : W * 0.085 * (1 - M.a * 0.8) * (k === 4 ? 1.3 : 1) * (1 + (1 - M.ef) * 0.6));
    const tol = (0.75 + 0.25 * M.ef) / Math.sqrt(ev.diff);
    const D = () => DIST[G.shot];
    const hoopY = () => H * (0.5 - D() * 0.3), hoopS = () => 1.15 - D() * 0.6;
    const hoopX = () => W / 2 + Math.sin(G.hph) * W * 0.27 * (G.shot >= 2 ? 1 : 0);
    const ballX0 = () => W / 2 + G.sw, ballY0 = () => H * 0.8;
    const footY = () => H * 0.935, SC = 1.4;
    const needLen = () => (D() / reachK) * H * 0.5;
    function shoot(dx, dy) {
      if (G.mode !== 'aim') return;
      const len = Math.hypot(dx, dy), reach = (len / (H * 0.5)) * reachK, ed = reach - D();
      const bx = ballX0(), by = ballY0(), hy = hoopY(), hx = hoopX();
      const lx = bx + (dx / Math.max(20, -dy)) * (by - hy);
      const rw = 34 * hoopS(), ex = lx - hx;
      let r, sub;
      if (Math.abs(ex) < rw * 0.5 * tol && Math.abs(ed) < 0.06 * tol) { r = 1; sub = 'Slam dunk!'; }
      else if (Math.abs(ex) < rw * 1.15 * tol && Math.abs(ed) < 0.13 * tol) { r = 0.6; sub = 'Bounces in!'; }
      else { r = 0; sub = ed < -0.18 ? 'Air ball!' : ed > 0.16 ? 'Off the backboard!' : 'Off the rim!'; }
      G.ball = { x0: bx, y0: by, x1: lx, y1: hy - 4 * hoopS() - (ed > 0 ? Math.min(40, ed * 160) : ed * 120), hx, r, ed, ex, px: bx };
      G.res = r; G.sub = sub; G.mode = 'fly'; G.t = 0; G.flight = r === 1 ? 0.95 : 0.8; G.dunk = r === 1; G.slam = false;
      if (G.dunk) { camTo(hx, hy + 30, 1.3, 3); AT.sfx('whoosh'); } else AT.sfx('tap');
    }
    G.up = (x, y, dx, dy) => {
      if (G.mode !== 'aim') return;
      if (dy < -25) shoot(dx, dy); else { G.msg = 'Swipe UP to shoot!'; G.msgT = 1.2; }
    };
    G.update = (dt) => {
      G.t += dt; G.netT += dt; if (G.msgT) G.msgT -= dt;
      G.hph += dt * hoopV(G.shot);
      if (G.mode === 'aim') {
        G.sw = Math.sin(ev.t * 3.1) * swayAmp(G.shot);
        if (G.t > 6.5) shoot(rand(-40, 40), -needLen() * rand(0.6, 1.4)); // never stall
      } else if (G.mode === 'fly') {
        const k = G.t / G.flight;
        if (G.dunk) {
          if (k > 0.55 && k < 0.85) ev.tsT = 0.35; // slow motion around the slam
          if (k >= 0.78 && !G.slam) { G.slam = true; G.netT = 0; shake(10); AT.sfx('dunk'); cheer(1); const b = G.ball; FX.add('spark', b.hx, hoopY(), 14, { speed: 220, life: 0.45 }); FX.ring(b.hx, hoopY(), 40, '#ffd43b'); }
        } else if (G.res > 0 && k > 0.92 && G.netT > 1) G.netT = 0;
        if (G.t >= G.flight) {
          G.shots.push(G.res); feedback(G.res === 1 ? 'perfect' : G.res > 0 ? 'good' : 'miss', G.sub, H * 0.55);
          if (G.res > 0 && !G.dunk) AT.sfx('swish');
          G.mode = 'fb'; G.t = 0;
          if (G.dunk) camHome(3);
        }
      } else if (G.mode === 'fb' && G.t > (G.dunk ? 1.25 : 1.0)) {
        G.shot++; G.ball = null; G.sw = 0; G.dunk = false;
        if (G.shot >= 5) { G.done = true; G.goals = G.shots.filter((v) => v > 0).length; G.skill = G.shots.reduce((a, b) => a + b, 0) / 5; }
        else { G.mode = 'aim'; G.t = 0; }
      }
    };
    function court() {
      g.fillStyle = '#e0a96d'; g.fillRect(0, 0, W, H);
      g.fillStyle = 'rgba(160,100,50,.25)'; for (let x = 0; x < W; x += 34) g.fillRect(x, 0, 2, H);
      stands(H * 0.1, '#3b2f6e');
      g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 4;
      g.beginPath(); g.ellipse(W / 2, H * 0.36, W * 0.42, H * 0.16, 0, Math.PI * 0.05, Math.PI * 0.95); g.stroke();
      g.fillStyle = 'rgba(112,72,232,.35)'; g.fillRect(W * 0.36, H * 0.2, W * 0.28, H * 0.22);
      g.strokeRect(W * 0.36, H * 0.2, W * 0.28, H * 0.22);
    }
    function hoop(x, y, s, front) {
      g.save(); g.translate(x, y); g.scale(s, s);
      const nt = G.netT, sw = nt < 1.2 ? Math.sin(nt * 22) * Math.exp(-nt * 3.5) : 0, st = nt < 1.2 ? Math.exp(-nt * 3) * 12 : 0;
      const shakeR = nt < 0.6 && G.dunk ? Math.sin(nt * 60) * 3 * (1 - nt / 0.6) : 0;
      g.translate(0, shakeR);
      if (!front) {
        g.fillStyle = '#868e96'; g.fillRect(-4, -150, 8, 46);
        rr(g, -62, -110, 124, 78, 6); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 4; g.strokeStyle = '#495057'; g.stroke();
        g.strokeStyle = '#fa5252'; g.lineWidth = 4; g.strokeRect(-22, -70, 44, 32);
        // net: swishes and stretches when the ball goes through
        g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 2;
        for (let k = -3; k <= 3; k++) { g.beginPath(); g.moveTo(k * 10, -4); g.quadraticCurveTo(k * 8 + sw * 8, 16, k * (6 - st * 0.2) + sw * 10, 34 + st); g.stroke(); }
        for (const yy of [10, 22, 34]) { const w = 34 - yy * 0.4 - (yy / 34) * st * 0.6; g.beginPath(); g.moveTo(-w + sw * yy * 0.3, yy + (yy / 34) * st); g.lineTo(w + sw * yy * 0.3, yy + (yy / 34) * st); g.stroke(); }
        g.lineWidth = 6; g.strokeStyle = '#e8590c'; g.beginPath(); g.ellipse(0, -4, 36, 9, 0, Math.PI, Math.PI * 2); g.stroke();
      } else { g.lineWidth = 6; g.strokeStyle = '#ff6b00'; g.beginPath(); g.ellipse(0, -4, 36, 9, 0, 0, Math.PI); g.stroke(); }
      g.restore();
    }
    function ballAt(x, y, r) {
      circle(x, y, r, '#ff922b');
      g.strokeStyle = '#2b2d42'; g.lineWidth = Math.max(1.5, r * 0.12);
      g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.moveTo(x - r, y); g.lineTo(x + r, y); g.moveTo(x, y - r); g.lineTo(x, y + r); g.stroke();
      g.fillStyle = 'rgba(255,255,255,.3)'; g.beginPath(); g.arc(x - r * 0.35, y - r * 0.35, r * 0.3, 0, Math.PI * 2); g.fill();
    }
    G.draw = () => {
      court();
      const hx = G.ball ? G.ball.hx : hoopX(), hy = hoopY(), s = hoopS();
      const me = meC(), sx = ballX0();
      // the dunker flies to the rim (drawn at hoop depth, smaller), everyone else shoots from the line
      let dunkPos = null;
      if (G.dunk && (G.mode === 'fly' || G.mode === 'fb')) {
        const k = G.mode === 'fly' ? clamp(G.t / G.flight, 0, 1) : 1, ft = G.mode === 'fb' ? G.t : 0;
        const ks = Math.min(1, k / 0.78), sc = SC * (1 - ks * (1 - s));
        const peakFoot = hy + 40 * sc;
        let px = sx + (hx - sx) * ks, py = footY() + (peakFoot - footY()) * ks - Math.sin(ks * Math.PI) * 40;
        if (ft > 0.25) { const d = Math.min(1, (ft - 0.25) / 0.35); py = peakFoot + (footY() - 20 - peakFoot) * d * d; }
        dunkPos = { x: px, y: py, sc, k, ft };
      }
      hoop(hx, hy, s, false);
      // the ball
      let bx = sx + 13 * SC, by = footY() - 8 - Math.abs(Math.sin(ev.rt * 7)) * 30, br = 15, inFront = true;
      if (G.ball) {
        const b = G.ball, k = G.mode === 'fly' ? clamp(G.t / G.flight, 0, 1) : 1;
        if (G.dunk) {
          const d = dunkPos;
          if (d.k < 0.78) { bx = d.x + 4; by = d.y - 50 * d.sc; br = 13 * d.sc; }
          else { bx = b.hx; by = hy + (d.ft + (d.k - 0.78) * 2) * 160 * s; br = 13 * s; inFront = false; }
        } else {
          bx = b.x0 + (b.x1 - b.x0) * k; by = b.y0 + (b.y1 - b.y0) * k - Math.sin(k * Math.PI) * H * (0.24 + D() * 0.22); br = 18 - (18 - 13 * s) * k;
          if (G.mode === 'fb') { // after the arc: drop through, rattle in, or bounce away
            const t = G.t;
            if (b.r === 1) { by = b.y1 + Math.min(60, t * 160) * s; inFront = false; }
            else if (b.r > 0) { by = b.y1 - Math.abs(Math.sin(Math.min(t, 0.5) * 12)) * 18 * (1 - t) + (t > 0.5 ? (t - 0.5) * 120 * s : 0); inFront = t < 0.5; if (t > 0.5 && G.netT > 2) G.netT = 0; }
            else { bx = b.x1 + (b.ex >= 0 ? 1 : -1) * t * 120; by = b.y1 + (b.ed < -0.18 ? t * 200 : -Math.sin(Math.min(1, t * 2) * Math.PI) * 50 + t * 140); }
          }
        }
      }
      if (!inFront) ballAt(bx, by, br);
      if (dunkPos) { // the dunk: drawn between the back of the hoop and the front of the rim
        const d = dunkPos, p = d.ft > 0 ? (d.ft < 0.25 ? Object.assign(PZ.dunk(0.95), { by: 0 }) : Object.assign(PZ.victory('hoops', d.ft, me.L), { view: 'back' })) : Object.assign(PZ.dunk(d.k), { by: 0 });
        if (d.k < 0.78 && d.k > 0.1) { g.globalAlpha = 0.25; fig(me, d.x - (hx - sx) * 0.06, d.y + 14, d.sc, p); g.globalAlpha = 1; }
        fig(me, d.x, d.y, d.sc, p);
        if (me.L.gold && d.k < 0.8) for (let i = 0; i < 3; i++) FX.add('spark', d.x + rand(-8, 8), d.y - 20 * d.sc, 1, { col: '#ff922b', speed: 40, life: 0.4 });
      }
      hoop(hx, hy, s, true);
      if (inFront) ballAt(bx, by, br);
      if (!dunkPos) {
        let p;
        if (G.mode === 'aim') p = PZ.dribble(ev.rt);
        else if (G.mode === 'fly') p = PZ.jumpShot(clamp(G.t / 0.55, 0, 1));
        else p = G.res > 0 ? Object.assign(PZ.victory('hoops', G.t, me.L), { view: 'back' }) : Object.assign(PZ.sad(G.t), { view: 'back' });
        fig(me, sx, footY(), SC, p);
      }
    };
    G.ui = () => {
      const hy = hoopY(), s = hoopS();
      if (G.mode === 'aim') {
        // guide: how long a swipe this distance needs (Power shortens it)
        const L = Math.min(needLen(), H * 0.72), x0 = W * 0.9, y0 = ballY0();
        g.save(); g.setLineDash([6, 7]); g.strokeStyle = 'rgba(255,255,255,.75)'; g.lineWidth = 4;
        g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0, y0 - L); g.stroke(); g.restore();
        circle(x0, y0 - L, 9, '#ffe066'); circle(x0, y0, 5, '#fff');
        txt('SWIPE', x0, y0 + 20, 11, '#fff');
        txt('SWIPE UP!', W / 2, H * 0.975, 22 + Math.sin(ev.t * 8) * 2, '#fff');
        if (G.shot >= 2) txt('Moving hoop!', W / 2, hy + 58 * s, 14, '#ffe066');
        if (G.shot >= 3 && swayAmp(G.shot) > 4) txt('Tired arms: aim sways', W / 2, H * 0.67, 13, '#fff');
      }
      if (G.msgT > 0) txt(G.msg, W / 2, H * 0.6, 20, '#ffe066');
      for (let k = 0; k < 5; k++) dot(W * 0.08 + k * 30, H * 0.14 + 8, 11, G.shots[k] == null ? null : G.shots[k] === 1 ? 1 : G.shots[k] > 0 ? 0.5 : 0);
    };
    return G;
  };

  // ---------- SWIM: alternate left/right taps in a steady rhythm ----------
  // dive in with a splash, strokes with splashes, a turn at the far wall, touch the wall to finish
  GAMES.swim = (ev) => {
    const BEAT = 0.42, DUR = 7, M = ev.mod;
    // Stamina makes the rhythm windows more forgiving; Speed raises the top swim speed
    const PF = (0.2 * (0.75 + M.a * 0.6) * M.ef) / ev.diff, GD = (0.45 * (0.85 + M.a * 0.35) * (0.85 + 0.15 * M.ef)) / ev.diff;
    const VMAX = (1.3 + M.s * 1.0) * (0.8 + 0.2 * M.ef);
    const G = { t: 0, last: -1, side: null, taps: 0, q: 0, pace: BEAT * 2, speed: 0.3, prog: 0, arm: 0, idleMiss: false, done: false, sph: 0, diveT: -1, turned: false, touched: false };
    const py = () => H * 0.16, ph = () => H * 0.26;
    const lapX = () => { const p = G.prog < 0.5 ? G.prog * 2 : 2 - G.prog * 2; return W * 0.1 + p * W * 0.8; };
    function splash(x, y, n, big) { FX.add('splash', x, y, n, { ang: -Math.PI / 2, spread: 2.6, speed: big ? 170 : 110, size: big ? 3.4 : 2.4, life: 0.55 }); }
    G.down = (x) => {
      if (G.t >= DUR) return;
      const side = x < W / 2 ? 'L' : 'R';
      const now = G.t;
      G.taps++; G.arm = 1 - G.arm;
      if (G.diveT < 0) { G.diveT = 0; AT.sfx('whoosh'); }
      else splash(lapX() + (G.arm ? 10 : -10), py() + ph() / 2, 4);
      if (G.last < 0) { G.last = now; G.side = side; feedback('good', 'Go!', H * 0.48); G.q += 0.6; G.speed += 0.2; return; }
      const dt = now - G.last; G.last = now;
      G.pace += (dt - G.pace) * 0.5;
      if (side === G.side) { feedback('miss', 'Alternate sides!', H * 0.48); G.speed -= 0.25; G.side = side; return; }
      G.side = side;
      const err = (dt - BEAT) / BEAT;
      if (Math.abs(err) < PF) { feedback('perfect', '', H * 0.48); G.q += 1; G.speed += 0.22; }
      else if (Math.abs(err) < GD) { feedback('good', err < 0 ? 'A bit fast' : 'A bit slow', H * 0.48); G.q += 0.6; G.speed += 0.1; }
      else { feedback('miss', err < 0 ? 'Too fast!' : 'Too slow!', H * 0.48); G.speed -= 0.25; }
      G.idleMiss = false;
    };
    G.update = (dt) => {
      G.t += dt;
      G.speed = clamp(G.speed - dt * 0.18, 0.15, VMAX);
      if (G.last >= 0 && G.t - G.last > BEAT * 2.4 && !G.idleMiss && G.t < DUR) { G.idleMiss = true; feedback('miss', 'Too slow!', H * 0.48); G.pace = BEAT * 2.4; G.speed -= 0.3; }
      if (G.last < 0 && G.t > 2.2 && !G.idleMiss) { G.idleMiss = true; G.last = G.t - BEAT; if (G.diveT < 0) G.diveT = 0; }
      if (G.diveT >= 0) {
        const was = G.diveT; G.diveT += dt;
        if (was < 0.42 && G.diveT >= 0.42) { splash(W * 0.14, py() + ph() / 2, 14, true); AT.sfx('splash'); shake(3); }
      }
      if (G.diveT > 0.42) { G.prog = Math.min(1, G.prog + dt * G.speed * 0.11); G.sph += dt * (4 + G.speed * 5); }
      if (!G.turned && G.prog >= 0.5) { G.turned = true; G.turnT = 0; splash(W * 0.9, py() + ph() / 2, 12, true); FX.ring(W * 0.9, py() + ph() / 2, 22, '#e7f5ff'); AT.sfx('splash'); }
      if (G.turnT != null) G.turnT += dt;
      if (!G.touched && G.prog >= 1) { G.touched = true; G.touchT = 0; splash(W * 0.1, py() + ph() / 2, 14, true); FX.ring(W * 0.1, py() + ph() / 2, 30, '#fff'); ev.flash = 0.3; AT.sfx('splash'); cheer(1); }
      if (G.touchT != null) G.touchT += dt;
      if (G.t > DUR + 0.4) { G.done = true; G.skill = clamp(G.q / (DUR / BEAT - 1), 0, 1); }
    };
    G.draw = () => {
      g.fillStyle = '#a5d8ff'; g.fillRect(0, 0, W, H);
      const PY = py(), PH = ph();
      stands(PY - 6, '#2c3e66');
      g.fillStyle = '#1971c2'; g.fillRect(0, PY, W, PH);
      g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 2;
      for (let y = PY + 16; y < PY + PH; y += 26) { g.beginPath(); for (let x = 0; x < W; x += 8) g.lineTo(x, y + Math.sin(x / 14 + ev.t * 4) * 3); g.stroke(); }
      for (const y of [PY + 4, PY + PH - 4]) for (let x = 6; x < W; x += 16) circle(x, y, 4, (x / 16) % 4 < 1 ? '#fa5252' : '#fff');
      g.fillStyle = '#fff'; g.fillRect(W * 0.92, PY, 5, PH); g.fillRect(W * 0.08 - 5, PY, 5, PH);
      g.fillStyle = '#ced4da'; rr(g, W * 0.02, PY + PH / 2 - 14, W * 0.07, 28, 4); g.fill(); // starting block
      const me = meC(), sy = PY + PH / 2;
      if (G.diveT < 0) fig(me, W * 0.055, sy + 6, 1.2, Object.assign(PZ.crouch(1), { expr: 'focused' }));
      else if (G.diveT < 0.42) { // dive: arc from the block into the water
        const k = G.diveT / 0.42;
        fig(me, W * 0.055 + k * W * 0.09, sy + 6 - Math.sin(k * Math.PI) * 26 + k * 10, 1.2, { view: 'side', dir: 1, rot: 0.3 + k * 1.3, aL: [2.9, 0], aR: [2.9, 0], lL: [-0.2, 0], lR: [-0.2, 0], expr: 'focused' });
      } else {
        const back = G.prog >= 0.5, tt = G.turnT != null && G.turnT < 0.35 ? G.turnT / 0.35 : 1;
        const ang = (back ? -Math.PI / 2 : Math.PI / 2) + (G.turnT != null && G.turnT < 0.35 ? Math.PI * (1 - tt) : 0);
        const x = G.touched ? W * 0.1 + 10 : lapX();
        TN.swimmer(g, x, sy, 1.35, me.L, G.touched ? 0 : G.sph, ang, G.turnT != null && G.turnT < 0.2);
        if (G.touched) { circle(W * 0.08 + 4, sy - 6, 5, me.L.skin); }
      }
    };
    G.ui = () => {
      // beat guide: pulses at the target pace
      const bp = (ev.t % BEAT) / BEAT;
      circle(W / 2, H * 0.5, 16 + (1 - bp) * 10, 'rgba(255,255,255,' + (0.35 + (1 - bp) * 0.5) + ')');
      if (G.turnT != null && G.turnT < 0.9) txt('TURN!', W * 0.8, py() - 14, 20, '#fff');
      if (G.touchT != null && G.touchT < 1.2) txt('TOUCH!', W * 0.22, py() - 14, 22, '#ffe066');
      // rhythm meter: left = too slow, right = too fast
      const my = H * 0.6, mw = W * 0.84, mx = (W - mw) / 2;
      rr(g, mx - 4, my - 16, mw + 8, 32, 16); g.fillStyle = '#fff'; g.fill();
      const grd = g.createLinearGradient(mx, 0, mx + mw, 0);
      const zp = clamp(PF * 0.6, 0.02, 0.2), zg = clamp(GD * 0.6, zp + 0.02, 0.45); // green/yellow sized by Stamina
      grd.addColorStop(0, '#ff8787'); grd.addColorStop(0.5 - zg, '#ffe066'); grd.addColorStop(0.5 - zp, '#51cf66'); grd.addColorStop(0.5 + zp, '#51cf66'); grd.addColorStop(0.5 + zg, '#ffe066'); grd.addColorStop(1, '#ff8787');
      rr(g, mx, my - 12, mw, 24, 12); g.fillStyle = grd; g.fill();
      const n = clamp(0.5 + (BEAT / G.pace - 1) * 0.6, 0.03, 0.97);
      g.fillStyle = '#2b2d42'; rr(g, mx + mw * n - 4, my - 20, 8, 40, 4); g.fill();
      txt('SLOW', mx, my + 32, 13, '#1864ab', 'left', null); txt('FAST', mx + mw, my + 32, 13, '#1864ab', 'right', null);
      txt('RHYTHM', W / 2, my + 32, 13, '#1864ab', 'center', null);
      // tap pads
      const want = G.side === 'L' ? 'R' : G.side === 'R' ? 'L' : null;
      for (const [s, x] of [['L', W * 0.04], ['R', W * 0.52]]) {
        const on = want === s || !want, py2 = H * 0.7, pw = W * 0.44, phh = H * 0.24;
        rr(g, x, py2, pw, phh, 24); g.fillStyle = on ? 'rgba(255,255,255,' + (0.55 + 0.35 * (1 - bp)) + ')' : 'rgba(255,255,255,.25)'; g.fill();
        IC.draw(g, 'hand', x + pw / 2, py2 + phh / 2 - 10, 54);
        txt(s === 'L' ? 'LEFT' : 'RIGHT', x + pw / 2, py2 + phh - 22, 16, '#1864ab', 'center', null);
      }
      txt(`${Math.max(0, Math.ceil(DUR - G.t))}s`, W - 16, H * 0.1 + 20, 18, '#fff', 'right');
    };
    return G;
  };

  // ---------- BOXING: tap the lit targets, swipe down to dodge red ----------
  // the rival bounces on his feet, winds up hooks, snaps back when hit; a knockout plays in slow motion
  GAMES.boxing = (ev) => {
    const DUR = 8.5, M = ev.mod;
    // Speed: more time to tap each target. Power: damage per hit. Stamina: how many hits you can take.
    const HP = 2 + Math.round(M.a * 4), DMG = 7 + M.p * 12;
    const G = { t: 0, cur: null, gap: 0.6, pts: 0, n: 0, since: 0, punch: 0, dodge: 0, done: false, rhp: 100, hp: HP, dmg: [], hitT: 9, imp: null, koT: 0, downT: 0 };
    const spots = () => ({ head: [W / 2, H * 0.33, 40], left: [W * 0.27, H * 0.5, 36], right: [W * 0.73, H * 0.5, 36] });
    const win = Math.max(0.42, ((1.05 - ev.stars * 0.05) / ev.diff) * (0.8 + M.s * 0.6) * (0.75 + 0.25 * M.ef));
    const RIV = run.duel ? ev.comps[1] : ev.comps[1] || ev.comps[0];
    function spawn() {
      G.since++;
      if (G.since >= 3 && Math.random() < 0.6) { G.since = 0; G.cur = { atk: true, side: pick(['left', 'right']), t: 0, tele: 0.4 / ev.diff, win: 0.75 / ev.diff }; }
      else G.cur = { atk: false, at: pick(Object.keys(spots()).filter((k) => !G.cur || k !== G.cur.at)), t: 0, win };
    }
    function resolve(kind, sub) { G.n++; G.pts += kind === 'perfect' ? 1 : kind === 'good' ? 0.6 : 0; feedback(kind, sub, H * 0.68); G.cur = null; G.gap = rand(0.25, 0.45); }
    G.down = (x, y, key) => {
      const c = G.cur; if (!c || c.atk || G.koT || G.downT) return;
      const [sx, sy, r] = spots()[c.at];
      if (key || Math.hypot(x - sx, y - sy) < r * 1.45) {
        const perf = c.t < c.win * 0.45, d = Math.round(DMG * (perf ? 1.25 : 1));
        G.punch = 0.18; G.px = sx; G.py = sy; G.hook = c.at !== 'head'; AT.sfx('punch');
        G.rhp = Math.max(0, G.rhp - d); G.dmg.push({ x: sx, y: sy - r, d, t: 0 });
        G.hitT = 0; G.hitSide = c.at === 'left' ? -1 : c.at === 'right' ? 1 : 0; G.imp = { x: sx, y: sy, t: 0, big: perf };
        FX.add('spark', sx, sy, perf ? 12 : 7, { speed: 200, life: 0.35 }); shake(perf ? 6 : 4);
        resolve(perf ? 'perfect' : 'good', `−${d}`);
      }
    };
    G.up = (x, y, dx, dy) => {
      const c = G.cur; if (!c || !c.atk) return;
      if (dy > 35 && Math.abs(dy) > Math.abs(dx)) {
        G.dodge = 0.35; AT.sfx('whoosh');
        if (c.t >= c.tele) resolve('perfect', 'Dodged!'); else resolve('good', 'Early dodge');
      }
    };
    G.update = (dt) => {
      G.t += dt; G.punch -= dt; G.dodge -= dt; G.hitT += dt;
      if (G.imp) { G.imp.t += dt; if (G.imp.t > 0.3) G.imp = null; }
      for (const f of G.dmg) f.t += dt;
      G.dmg = G.dmg.filter((f) => f.t < 0.8);
      // knockout: slow motion while the rival goes down with stars around his head
      if (G.rhp <= 0 && !G.koT) { G.koT = 1e-4; G.cur = null; feedback('perfect', 'KNOCKOUT!', H * 0.68); AT.sfx('ko'); shake(12); cheer(1); camTo(W / 2, H * 0.45, 1.25, 3); }
      if (G.koT) { G.koT += dt; ev.tsT = 0.3; if (G.koT < 0.62) return; }
      if (G.hp <= 0 && !G.downT) { G.downT = 1e-4; G.cur = null; shake(9); }
      if (G.downT) { G.downT += dt; if (G.downT < 0.9) return; }
      if (G.cur) {
        const c = G.cur; c.t += dt;
        if (!c.atk && c.t > c.win) resolve('miss', 'Too slow!');
        else if (c.atk && c.t > c.tele + c.win) { G.hp--; resolve('miss', G.hp > 0 ? 'Got hit!' : 'Knocked down!'); G.shake = 0.3; shake(8); AT.sfx('punch'); }
      } else if (G.t < DUR && !G.koT) { G.gap -= dt; if (G.gap <= 0) spawn(); }
      G.shake = Math.max(0, (G.shake || 0) - dt);
      // the round ends on time, on a knockout, or when you run out of hits you can take
      const ko = G.rhp <= 0, down = G.hp <= 0;
      if (!G.done && ((G.t > DUR && !G.cur) || ko || down)) {
        G.done = true; G.cur = null;
        const acc = G.n ? G.pts / G.n : 0;
        G.skill = clamp(0.4 * acc + 0.6 * (1 - G.rhp / 100), 0, 1);
        if (ko) G.skill = Math.max(G.skill, 0.92);
        if (down) G.skill *= 0.6;
        if (G.koT) camHome(3);
      }
    };
    G.draw = () => {
      // ring with the crowd behind the ropes
      g.fillStyle = '#ffc9c9'; g.fillRect(0, 0, W, H);
      stands(H * 0.34, '#5c3a4a');
      g.fillStyle = '#4dabf7'; g.fillRect(0, H * 0.66, W, H * 0.34);
      g.save();
      const off = G.dodge > 0 ? Math.sin((G.dodge / 0.35) * Math.PI) * 26 : 0;
      g.translate(G.shake ? rand(-6, 6) : 0, -off);
      const sp = spots(), c = G.cur;
      // the rival boxer (big, facing you)
      let pose;
      if (G.koT) pose = Object.assign(PZ.ko(G.koT / 0.6), { stars: ev.rt * 4 });
      else if (G.hitT < 0.35) { pose = PZ.hit(G.hitT / 0.35); pose.bx = (G.hitSide || 0) * -6 * (1 - G.hitT / 0.35); pose.rot = (G.hitSide || 0) * 0.15 * (1 - G.hitT / 0.35) - (G.hitSide ? 0 : 0.12 * (1 - G.hitT / 0.35)); }
      else if (c && c.atk) { const sd = c.side === 'left' ? -1 : 1; pose = c.t < c.tele ? PZ.hook(0.12 + (c.t / c.tele) * 0.1, sd) : PZ.hook(0.25 + clamp((c.t - c.tele) / c.win, 0, 1) * 0.3, sd); pose.lean = -sd * 0.18; }
      else if (G.rhp < 30) pose = Math.sin(ev.rt * 1.3) > 0.4 ? PZ.stumble(ev.rt) : PZ.guard(ev.rt, 0.6);
      else pose = PZ.guard(ev.rt, 1);
      fig(RIV, W / 2, H * 0.64, H * 0.0072, pose);
      if (G.imp) TN.impact(g, G.imp.x, G.imp.y, G.imp.big ? 46 : 34, G.imp.t / 0.3);
      for (const s of ['left', 'right']) {
        const [x, y] = sp[s];
        if (c && c.atk && c.side === s) {
          const flash = Math.floor(c.t * 14) % 2;
          let col = '#ff2222', r = 30;
          if (c.t < c.tele) col = flash ? '#ff2222' : '#fff';
          else r = 30 + Math.min(1, (c.t - c.tele) / c.win) * 26;
          circle(x, y, r + 22 + flash * 6, 'rgba(255,0,0,.28)');
          circle(x, y, r + 4, '#2b2d42'); circle(x, y, r, col);
          txt('!', x, y - r - 30, 34, '#ff2222', 'center', '#fff');
        }
      }
      // lit target
      if (c && !c.atk) {
        const [x, y, r] = sp[c.at], k = 1 - c.t / c.win;
        circle(x, y, r + 10, 'rgba(255,224,102,.55)');
        g.strokeStyle = '#ffd43b'; g.lineWidth = 6; g.beginPath(); g.arc(x, y, r + 12, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2); g.stroke();
        IC.draw(g, 'target', x, y, r * 1.7);
      }
      g.restore();
    };
    G.ui = () => {
      const c = G.cur;
      if (c && c.atk) { IC.draw(g, 'swipe', W / 2, H * 0.8 + Math.sin(ev.t * 12) * 6, 54); txt('SWIPE DOWN!', W / 2, H * 0.9, 24, '#fff'); }
      if (G.dodge > 0) { g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 3; for (const sd of [-1, 1]) for (let i = 0; i < 3; i++) { const x = W / 2 + sd * (W * 0.32 + i * 10); g.beginPath(); g.moveTo(x, H * 0.3 + i * 30); g.lineTo(x, H * 0.45 + i * 30); g.stroke(); } }
      // your gloves: straight jab to the head, hooks curve in from the side
      for (const s of [-1, 1]) {
        let x = W / 2 + s * W * 0.3, y = H * 0.9 + Math.abs(Math.sin(ev.rt * 5 + s)) * 5, sz = 70;
        if (G.punch > 0 && s === (G.px <= W / 2 ? -1 : 1)) {
          const k = Math.sin((G.punch / 0.18) * Math.PI / 2), x0 = x, y0 = y;
          x = x0 + (G.px - x0) * k + (G.hook ? Math.sin(k * Math.PI) * s * 50 : 0); y = y0 + (G.py - y0) * k; sz = 70 - k * 18;
          g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 4; g.beginPath(); g.moveTo(x0, y0); g.quadraticCurveTo(x0 + (G.hook ? s * 60 : 0), (y0 + y) / 2, x, y); g.stroke();
        }
        IC.draw(g, 'glove', x, y, sz);
      }
      if (G.downT) { g.fillStyle = `rgba(20,0,0,${Math.min(0.45, G.downT)})`; g.fillRect(0, 0, W, H); for (let i = 0; i < 5; i++) TN.star(g, W / 2 + Math.cos(ev.rt * 3 + i * 1.26) * 60, H * 0.4 + Math.sin(ev.rt * 3 + i * 1.26) * 18, 10, '#ffd43b'); txt('DOWN!', W / 2, H * 0.5, 40, '#ff6b6b', 'center', '#fff'); }
      txt(`${Math.max(0, Math.ceil(DUR - G.t))}s`, W - 16, H * 0.1 + 20, 18, '#fff', 'right');
      // rival health (your Power) and the hits you can still take (your Stamina)
      const hy = H * 0.15;
      rr(g, W * 0.52, hy - 9, W * 0.44, 18, 9); g.fillStyle = 'rgba(0,0,0,.3)'; g.fill();
      rr(g, W * 0.52, hy - 9, W * 0.44 * (G.rhp / 100), 18, 9); g.fillStyle = G.rhp > 30 ? '#ff6b6b' : '#fa5252'; g.fill();
      txt('RIVAL', W * 0.74, hy, 12, '#fff');
      for (let k = 0; k < HP; k++) IC.draw(g, 'heart', 22 + k * 24, hy, 22, k < G.hp ? null : 'rgba(255,255,255,.35)');
      for (const f of G.dmg) txt(`-${f.d}`, f.x + 30, f.y - f.t * 50, 26, '#fff', 'center', '#c92a2a');
    };
    return G;
  };

  // ---------- LIFT: hold to fill the power bar, release in the green ----------
  // chalk the hands, grab the bar, shake under the weight, lock it out overhead while the crowd stands up
  GAMES.lift = (ev) => {
    const M = ev.mod;
    const G = { att: 0, res: [], mode: 'ready', t: 0, p: 0, hold: false, done: false, chalkT: 0 };
    // Power: the bar fills slower and wobbles less. Stamina: a wider green zone.
    const fill = (1.25 - M.p * 0.5) * (1 + (1 - M.ef) * 0.4), wob = (1 - M.p) * 0.035;
    const val = () => clamp(G.p + Math.sin(G.t * 11) * wob * Math.min(1, G.p * 3), 0, 1);
    const cx = () => W * 0.4, base = () => H * 0.7, S = () => H * 0.0034;
    function newAtt() { G.lo = rand(0.5, 0.8); G.w = (0.085 + ev.stars * 0.012) * (0.8 + M.a * 0.6) * (0.85 + 0.15 * M.ef); G.lo = Math.min(G.lo, 0.93 - G.w); G.p = 0; G.mode = 'ready'; G.t = 0; G.hold = false; }
    newAtt();
    function finish(r, sub) {
      G.res.push(r); feedback(r === 1 ? 'perfect' : r > 0 ? 'good' : 'miss', sub, H * 0.3); G.mode = 'fb'; G.t = 0; G.hold = false;
      if (r > 0) { cheer(1); shake(4); ev.flash = 0.18; FX.add('chalk', cx(), base() - 60 * S(), 8, { speed: 60, size: 4 }); }
      else { shake(7); AT.sfx('thud'); FX.add('dust', cx(), base(), 12, { ang: -Math.PI / 2, spread: 3, speed: 120, size: 4 }); }
    }
    G.down = () => { if (G.mode === 'ready') { G.mode = 'hold'; G.hold = true; G.t = 0; } };
    G.up = () => {
      if (G.mode !== 'hold') return;
      const p = val(), mid = G.lo + G.w / 2;
      if (p >= G.lo && p <= G.lo + G.w) finish(Math.abs(p - mid) < G.w * 0.22 ? 1 : 0.6, 'Lifted!');
      else if (p < G.lo) finish(0, 'Not enough power');
      else finish(0, 'Too late!');
    };
    G.update = (dt) => {
      G.t += dt; G.chalkT -= dt;
      if (G.mode === 'ready' && G.t < 1 && G.chalkT <= 0) { G.chalkT = 0.22; FX.add('chalk', cx(), base() - 32 * S(), 3, { speed: 40, size: 3, life: 0.6 }); }
      if (G.mode === 'ready' && G.t > 3) finish(0, 'Hold to lift!');
      if (G.mode === 'hold') {
        G.p += dt * (0.32 + G.p * 0.95) * ev.diff * fill;
        if (G.p > 0.6 && Math.random() < dt * 4) FX.add('sweat', cx() + rand(-12, 12), base() - 58 * S(), 1, { ang: -Math.PI / 2, spread: 2, speed: 60, size: 3 });
        if (G.p >= 1) { G.p = 1; finish(0, 'Lift failed!'); }
      }
      if (G.mode === 'fb' && G.t > 0.9) {
        G.att++;
        if (G.att >= 3) { G.done = true; G.skill = G.res.reduce((a, b) => a + b, 0) / 3; } else newAtt();
      }
    };
    G.draw = () => {
      g.fillStyle = '#9775fa'; g.fillRect(0, 0, W, H);
      stands(H * 0.36, '#4b3a8c');
      g.fillStyle = '#5f3dc4'; g.fillRect(0, H * 0.7, W, H * 0.3);
      g.fillStyle = '#7048e8'; rr(g, W * 0.12, H * 0.69, W * 0.56, 12, 4); g.fill(); // platform
      const last = G.res[G.res.length - 1], s = S();
      const ok = G.mode === 'fb' && last > 0, fail = G.mode === 'fb' && !(last > 0);
      let pose, k;
      if (G.mode === 'ready') { pose = G.t < 1 ? PZ.chalk(ev.rt) : PZ.grab(); k = -0.15; }
      else if (G.mode === 'hold') { k = G.p; pose = PZ.strain(ev.rt, G.p); }
      else if (ok) { pose = PZ.lockout(ev.rt); k = 1.05; }
      else { pose = PZ.fallSit(); k = -0.5; }
      fig(meC(), cx(), base(), s, pose);
      // barbell follows the hands; it crashes down on a failed lift
      const by = fail ? base() - 6 * s : base() - (18 + Math.max(0, k) * 40) * s + (G.mode === 'hold' && G.p > 0.7 ? Math.sin(ev.t * 50) * 3 : 0);
      if (!(G.mode === 'ready' && G.t < 1)) {
        g.strokeStyle = '#dee2e6'; g.lineWidth = 6; g.lineCap = 'round'; g.beginPath(); g.moveTo(cx() - 72, by); g.lineTo(cx() + 72, by); g.stroke();
        for (const sd of [-1, 1]) { rr(g, cx() + sd * 62 - 8, by - 26, 16, 52, 5); g.fillStyle = '#2b2d42'; g.fill(); rr(g, cx() + sd * 76 - 6, by - 18, 12, 36, 4); g.fill(); }
      } else { g.strokeStyle = '#dee2e6'; g.lineWidth = 6; g.beginPath(); g.moveTo(cx() - 72, base() - 6); g.lineTo(cx() + 72, base() - 6); g.stroke(); for (const sd of [-1, 1]) { rr(g, cx() + sd * 62 - 8, base() - 32, 16, 52, 5); g.fillStyle = '#2b2d42'; g.fill(); } }
    };
    G.ui = () => {
      const bx = W * 0.82, top = H * 0.2, bh = H * 0.48, bw = 38;
      rr(g, bx - 5, top - 5, bw + 10, bh + 10, 20); g.fillStyle = '#fff'; g.fill();
      rr(g, bx, top, bw, bh, 16); g.fillStyle = '#e9ecef'; g.fill();
      g.save(); rr(g, bx, top, bw, bh, 16); g.clip();
      g.fillStyle = 'rgba(255,107,107,.45)'; g.fillRect(bx, top, bw, bh * (1 - G.lo - G.w));
      const pv = G.mode === 'hold' ? val() : G.p;
      g.fillStyle = 'rgba(255,212,59,.9)'; g.fillRect(bx, top + bh * (1 - pv), bw, bh * pv);
      g.fillStyle = 'rgba(64,192,87,.8)'; g.fillRect(bx, top + bh * (1 - G.lo - G.w), bw, bh * G.w);
      g.restore();
      // green zone stays visible on top of the fill, with brackets past the bar edges
      g.fillStyle = '#2f9e44';
      for (const yy of [top + bh * (1 - G.lo - G.w), top + bh * (1 - G.lo)]) { rr(g, bx - 10, yy - 3, bw + 20, 6, 3); g.fill(); }
      g.fillStyle = '#2b2d42'; g.fillRect(bx - 8, top + bh * (1 - pv) - 3, bw + 16, 6);
      IC.draw(g, 'dumbbell', bx + bw / 2, top + bh + 30, 34);
      for (let k = 0; k < 3; k++) dot(W / 2 + (k - 1) * 34, H * 0.84, 13, G.res[k]);
      if (G.mode === 'ready') txt('HOLD!', W / 2, H * 0.92, 30 + Math.sin(ev.t * 10) * 3, '#fff');
      else if (G.mode === 'hold') txt('…release in the green', W / 2, H * 0.92, 18, '#fff');
    };
    return G;
  };

  // ======================================================================
  // RESOLVE: the athlete's stars give a base, the player's skill decides a lot
  // ======================================================================
  function resolveEvent() {
    const gear = AT.S().wallet.GOLD_GEAR || 0;
    const skill = clamp(ev.game.skill || 0, 0, 1);
    ev.skill = skill;
    for (const c of ev.comps) {
      // your athlete: stars + Speed/Power/Stamina + how well you played; rivals: stars + a random edge that grows per league
      c.power = c.j === 0
        ? (AT.athPower(ev.m) + skill * 30 + rand(0, 4) + gear * 0.8) * (0.85 + 0.15 * ev.mod.ef)
        : run.easy ? AT.powerOf(1) * 0.7 + rand(0, 8) : AT.powerOf(c.stars) * 0.85 + rand(5, 20 + run.lvl * 1.5) + run.lvl * 1.2;
    }
    const kind = ev.E.kind;
    let order;
    if (kind === 'pen' || kind === 'hoop') {
      // the player's real shots; rivals score by their strength
      for (const c of ev.comps) {
        if (c.j === 0) { c.shots = ev.game.shots.map((s) => (s > 0 ? 1 : 0)); c.goals = ev.game.goals; continue; }
        const p = clamp(0.3 + (AT.powerOf(c.stars) - 10) / 110 + rand(-0.08, 0.08), 0.2, 0.92);
        c.shots = [0, 0, 0, 0, 0].map(() => (Math.random() < p ? 1 : 0));
        c.goals = c.shots.reduce((a, b) => a + b, 0);
      }
      order = ev.comps.slice().sort((a, b) => b.goals - a.goals || b.power - a.power);
    } else order = ev.comps.slice().sort((a, b) => b.power - a.power);
    order.forEach((c, i) => (c.rank = i));
    const top = Math.max(...ev.comps.map((c) => c.power));
    ev.dur = 3.6;
    if (kind === 'race') {
      for (const c of ev.comps) c.T = 2.8 * Math.pow(order[0].power / c.power, 1.7);
      // keep finishing order identical to the ranking
      order.forEach((c, i) => { if (i > 0) c.T = Math.max(c.T, order[i - 1].T + 0.06); });
      ev.dur = Math.min(5.4, Math.max(...ev.comps.map((c) => c.T)) + 0.5) + 0.35; // + the crouched start
    } else if (kind === 'lift') {
      order.forEach((c, i) => { c.kg = Math.round(c.power * 2.5 + 20); if (i > 0) c.kg = Math.min(c.kg, order[i - 1].kg - 2); });
      ev.dur = 3.9;
    } else if (kind === 'box') {
      order.forEach((c, i) => { c.score = Math.round(c.power * 9); if (i > 0) c.score = Math.min(c.score, order[i - 1].score - 5); c.frac = clamp(c.power / top, 0.2, 1); });
    } else ev.dur = 3.8;
    for (const c of ev.comps) { run.totals[c.j] += EVENT_PTS[c.rank]; run.pow[c.j] += c.power; }
    run.log.push({ type: ev.type, rank: ev.comps[0].rank, skill });
    if (ev.comps[0].rank === 0) AT.task('win', 1, run.sport);
  }

  function nextEvent() {
    run.idx++;
    if (run.idx < run.members.length) startEvent();
    else finish();
  }

  T.update = function (dt) {
    if (!ev) {
      // results screen: if it was dismissed without collecting, finish up anyway
      if (pendingCollect && !AT.modalOpen()) pendingCollect();
      else if (!pendingCollect && !AT.modalOpen()) T.abort();
      return;
    }
    try { step(dt); } catch (err) { console.error(err); T.abort(); AT.toast('Back to the academy!'); }
  };
  function step(dt) {
    perfTick(dt);
    const sdt = dt * ev.ts; // slow motion scales the scene, never the menus
    ev.tsT = 1; ev.letterboxT = 0;
    ev.t += ev.phase === 'play' || ev.phase === 'action' ? sdt : dt;
    ev.rt += sdt; ev.fbT += dt; ev.fade += dt; ev.flash = Math.max(0, ev.flash - dt);
    switch (ev.phase) {
      case 'swoop': if (ev.t > 1.9) setPhase('intro'); break;
      case 'intro': if (ev.t > 4.5) setPhase('count'); break; // time to read the stats
      case 'count': {
        const i = Math.floor(ev.t / 0.6);
        if (i !== ev.ci) { ev.ci = i; AT.sfx(i < 3 ? 'count' : 'go'); }
        if (ev.t >= 1.8) { setPhase('play'); ev.goT = 0; AT.sfx('go'); cheer(0.9); }
        break;
      }
      case 'play':
        ev.goT += dt;
        ev.game.update(sdt);
        if (ev.game.done || ev.t > 60) {
          if (!ev.game.done) ev.game.skill = ev.game.skill || 0;
          if (ev.game.goals == null) ev.game.goals = (ev.game.shots || []).filter((s) => s > 0).length;
          if (!ev.game.shots) ev.game.shots = [];
          resolveEvent(); setPhase('action'); AT.sfx('whistle'); ev.marks = {};
        }
        break;
      case 'action':
        actionUpdate();
        if (ev.E.kind === 'box' && ev.t > 2.4 && !ev.pow) { ev.pow = true; AT.sfx('punch'); shake(8); cheer(1); }
        if (ev.t > ev.dur) {
          setPhase('result');
          const r = ev.comps[0].rank;
          AT.sfx(r === 0 ? 'win' : r < 2 ? 'level' : 'lose');
          if (r === 0) { AT.sfx('crowd'); cheer(1); FX.add('confetti', W / 2, H * 0.3, 40, { speed: 220, life: 2.2, size: 4 }); }
        }
        break;
      case 'result': if (ev.t > 2.2) setPhase('podium'); break;
      case 'podium': podiumUpdate(); if (ev.t > 4.2) nextEvent(); break;
    }
    if (!ev) return;
    ev.ts += (ev.tsT - ev.ts) * Math.min(1, dt * 9);
    ev.letterbox += ((ev.letterboxT || 0) - ev.letterbox) * Math.min(1, dt * 8);
    ev.excite += (ev.exT - ev.excite) * Math.min(1, dt * 4); ev.exT = Math.max(0.3, ev.exT - dt * 0.3);
    camUpdate(dt); FX.update(sdt);
    draw();
  }
  // scripted moments of the result scene: camera, slow motion, crowd, effects
  function actionUpdate() {
    const k = ev.E.kind, t = ev.t, mk = ev.marks;
    if (k === 'race') {
      const lead = ev.comps.reduce((a, c) => Math.min(a, c.T), 99), p = clamp((t - 0.35) / lead, 0, 1);
      if (!mk.go && t > 0.35) { mk.go = 1; AT.sfx(ev.E.swim ? 'whoosh' : 'go'); shake(2); }
      if (!ev.E.swim) camTo(W / 2, H * (0.62 - p * 0.3), 1.18, 3);
      if (p > 0.86 && p < 1) { ev.tsT = 0.3; ev.letterboxT = 0.6; cheer(1); }
      if (p >= 1 && !mk.fin) { mk.fin = 1; ev.flash = 0.25; AT.sfx('tap'); camHome(3); }
    } else if (k === 'lift') {
      if (!mk.up && t > 2.5) { mk.up = 1; cheer(1); shake(3); ev.flash = 0.15; AT.sfx('crowd'); }
    }
  }

  // ======================================================================
  // DRAWING
  // ======================================================================
  function txt(s, x, y, size, col = '#fff', align = 'center', stroke = 'rgba(0,0,0,.35)') {
    g.font = `900 ${size}px ${FONT}`; g.textAlign = align; g.textBaseline = 'middle';
    if (stroke) { g.lineWidth = Math.max(3, size / 6); g.strokeStyle = stroke; g.lineJoin = 'round'; g.strokeText(s, x, y); }
    g.fillStyle = col; g.fillText(s, x, y);
  }
  function circle(x, y, r, col) { g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fillStyle = col; g.fill(); }
  function dot(x, y, r, res) {
    circle(x, y, r + 3, '#fff');
    circle(x, y, r, res == null ? '#dee2e6' : res === 1 ? '#40c057' : res > 0 ? '#fab005' : '#fa5252');
    if (res != null) IC.draw(g, res > 0 ? 'check' : 'cross', x, y, r * 1.5);
  }
  function badge(c, x, y, r) {
    circle(x, y + 2, r, 'rgba(0,0,0,.2)'); circle(x, y, r, c.a.color);
    g.lineWidth = 3; g.strokeStyle = '#fff'; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.stroke();
    IC.draw(g, c.a.logo, x, y, r * 1.35);
  }
  function medal(rank, x, y, size) {
    if (rank < 3) { IC.draw(g, MEDALS[rank], x, y, size); return; }
    circle(x, y, size * 0.36, '#adb5bd'); txt('4', x, y + 1, size * 0.42, '#fff', 'center', null);
  }
  function stars(x, y, n, size) { for (let i = 0; i < 5; i++) IC.draw(g, 'star', x + (i - 2) * size * 0.95, y, size, i < n ? null : 'rgba(255,255,255,.35)'); }
  function header() {
    const grd = g.createLinearGradient(0, 0, 0, 96);
    grd.addColorStop(0, 'rgba(0,0,0,.45)'); grd.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grd; g.fillRect(0, 0, W, 96);
    txt(run.duel ? 'VS' : `${run.idx + 1}/${run.members.length}`, 14, 26, 16, '#fff', 'left');
    if (run.duel) { badge(ev.comps[1], W - 26, 28, 15); txt(run.duel.name, W - 26, 52, 12, '#ffe066'); }
    // the title shrinks to fit between the corner labels on narrow screens
    g.font = `900 26px ${FONT}`;
    const tw0 = g.measureText(ev.E.name).width, room = W - (run.duel ? 120 : 84);
    txt(ev.E.name, W / 2, 28, Math.max(15, Math.min(26, (26 * room) / tw0)));
    g.font = `900 17px ${FONT}`;
    const nm = ev.m.name, tw = g.measureText(nm).width;
    IC.draw(g, ZONES[ev.m.zone].icon, W / 2 - tw / 2 - 16, 56, 22);
    txt(nm, W / 2 + 4, 56, 17, '#ffe066');
    stars(W / 2, 80, ev.stars, 17);
  }

  const nLanes = () => ev.comps.length;
  function laneX(j) { return W * (0.1 + ((j + 0.5) * 0.8) / nLanes()); }
  const endPose = (c, t) => (c.rank === 0 ? PZ.victory(ev.sport, t, c.L) : PZ.react(c.rank, t + c.j));

  // RACE: crouched start, explosive first steps, pumping arms, slow motion at the line, chest lean.
  // SWIM: dive with a splash, strokes, a turn at the far wall, touch the wall to finish.
  function drawRace() {
    const E = ev.E, swim = !!E.swim;
    g.fillStyle = E.top; g.fillRect(0, 0, W, H);
    const y0 = H * 0.8, y1 = H * 0.24, lw = (W * 0.72) / nLanes();
    TN.crowd(g, 0, 0, W, y1 - 46, ev.rt, ev.excite, Q.dens, flagCols(), swim ? '#2c3e66' : null);
    g.fillStyle = E.lane; g.fillRect(W * 0.1, y1 - 40, W * 0.8, y0 - y1 + 90);
    g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 3;
    for (let j = 0; j <= nLanes(); j++) { const x = W * 0.1 + (j * W * 0.8) / nLanes(); g.beginPath(); g.moveTo(x, y1 - 40); g.lineTo(x, y0 + 50); g.stroke(); }
    if (swim) {
      for (let j = 1; j < nLanes(); j++) for (let y = y1 - 30; y < y0 + 40; y += 14) circle(W * 0.1 + (j * W * 0.8) / nLanes(), y, 3.5, (y / 14) % 4 < 1 ? '#fa5252' : '#fff');
      g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 2;
      for (let y = y1; y < y0; y += 34) { g.beginPath(); for (let x = W * 0.1; x < W * 0.9; x += 8) g.lineTo(x, y + Math.sin(x / 12 + ev.rt * 4) * 3); g.stroke(); }
      g.fillStyle = '#e9ecef'; g.fillRect(W * 0.1, y0 + 30, W * 0.8, 10); g.fillRect(W * 0.1, y1 - 40, W * 0.8, 8); // walls
    } else for (let i = 0; i < 20; i++) for (let r = 0; r < 2; r++) { g.fillStyle = (i + r) % 2 ? '#212529' : '#fff'; g.fillRect(W * 0.1 + i * W * 0.04, y1 - 8 + r * 8, W * 0.04, 8); }
    if (!swim) { g.fillStyle = 'rgba(255,255,255,.9)'; g.fillRect(W * 0.1, y0 + 18, W * 0.8, 4); }
    const res = ev.phase === 'result', at = res ? 99 : ev.t - 0.35;
    ev.comps.forEach((c) => {
      const x = laneX(c.j);
      if (c.j === 0) { g.fillStyle = 'rgba(255,224,102,.28)'; g.fillRect(x - lw / 2, y1 - 40, lw, y0 - y1 + 90); }
      const p = clamp(at / c.T, 0, 1);
      if (swim) {
        const pp = p < 0.5 ? p * 2 : 2 - p * 2, ease = pp;
        const y = y0 + 20 - (y0 + 20 - y1) * ease;
        if (res) fig(c, x, y0 + 26, 0.95, endPose(c, ev.rt));
        else if (at < 0) fig(c, x, y0 + 40, 0.95, PZ.block());
        else if (at < 0.3) { const k = at / 0.3; fig(c, x, y0 + 40 - Math.sin(k * Math.PI) * 30 - k * 20, 0.95, Object.assign(PZ.block(), { by: 0, rot: k * 0.9, aL: [2.9, 0], aR: [2.9, 0] })); }
        else {
          if (!ev.marks['in' + c.j]) { ev.marks['in' + c.j] = 1; FX.add('splash', x, y0, 10, { ang: -Math.PI / 2, spread: 2.4, speed: 140, size: 3 }); AT.sfx('splash'); }
          if (p >= 0.5 && !ev.marks['tn' + c.j]) { ev.marks['tn' + c.j] = 1; FX.add('splash', x, y1 - 20, 8, { ang: Math.PI / 2, spread: 2.4, speed: 110, size: 2.6 }); }
          if (p >= 1 && !ev.marks['to' + c.j]) { ev.marks['to' + c.j] = 1; FX.add('splash', x, y0 + 28, 10, { ang: -Math.PI / 2, spread: 2.6, speed: 150, size: 3 }); FX.ring(x, y0 + 26, 18, '#fff'); }
          TN.swimmer(g, x, p >= 1 ? y0 + 22 : y, 1.0, c.L, p >= 1 ? 0 : ev.rt * 9 + c.j, p < 0.5 ? 0 : Math.PI);
        }
      } else {
        const ease = p < 1 ? p * p * (1.6 - 0.6 * p) : 1;
        const y = y0 - (y0 - y1) * ease, s = 1.05 - ease * 0.25;
        let pose;
        if (res) pose = endPose(c, ev.rt);
        else if (at < 0) pose = PZ.crouchBack();
        else if (p < 1) {
          pose = PZ.runBack(ev.rt * 17 + c.j * 1.3, at < 0.45 ? 1.3 : 1.05);
          if (at < 0.45) pose.by += 3; // explosive, low first steps
          if (p > 0.94) { pose.by += 3; pose.aL = [0.9, 0, 0]; pose.aR = [0.9, 0, 0]; pose.head = 0.3; } // chest lean on the line
          if (at > 0 && !ev.marks['d' + c.j]) { ev.marks['d' + c.j] = 1; FX.add('dust', x, y0 + 4, 7, { ang: Math.PI / 2, spread: 2.2, speed: 70, size: 4 }); }
        } else pose = Object.assign(PZ.stand(ev.rt), { view: 'back', expr: 'smile' });
        fig(c, x, y, s, pose);
      }
      badge(c, x, y0 + 52 + (swim ? 6 : 0), 15);
      if (c.j === 0) txt('YOU', x, y0 + 80, 13, '#fff');
      if (res) medal(c.rank, x, y1 - 26, 34);
    });
    if (!res && ev.t < 0.35 && !swim) txt('SET…', W / 2, H * 0.5, 34, '#fff');
  }

  // LIFT: chalk, grab the bar, shake under the weight, triumphant lockout; the crowd stands up
  function drawLift() {
    g.fillStyle = '#9775fa'; g.fillRect(0, 0, W, H);
    TN.crowd(g, 0, H * 0.06, W, H * 0.16, ev.rt, ev.excite, Q.dens, flagCols(), '#4b3a8c');
    g.fillStyle = '#5f3dc4'; g.fillRect(0, H * 0.72, W, H * 0.28);
    const res = ev.phase === 'result', t = res ? 99 : ev.t;
    ev.comps.forEach((c) => {
      const x = laneX(c.j), base = H * 0.7, s = 1.05;
      if (c.j === 0) { g.fillStyle = 'rgba(255,224,102,.25)'; g.fillRect(x - W * 0.36 / nLanes(), H * 0.2, W * 0.72 / nLanes(), H * 0.6); }
      const up = clamp((t - 1.0) / (1.4 + c.rank * 0.12), 0, 1);
      const kg = c.kg ? Math.round(c.kg * clamp((t - 0.6) / 1.9, 0, 1)) : 0;
      let pose, k;
      if (res) { pose = endPose(c, ev.rt + c.j); k = c.rank === 0 ? -1 : 1.05; }
      else if (t < 0.6) { pose = PZ.chalk(ev.rt + c.j); k = -1; if (Math.random() < 0.08) FX.add('chalk', x, base - 30, 1, { speed: 30, size: 2.5 }); }
      else if (t < 1.0) { pose = PZ.grab(); k = 0; }
      else if (up < 1) { pose = PZ.strain(ev.rt + c.j, up); k = up; }
      else { pose = PZ.lockout(ev.rt + c.j); k = 1.05; }
      fig(c, x, base, s, pose);
      if (k >= 0) {
        const by = base - (18 + k * 40) * s + (up > 0.2 && up < 1 ? Math.sin(ev.rt * 40 + c.j) * 1.5 : 0);
        g.strokeStyle = '#ced4da'; g.lineWidth = 4; g.lineCap = 'round'; g.beginPath(); g.moveTo(x - 30, by); g.lineTo(x + 30, by); g.stroke();
        const pr = c.kg ? 7 + Math.min(12, c.kg / 12) : 9;
        for (const sd of [-1, 1]) { rr(g, x + sd * 26 - 4, by - pr, 8, pr * 2, 3); g.fillStyle = '#212529'; g.fill(); }
      } else if (k === -1 && !res) { g.strokeStyle = '#ced4da'; g.lineWidth = 4; g.beginPath(); g.moveTo(x - 30, base - 4); g.lineTo(x + 30, base - 4); g.stroke(); }
      txt(kg ? String(kg) : '—', x, H * 0.265, 19, '#fff'); if (kg) txt('kg', x, H * 0.265 + 18, 12, '#e5dbff', 'center', null);
      badge(c, x, H * 0.79, 15);
      if (c.j === 0) txt('YOU', x, H * 0.84, 13);
      if (res) medal(c.rank, x, H * 0.33, 36);
    });
  }

  // BOX: jabs and hooks into the bag with impact flashes; the strongest punch rings the meter
  function drawBox() {
    g.fillStyle = '#ffc9c9'; g.fillRect(0, 0, W, H);
    TN.crowd(g, 0, H * 0.04, W, H * 0.1, ev.rt, ev.excite, Q.dens, flagCols(), '#5c3a4a');
    g.fillStyle = '#4dabf7'; g.fillRect(0, H * 0.62, W, H * 0.38);
    g.strokeStyle = '#fa5252'; g.lineWidth = 5;
    for (const y of [H * 0.5, H * 0.56]) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
    const res = ev.phase === 'result', t = res ? 99 : ev.t;
    ev.comps.forEach((c) => {
      const x = laneX(c.j);
      const f = c.frac ? clamp(t / 2.4, 0, 1) * c.frac : 0;
      const mh = H * 0.26, my = H * 0.16;
      rr(g, x - 9, my, 18, mh, 9); g.fillStyle = 'rgba(0,0,0,.25)'; g.fill();
      if (f > 0) { rr(g, x - 9, my + mh * (1 - f), 18, mh * f, 9); g.fillStyle = f > 0.9 ? '#ffd43b' : c.a.color; g.fill(); }
      const hitPh = (ev.rt * 4 + c.j * 0.3) % 1, swing = !res && t < 2.6;
      const sw = swing ? Math.sin(ev.rt * 16 + c.j) * 0.15 * f + (hitPh < 0.2 ? 0.12 : 0) : 0;
      g.save(); g.translate(x, H * 0.43); g.rotate(sw);
      g.strokeStyle = '#495057'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, -12); g.lineTo(0, 0); g.stroke();
      rr(g, -13, 0, 26, 50, 12); g.fillStyle = '#c92a2a'; g.fill(); g.lineWidth = 1.6; g.strokeStyle = '#1f2433'; g.stroke();
      g.restore();
      if (swing && hitPh < 0.12) TN.impact(g, x, H * 0.47, 16, hitPh / 0.12);
      let pose;
      if (res) pose = endPose(c, ev.rt + c.j);
      else if (swing) { const side = Math.floor(ev.rt * 4 + c.j * 0.3) % 2 ? 1 : -1; pose = Object.assign((Math.floor(ev.rt * 2) % 2 ? PZ.jab : PZ.hook)(hitPh * 2, side), { view: 'back' }); }
      else pose = Object.assign(PZ.guard(ev.rt), { view: 'back' });
      fig(c, x, H * 0.64, 1.0, pose);
      if (t >= 2.4 && c.score) txt(ev.phase === 'action' && t < 3.2 ? 'POW!' : String(c.score), x, my - 16, 18, '#fff');
      if (t >= 2.4 && t < 2.7 && !res) TN.impact(g, x, H * 0.47, 30, (t - 2.4) / 0.3);
      badge(c, x, H * 0.8, 15);
      if (c.j === 0) txt('YOU', x, H * 0.85, 13);
      if (res) medal(c.rank, x, H * 0.1, 34);
    });
  }

  // PENALTIES / SHOOTOUT: everyone's 5 shots, your athlete celebrates or hangs their head
  function drawPen() {
    const hoopRes = ev.E.kind === 'hoop';
    const gx = W * 0.2, gy = H * 0.15, gw = W * 0.6, gh = H * 0.13;
    if (hoopRes) { // basketball: court + backboard
      g.fillStyle = '#e0a96d'; g.fillRect(0, 0, W, H); g.fillStyle = 'rgba(160,100,50,.25)'; for (let x = 0; x < W; x += 34) g.fillRect(x, 0, 2, H);
      rr(g, W / 2 - 60, gy - 20, 120, 76, 6); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 4; g.strokeStyle = '#495057'; g.stroke();
      g.lineWidth = 6; g.strokeStyle = '#e8590c'; g.beginPath(); g.ellipse(W / 2, gy + 60, 34, 8, 0, 0, Math.PI * 2); g.stroke();
    } else {
      for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#40c057' : '#51cf66'; g.fillRect(0, (i * H) / 8, W, H / 8); }
      TN.crowd(g, 0, 0, W, gy - 6, ev.rt, ev.excite, Q.dens, flagCols());
      g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(gx, gy, gw, gh);
      g.strokeStyle = '#fff'; g.lineWidth = 6; g.beginPath(); g.moveTo(gx, gy + gh); g.lineTo(gx, gy); g.lineTo(gx + gw, gy); g.lineTo(gx + gw, gy + gh); g.stroke();
    }
    const res = ev.phase === 'result', t = res ? 99 : ev.t;
    const per = 0.68;
    const me = ev.comps[0];
    fig(me, W / 2, H * 0.5, 1.35, res ? endPose(me, ev.rt) : PZ.clap(ev.rt));
    ev.comps.forEach((c, i) => {
      const y = H * 0.58 + i * H * 0.075;
      rr(g, W * 0.06, y - 20, W * 0.88, 40, 14); g.fillStyle = c.j === 0 ? 'rgba(255,244,230,.95)' : 'rgba(255,255,255,.85)'; g.fill();
      badge(c, W * 0.06 + 22, y, 13);
      txt(c.j === 0 ? 'YOU' : run.duel ? c.name : c.a.name.split(' ')[0], W * 0.06 + 42, y, 13, '#2b2d42', 'left', null);
      for (let k = 0; k < 5; k++) {
        const x = W * 0.45 + k * W * 0.085;
        const shown = c.shots && t > (k + 1) * per;
        circle(x, y, 11, shown ? (c.shots[k] ? '#40c057' : '#fa5252') : '#dee2e6');
        if (shown) IC.draw(g, c.shots[k] ? 'check' : 'cross', x, y, 17);
      }
      if (res) medal(c.rank, W * 0.06 + W * 0.88 - 16, y, 28);
    });
  }

  // PODIUM: blocks rise, the top three hop on, medals drop onto their chests, confetti and a fanfare
  function podiumUpdate() {
    const t = ev.t, P = ev.pod;
    if (!P.fan && t > 1.0) { P.fan = true; AT.sfx('fanfare'); cheer(1); FX.add('confetti', W * 0.3, H * 0.2, 35, { speed: 230, life: 2.6, size: 4 }); FX.add('confetti', W * 0.7, H * 0.2, 35, { speed: 230, life: 2.6, size: 4 }); }
    for (let r = 0; r < Math.min(3, ev.comps.length); r++) {
      const land = 1.15 + (2 - r) * 0.28 + (ev.comps.length < 3 ? -0.28 : 0);
      if (!P.medal[r] && t > land + 0.35) { P.medal[r] = true; AT.sfx('coin'); const s = slot(r); FX.add('star', s.x, s.y - 40, 6, { speed: 90, life: 0.6, size: 4 }); }
    }
  }
  function slot(rank) { // podium block position for a rank
    const n = ev.comps.length;
    const x = n === 2 ? (rank === 0 ? W * 0.38 : W * 0.66) : [W * 0.5, W * 0.22, W * 0.78][rank];
    const h = [H * 0.2, H * 0.14, H * 0.1][rank], base = H * 0.86;
    return { x, h, top: base - h, base, y: base - h };
  }
  function drawPodium() {
    const t = ev.t;
    const sky = g.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, '#4dabf7'); sky.addColorStop(1, '#a5d8ff');
    g.fillStyle = sky; g.fillRect(0, 0, W, H);
    TN.crowd(g, 0, H * 0.12, W, H * 0.34, ev.rt, Math.max(ev.excite, 0.9), Q.dens, flagCols());
    g.fillStyle = '#69db7c'; g.fillRect(0, H * 0.46, W, H * 0.54);
    g.fillStyle = 'rgba(255,255,255,.18)'; for (let i = 0; i < 6; i++) g.fillRect(0, H * 0.5 + i * H * 0.09, W, H * 0.04);
    const order = ev.comps.slice().sort((a, b) => a.rank - b.rank);
    const rise = (k) => { k = clamp(k, 0, 1); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
    order.forEach((c) => {
      const r = c.rank;
      if (r > 2) { // 4th place watches from the side
        fig(c, W * 0.92, H * 0.95, 0.95, PZ.react(3, ev.rt));
        return;
      }
      const s = slot(r), hh = s.h * rise(t / 0.55 - r * 0.1);
      const top = s.base - hh;
      const bw = W * 0.25;
      rr(g, s.x - bw / 2, top, bw, hh + 4, 6); g.fillStyle = ['#fcc419', '#ced4da', '#e8a87c'][r]; g.fill(); g.lineWidth = 2; g.strokeStyle = '#1f2433'; g.stroke();
      g.fillStyle = 'rgba(255,255,255,.35)'; g.fillRect(s.x - bw / 2 + 4, top + 4, bw - 8, 6);
      if (hh > 26) txt(String(r + 1), s.x, top + hh / 2 + 4, 30, '#fff', 'center', 'rgba(0,0,0,.25)');
      // hop onto the block
      const land = 1.15 + (2 - r) * 0.28 + (ev.comps.length < 3 ? -0.28 : 0), j0 = land - 0.4;
      let y = top, x = s.x;
      if (t < j0) { x = s.x + (r === 0 ? 0 : r === 1 ? -bw * 0.6 : bw * 0.6); y = s.base + 8; }
      else if (t < land) { const k = (t - j0) / 0.4; x = s.x + (r === 0 ? 0 : (r === 1 ? -bw * 0.6 : bw * 0.6) * (1 - k)); y = (s.base + 8) + (top - (s.base + 8)) * k - Math.sin(k * Math.PI) * 40; }
      const pose = t < land ? (t < j0 ? PZ.stand(ev.rt) : { aL: [2.4, 0], aR: [2.4, 0], lL: [0.1, 0, 0.5], lR: [0.1, 0, 0.5], sq: 0.08, expr: 'happy' })
        : r === 0 ? PZ.victory(ev.sport, ev.rt, c.L) : r === 1 ? PZ.clap(ev.rt) : PZ.wave(ev.rt);
      const sc = r === 0 ? 1.45 : 1.25;
      fig(c, x, y, sc, pose);
      // the medal drops onto the chest
      const mt = t - (land + 0.05);
      if (mt > 0) {
        const chest = y - 25 * sc + (pose.by || 0) * sc;
        const k = clamp(mt / 0.3, 0, 1), my = -30 + (chest + 30) * k - (k >= 1 ? Math.abs(Math.sin(mt * 12)) * 6 * Math.exp(-mt * 4) : 0);
        if (k >= 1) { g.strokeStyle = ['#e03131', '#1c7ed6', '#2f9e44'][r]; g.lineWidth = 3; g.beginPath(); g.moveTo(x - 7, chest - 14); g.lineTo(x, my); g.lineTo(x + 7, chest - 14); g.stroke(); }
        IC.draw(g, MEDALS[r], x, my, 26);
      }
      badge(c, s.x - 22, s.base + 20, 11);
      txt(c.j === 0 ? 'YOU' : String(c.name).split(' ')[0], s.x + 6, s.base + 20, 12, '#fff', 'left');
    });
  }

  function drawFeedback() {
    if (!ev.fb || ev.fbT > 1) return;
    const t = ev.fbT;
    const s = t < 0.16 ? 0.3 + (t / 0.16) * 1.0 : t < 0.3 ? 1.3 - ((t - 0.16) / 0.14) * 0.3 : 1;
    g.save();
    g.globalAlpha = t > 0.72 ? Math.max(0, 1 - (t - 0.72) / 0.28) : 1;
    g.translate(W / 2, ev.fbY - t * 18); g.scale(s, s);
    // white outer outline + dark inner outline: readable on every background
    g.font = `900 50px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
    g.lineWidth = 16; g.strokeStyle = '#fff'; g.strokeText(ev.fb, 0, 0);
    g.lineWidth = 8; g.strokeStyle = '#2b2d42'; g.strokeText(ev.fb, 0, 0);
    g.fillStyle = ev.fbCol; g.fillText(ev.fb, 0, 0);
    if (ev.fbSub) {
      g.font = `900 19px ${FONT}`; const tw = g.measureText(ev.fbSub).width;
      rr(g, -tw / 2 - 12, 26, tw + 24, 30, 15); g.fillStyle = 'rgba(43,45,66,.85)'; g.fill();
      txt(ev.fbSub, 0, 41, 19, '#fff', 'center', null);
    }
    g.restore();
  }
  // the athletes line up and wave while the camera swoops over the venue
  function lineup() {
    const n = ev.comps.length, sp = n > 2 ? 0.22 : 0.3;
    ev.comps.forEach((c, i) => { const x = W * (0.5 + (i - (n - 1) / 2) * sp), y = H * 0.84; fig(c, x, y, 1.3, PZ.wave(ev.rt * 1.1 + i * 0.7)); badge(c, x, y + 20, 11); });
  }
  function swoopUI() {
    const k = clamp(ev.t / 0.5, 0, 1), y = H * 0.1 + (1 - k) * -60;
    rr(g, W * 0.08, y - 26, W * 0.84, 52, 26); g.fillStyle = 'rgba(43,45,66,.82)'; g.fill();
    txt(ev.E.name, W / 2, y - 4, 24, '#fff', 'center', null);
    txt(run.duel ? 'Challenge' : `${LEAGUES[run.lvl].name} · event ${run.idx + 1}/${run.members.length}`, W / 2, y + 16, 12, '#ffe066', 'center', null);
    if (ev.t > 1.2) txt('Tap to skip', W / 2, H * 0.97, 12, 'rgba(255,255,255,.8)');
  }
  function introCard() {
    g.fillStyle = 'rgba(20,24,40,.55)'; g.fillRect(0, 0, W, H);
    const s = Math.min(1, ev.t * 4), k = s < 1 ? 0.6 + 0.5 * s : 1 + Math.sin(ev.t * 3) * 0.02;
    const [icon, line] = INTRO[ev.E.game];
    g.save(); g.translate(W / 2, H * 0.46); g.scale(k, k);
    const cw = Math.min(W * 0.9, 380), x0 = -cw / 2;
    rr(g, x0, -170, cw, 345, 28); g.fillStyle = '#fffaf0'; g.fill(); g.lineWidth = 5; g.strokeStyle = '#fff'; g.stroke();
    circle(0, -122, 36, '#ffe066'); IC.draw(g, icon, 0, -122, 50);
    txt(ev.E.name, 0, -70, 24, '#2b2d42', 'center', null);
    txt(line, 0, -42, line.length > 36 ? 13 : 15, '#495057', 'center', null);
    // the athlete's 3 stats as small bars; the ones that help in this sport are highlighted
    const help = STAT_HELP[ev.E.game] || {}, st = ev.m.st || [20, 20, 20];
    STAT_NAMES.forEach(([nm, ic], i) => {
      const y = -6 + i * 38, on = help[i] != null;
      rr(g, x0 + 10, y - 16, cw - 20, 34, 12); g.fillStyle = on ? '#fff3bf' : '#f1f3f5'; g.fill();
      if (on) { g.lineWidth = 2.5; g.strokeStyle = '#fab005'; g.stroke(); }
      IC.draw(g, ic, x0 + 30, y + 1, 24, on ? null : '#ced4da');
      txt(nm, x0 + 48, y - 5, 12, on ? '#2b2d42' : '#868e96', 'left', null);
      if (on) txt(help[i], x0 + 48, y + 9, 10, '#e67700', 'left', null);
      const bx = x0 + cw * 0.5, bw = cw * 0.36;
      rr(g, bx, y - 4, bw, 10, 5); g.fillStyle = '#dee2e6'; g.fill();
      rr(g, bx, y - 4, Math.max(6, bw * st[i] / 100), 10, 5); g.fillStyle = on ? '#fab005' : '#adb5bd'; g.fill();
      txt(String(Math.round(st[i])), x0 + cw - 22, y + 1, 14, '#2b2d42', 'center', null);
    });
    // energy before this match
    const en = ev.mod.en, ey = 112, ecol = en >= 60 ? '#40c057' : en >= 20 ? '#fab005' : '#fa5252';
    IC.draw(g, 'battery', x0 + 30, ey, 22);
    txt('Energy', x0 + 48, ey, 12, '#2b2d42', 'left', null);
    rr(g, x0 + cw * 0.5, ey - 5, cw * 0.36, 10, 5); g.fillStyle = '#dee2e6'; g.fill();
    rr(g, x0 + cw * 0.5, ey - 5, Math.max(6, cw * 0.36 * en / 100), 10, 5); g.fillStyle = ecol; g.fill();
    txt(`${Math.round(en)}%`, x0 + cw - 22, ey, 13, '#2b2d42', 'center', null);
    if (ev.mod.ef < 1) txt('Tired: smaller zones, slower play', 0, ey + 22, 12, '#c92a2a', 'center', null);
    txt('Tap to start', 0, 156, 15, '#e8590c', 'center', null);
    g.restore();
  }
  // 3, 2, 1, GO!
  function countUI(t) {
    const i = Math.floor(t / 0.6); if (i > 3) return;
    const k = (t % 0.6) / 0.6, lab = i < 3 ? String(3 - i) : 'GO!';
    g.save(); g.translate(W / 2, H * 0.44);
    const s = k < 0.18 ? 0.4 + (k / 0.18) * 1.0 : 1.4 - Math.min(0.4, (k - 0.18) * 0.8);
    g.scale(s, s); g.globalAlpha = k > 0.75 ? Math.max(0, 1 - (k - 0.75) * 4) : 1;
    g.font = `900 ${i < 3 ? 110 : 92}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
    g.lineWidth = 22; g.strokeStyle = '#fff'; g.strokeText(lab, 0, 0);
    g.lineWidth = 10; g.strokeStyle = '#2b2d42'; g.strokeText(lab, 0, 0);
    g.fillStyle = i < 3 ? '#ffd43b' : '#51cf66'; g.fillText(lab, 0, 0);
    g.restore();
  }

  function draw() {
    g.clearRect(0, 0, W, H);
    const ph = ev.phase;
    g.save(); camApply();
    if (ph === 'swoop' || ph === 'intro' || ph === 'count' || ph === 'play') { ev.game.draw(); if (ph === 'swoop') lineup(); }
    else if (ph === 'podium') drawPodium();
    else { const k = ev.E.kind; if (k === 'race') drawRace(); else if (k === 'lift') drawLift(); else if (k === 'box') drawBox(); else drawPen(); }
    FX.draw(g);
    g.restore();
    if (ph === 'play' || ph === 'count') ev.game.ui();
    if (ph === 'swoop') swoopUI(); else if (ph !== 'podium') header();
    if (ph === 'intro') introCard();
    if (ph === 'count') countUI(ev.t); else if (ph === 'play' && ev.goT < 0.6) countUI(1.8 + ev.goT);
    if (ph === 'action' && ev.t < 1.4 && ev.ts > 0.9) {
      const grade = ev.skill > 0.8 ? 'Great play!' : ev.skill > 0.45 ? 'Nice!' : 'Keep practicing!';
      txt(grade, W / 2, H * 0.92, 22, '#fff');
    }
    if (ph === 'result') {
      const r = ev.comps[0].rank;
      const s = Math.min(1, ev.t * 4);
      g.save(); g.translate(W / 2, H * 0.92); g.scale(s, s);
      rr(g, -W * 0.4, -30, W * 0.8, 60, 22); g.fillStyle = r === 0 ? '#fab005' : '#fff'; g.fill();
      medal(r, -W * 0.3, 0, 40);
      txt(`YOU: ${PLACE[r]}!  +${EVENT_PTS[r]}`, 12, 0, 24, r === 0 ? '#fff' : '#2b2d42', 'center', r === 0 ? 'rgba(0,0,0,.3)' : null);
      g.restore();
    }
    if (ph === 'podium') {
      const k = clamp(ev.t / 0.4, 0, 1);
      rr(g, W * 0.18, H * 0.04 - (1 - k) * 60, W * 0.64, 44, 22); g.fillStyle = 'rgba(43,45,66,.85)'; g.fill();
      txt(`${ev.E.name}`, W / 2, H * 0.04 + 22 - (1 - k) * 60, 20, '#ffe066', 'center', null);
      if (ev.t > 1.4) txt('Tap to continue', W / 2, H * 0.985, 12, '#fff');
    }
    drawFeedback();
    if (ev.letterbox > 0.02) { const b = H * 0.08 * ev.letterbox; g.fillStyle = '#000'; g.fillRect(0, 0, W, b); g.fillRect(0, H - b, W, b); }
    if (ev.flash > 0) { g.fillStyle = `rgba(255,255,255,${Math.min(0.8, ev.flash * 3)})`; g.fillRect(0, 0, W, H); }
    if (ev.fade < 0.32) { g.fillStyle = `rgba(${ev.fadeCol},${(1 - ev.fade / 0.32) * 0.9})`; g.fillRect(0, 0, W, H); } // smooth transitions, no hard cuts
  }
  // ======================================================================
  // RESULTS & PRIZES
  // ======================================================================
  function finish() {
    ev = null;
    if (run.duel) { finishDuel(); return; }
    const S = AT.S(), sp = run.sport, l = S.lg[sp], lvl = l.lvl, L = LEAGUES[lvl], spt = SPORTS[sp];
    const idx = [0, 1, 2, 3].sort((a, b) => run.totals[b] - run.totals[a] || run.pow[b] - run.pow[a]);
    const place = idx.indexOf(0);
    const topZone = AT.topZoneOf();
    const base = 40 + ZONES[topZone].fee * 14;
    const coins = Math.round(base * [3, 1.6, 1, 0.5][place] * L.coin);
    const trophy = ['TROPHY_GOLD', 'TROPHY_SILVER', 'TROPHY_BRONZE', null][place];
    const gear = Math.random() < [0.4 + lvl * 0.05, 0.15 + lvl * 0.03, 0, 0][place];
    const pts = PLACE_PTS[place];
    const rpAdd = RIVALS.map((_, k) => PLACE_PTS[idx.indexOf(k + 1)]);
    const newPts = l.pts + pts, played = l.played + 1, last = lvl === LEAGUES.length - 1;
    // season: enough points promotes right away; after the last tournament a weak season drops one league
    let outcome = null;
    if (newPts >= L.target) outcome = last ? 'diamond' : 'promote';
    else if (played >= L.events) outcome = newPts < L.keep && lvl > 0 ? 'relegate' : 'stay';
    const next = LEAGUES[lvl + 1], prev = LEAGUES[lvl - 1];
    const firstTitle = (outcome === 'promote' || outcome === 'diamond') && !l.won.includes(lvl);
    const titleTags = [];
    if (firstTitle) titleTags.push(`<span>${ico(L.decor)} Decoration +2%</span>`);
    if (firstTitle && lvl === 3) titleTags.push(`<span>${ico('euro')} European medal</span>`);
    if (firstTitle && lvl === 4) titleTags.push(`<span>${ico('globe')} World medal</span>`);
    if (outcome === 'diamond') titleTags.push(`<span>${ico('diamond')} Diamond trophy</span>`);
    const season = {
      promote: `<div class="season promo">${ico(L.icon)} ${L.short} title! Promoted to ${ico(next && next.icon)} <b>${next && next.name}</b></div>`,
      diamond: `<div class="season promo">${ico('diamond')} Diamond League champions!</div>`,
      relegate: `<div class="season down">Season over · ${newPts}/${L.target} pts — down to ${ico(prev && prev.icon)} ${prev && prev.name}</div>`,
      stay: `<div class="season">Season over · ${newPts}/${L.target} pts — new ${L.short} season</div>`,
    }[outcome] || `<div class="season">${ico(L.icon)} ${L.short} · <b>${newPts}/${L.target}</b> pts · tournament ${played}/${L.events}</div>`;

    const podSlot = (rank, cls) => {
      const a = ACAD[idx[rank]];
      return `<div class="pod ${cls} ${idx[rank] === 0 ? 'me' : ''}">${logo(a)}<div class="pn">${idx[rank] === 0 ? 'YOU' : a.name}</div><div class="blk">${rank + 1}</div></div>`;
    };
    const prizeTags = [`<span>${ico('coin')} +${fmt(coins)}</span>`];
    if (trophy) prizeTags.push(`<span>${ico(MEDALS[place])} Trophy</span>`);
    if (gear) prizeTags.push(`<span>${ico('sparkle')} Gold Gear</span>`);
    prizeTags.push(`<span>${ico('chart')} +${pts} pts</span>`);
    const a4 = ACAD[idx[3]];
    AT.showModal(`<div class="mh"><span>${ico(spt.icon)} Results</span></div>
      <div class="podium">${podSlot(1, 'p2')}${podSlot(0, 'p1')}${podSlot(2, 'p3')}</div>
      <div class="fourth">4th ${logo(a4, 20)} ${idx[3] === 0 ? 'YOU' : a4.name}</div>
      <div class="prize"><div class="big">${place === 0 ? `${ico('crown')} Champions!` : `You placed ${PLACE[place]}!`}</div><div class="pz">${prizeTags.join('')}</div></div>
      ${season}${titleTags.length ? `<div class="pz title">${titleTags.join('')}</div>` : ''}
      <button class="go" data-go="1">Collect</button>`, (e, b) => {
      if (!b || !b.dataset.go) return;
      collect();
    });
    AT.sfx(outcome === 'promote' || outcome === 'diamond' ? 'legend' : place === 0 ? 'win' : outcome === 'relegate' ? 'lose' : 'level');
    if (place === 0 || outcome === 'promote' || outcome === 'diamond') AT.sfx('crowd');
    cv.classList.add('hidden');

    let collected = false;
    pendingCollect = collect;
    function collect() {
      if (collected) return;
      collected = true;
      pendingCollect = null;
      if (AT.coachEmote) setTimeout(() => AT.coachEmote(place === 0 ? 'cheer' : place === 1 ? 'thumbs' : 'facepalm'), 400);
      const titlesBefore = AT.titleCount();
      AT.addCoins(coins);
      if (trophy) { AT.addItem(trophy); S.trophyLog.push({ t: place, l: lvl }); }
      if (gear) AT.addItem('GOLD_GEAR');
      l.pts = newPts; l.played = played; l.rp = l.rp.map((v, k) => v + rpAdd[k]);
      const reset = () => { l.pts = 0; l.played = 0; l.rp = [0, 0, 0]; };
      if (outcome === 'promote' || outcome === 'diamond') {
        if (!l.won.includes(lvl)) {
          l.won.push(lvl); AT.addItem('DECOR');
          if (lvl === 3) AT.addItem('MEDAL_EURO');
          if (lvl === 4) AT.addItem('MEDAL_WORLD');
        }
        if (outcome === 'diamond') { AT.addItem('TROPHY_DIAMOND'); l.titles = (l.titles || 0) + 1; } else l.lvl++;
        reset();
      } else if (outcome === 'relegate') { l.lvl--; reset(); } else if (outcome === 'stay') reset();
      l.best = Math.max(l.best || 0, l.lvl);
      l.next = AT.TOURNEY_INTERVAL;
      S.played++; AT.task('tourney');
      T.active = false;
      run = null;
      cv.classList.add('hidden');
      if (AT.modalOpen()) AT.hideModal();
      AT.afterTourney();
      AT.sfx('buy');
      AT.sendScore(AT.leagueScore());
      const tc = AT.titleCount();
      const opened = tc > titlesBefore ? ZONES.filter((z, i) => z.need > titlesBefore && z.need <= tc && !S.zones[i].unlocked) : [];
      if (outcome === 'promote') setTimeout(() => AT.toast(`${ico(LEAGUES[l.lvl].icon)} ${spt.name}: ${LEAGUES[l.lvl].name}!${opened.length ? `<br>${opened.map((z) => ico(z.icon)).join(' ')} New zone can be built` : ''}`, 3200), 300);
      else if (outcome === 'diamond') setTimeout(() => AT.toast(`${ico('diamond')} Diamond trophy won! New season starts`, 3000), 300);
      else if (outcome === 'relegate') setTimeout(() => AT.toast(`${ico(spt.icon)} ${spt.name} drops to ${LEAGUES[l.lvl].short}`, 2600), 300);
    }
  }

  // 1-on-1 challenge result
  function finishDuel() {
    const S = AT.S(), c = run.duel, done = run.onDone;
    const win = run.log.length && run.log[0].rank === 0;
    const gear = win && Math.random() < 0.3; // sometimes a rare item
    const loss = win ? 0 : Math.min(c.risk, Math.floor(S.wallet.COINS));
    const tags = win
      ? [`<span>${ico('coin')} +${fmt(c.prize)}</span>`].concat(gear ? [`<span>${ico('sparkle')} Rare: Gold Gear</span>`] : [])
      : [loss ? `<span class="neg">${ico('coin')} −${fmt(loss)}</span>` : `<span>No coins lost</span>`];
    AT.showModal(`<div class="mh"><span>${ico('swords')} Challenge</span></div>
      <div class="duel">${logo(PLAYER, 54)}<b>VS</b>${logo(c.academy, 54)}</div>
      <div class="prize"><div class="big">${win ? `${ico('crown')} You beat ${c.name}!` : `${c.name} wins this time`}</div><div class="pz">${tags.join('')}</div></div>
      <button class="go" data-go="1">${win ? 'Collect' : 'OK'}</button>`, (e, b) => {
      if (!b || !b.dataset.go) return;
      collect();
    });
    AT.sfx(win ? 'win' : 'lose');
    if (win) AT.sfx('crowd');
    cv.classList.add('hidden');
    let collected = false;
    pendingCollect = collect;
    function collect() {
      if (collected) return;
      collected = true; pendingCollect = null;
      if (AT.coachEmote) setTimeout(() => AT.coachEmote(win ? 'cheer' : 'facepalm'), 400);
      if (win) AT.addCoins(c.prize); else if (loss) AT.addCoins(-loss);
      if (gear) AT.addItem('GOLD_GEAR');
      T.active = false; run = null;
      cv.classList.add('hidden');
      if (AT.modalOpen()) AT.hideModal();
      AT.afterTourney();
      AT.sfx(win ? 'buy' : 'tap');
      if (done) done(win ? 'win' : 'lose');
    }
  }

  // ======================================================================
  // LEAGUES SCREEN: one tab per sport
  // ======================================================================
  let lgTab = 0;
  T.openLeague = function (sp) {
    const S = AT.S();
    if (sp != null && sp >= 0) lgTab = sp;
    const mmss = (t) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
    // football: national-team style kits unlock in the European / World leagues
    const kitRow = () => {
      const K = AT.Skins.KITS, cur = AT.myKit ? AT.myKit() : null;
      const css = (c) => '#' + c.toString(16).padStart(6, '0');
      const chip = (id) => {
        if (!id) return `<button class="kchip ${!cur ? 'on' : ''}" data-kit="none"><i style="background:#ffa94d"></i><span>Academy</span></button>`;
        const k = K[id], ok = AT.kitUnlocked(id);
        const bg = k.stripes ? `repeating-linear-gradient(90deg,${css(k.shirt)} 0 5px,${css(k.stripes)} 5px 10px)` : css(k.shirt);
        return `<button class="kchip ${cur === id ? 'on' : ''} ${ok ? '' : 'lk'}" data-kit="${id}" title="${k.name}"><i style="background:${bg};border-bottom:7px solid ${css(k.shorts)}"></i><span>${ok ? k.name.replace(' style', '') : ico('lock')}</span></button>`;
      };
      return `<div class="kitrow"><div class="kt">${ico('jersey')} Team kit <small>European kits unlock in the European league, World kits in the World league</small></div><div class="kchips">${[null, 'ger', 'fra', 'ita', 'esp', 'bra', 'arg'].map(chip).join('')}</div></div>`;
    };
    const html = () => {
      const cur = lgTab, l = S.lg[cur], L = LEAGUES[l.lvl], spt = SPORTS[cur];
      const has = AT.sportHasAthletes(cur), open = AT.sportOpen(cur), last = l.lvl === LEAGUES.length - 1;
      const tabs = SPORTS.map((s, i) => {
        const ready = S.lg[i].next <= 0 && AT.sportHasAthletes(i);
        return `<button class="tab ${i === cur ? 'on' : ''} ${AT.sportOpen(i) ? '' : 'lk'}" data-tab="${i}">${ico(s.icon)}<span>${s.name}</span>${ready ? '<i class="rd"></i>' : ''}</button>`;
      }).join('');
      const table = [{ n: 'You', a: PLAYER, p: l.pts, me: 1 }].concat(RIVALS.map((r, k) => ({ n: r.name, a: r, p: l.rp[k] || 0 })))
        .sort((a, b) => b.p - a.p || (b.me ? 1 : 0) - (a.me ? 1 : 0))
        .map((r, i) => `<div class="lrow ${r.me ? 'me' : ''}"><span class="rk">${i + 1}</span>${logo(r.a)}<span class="nm">${r.n}</span><span class="pt">${r.p}</span></div>`).join('');
      const prog = clamp(l.pts / L.target, 0, 1);
      const reward = [`${ico('coin')} ×${L.coin} prizes`, `${ico(L.decor)} +2% decoration`];
      if (l.lvl === 3) reward.push(`${ico('euro')} European medal`);
      if (l.lvl === 4) reward.push(`${ico('globe')} World medal`);
      if (last) reward.push(`${ico('diamond')} Diamond trophy`);
      const action = !open ? `<div class="next lk">${ico('lock')} Open the ${spt.name} zone first</div>`
        : !has ? `<div class="next lk">${ico('scout')} Sign a ${spt.name} athlete at the Scouting Office</div>`
          : l.next <= 0 ? `<button class="go" data-go="1">Enter Tournament ${ico('play')}</button>`
            : `<div class="next">${ico('hourglass')} Next tournament in <b>${mmss(l.next)}</b></div>`;
      const ladder = LEAGUES.map((g, i) => {
        const st = i < l.lvl ? 'done' : i === l.lvl ? 'cur' : 'lk';
        const mark = l.won.includes(i) ? ico('check') : i > l.lvl ? ico('lock') : '';
        return `<div class="lrung ${st}"><span class="ri">${ico(g.icon)}</span><span class="ln">${g.name}</span><span class="lr">${ico('coin')}×${g.coin}</span><span class="ls">${mark}</span></div>`;
      }).reverse().join('');
      return `<div class="mh"><span>${ico('trophy')} Leagues</span><button class="x">${ico('close')}</button></div>
        <div class="tabs">${tabs}</div>
        <div class="lghead"><span class="lgi">${ico(L.icon)}</span><div><b>${L.name}</b><span>${ico(spt.icon)} ${spt.name} · tournament ${Math.min(l.played + 1, L.events)}/${L.events}</span></div></div>
        <div class="bar"><i style="width:${Math.round(prog * 100)}%"></i>${!last && L.keep ? `<s style="left:${Math.round((L.keep / L.target) * 100)}%"></s>` : ''}</div>
        <div class="sub">${l.pts}/${L.target} pts ${last ? `to win the ${ico('diamond')} Diamond trophy` : `to promote${L.keep ? ` · under ${L.keep} at season end drops a league` : ''}`}</div>
        ${action}
        ${SPORTS[cur].id === 'football' ? kitRow() : ''}
        ${table}
        <div class="sub">Top 3 score points: 1st ${PLACE_PTS[0]} · 2nd ${PLACE_PTS[1]} · 3rd ${PLACE_PTS[2]}</div>
        <div class="rwd">${reward.map((r) => `<span>${r}</span>`).join('')}</div>
        <div class="ladder2">${ladder}</div>
        <div class="sub">${ico('trophy')} ${AT.trophyCount()} trophies · ${AT.titleCount()} titles · ${S.played} tournaments${S.chalWins ? ` · ${S.chalWins} challenges won` : ''}</div>`;
    };
    AT.showModal(html(), (e, b) => {
      if (!b) return;
      if (b.dataset.tab != null) { lgTab = +b.dataset.tab; $('modalCard').innerHTML = html(); return; }
      if (b.dataset.kit) {
        const id = b.dataset.kit === 'none' ? null : b.dataset.kit;
        if (id && !AT.kitUnlocked(id)) { AT.toast(AT.Skins.KITS[id].region === 'eu' ? 'Reach the European league to unlock' : 'Reach the World league to unlock'); AT.sfx('miss'); return; }
        AT.setKit(id); AT.sfx('tap'); if (AT.coachEmote) AT.coachEmote('thumbs'); $('modalCard').innerHTML = html(); return;
      }
      if (b.dataset.go) {
        const l = S.lg[lgTab];
        if (l.next > 0 || !AT.sportHasAthletes(lgTab)) return;
        T.openPicker(lgTab);
      }
    });
  };
})();
