/* Athlete Tycoon — one flat vector icon set, drawn in code (no emojis, no image files).
   Every icon lives on a 24×24 grid and is a list of parts:
     { d, f }      filled shape with the shared dark rounded outline
     { d, l, w }   thick rounded line: dark outline underneath, colour on top
     { d, k, w }   plain dark detail line
   The same data renders as inline SVG (menus/HUD) and onto canvases (3D labels, tournament). */
'use strict';
(function () {
  const AT = (window.AT = window.AT || {});
  const INK = '#2b2d42';
  const OUT = 2.1; // outline width on the 24 grid

  // ---------- path helpers ----------
  const C = (cx, cy, r) => `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0z`;
  const R = (x, y, w, h, r) => `M${x + r} ${y}h${w - 2 * r}a${r} ${r} 0 0 1 ${r} ${r}v${h - 2 * r}a${r} ${r} 0 0 1 ${-r} ${r}h${-(w - 2 * r)}a${r} ${r} 0 0 1 ${-r} ${-r}v${-(h - 2 * r)}a${r} ${r} 0 0 1 ${r} ${-r}z`;
  const poly = (pts) => 'M' + pts.map((p) => p.map((v) => +v.toFixed(2)).join(' ')).join('L') + 'z';
  function starPath(cx, cy, R1, R2, n = 5) {
    const pts = [];
    for (let i = 0; i < n * 2; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / n, r = i % 2 ? R2 : R1;
      pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    return poly(pts);
  }
  function gearPath(cx, cy, ro, ri, teeth) {
    const pts = [], step = (Math.PI * 2) / teeth;
    for (let i = 0; i < teeth; i++) {
      const a = i * step;
      for (const [o, r] of [[-0.3, ri], [-0.17, ro], [0.17, ro], [0.3, ri]]) pts.push([cx + Math.cos(a + o * step * 1.6) * r, cy + Math.sin(a + o * step * 1.6) * r]);
    }
    return poly(pts);
  }
  const medal = (metal, shine) => [
    { d: 'M7.5 2.5h4l1.5 6.5-4 1.5z', f: '#4dabf7' },
    { d: 'M16.5 2.5h-4l-1.5 6.5 4 1.5z', f: '#fa5252' },
    { d: C(12, 15.2, 6.3), f: metal },
    { d: C(12, 15.2, 3.3), f: shine },
  ];
  const shoe = [
    { d: 'M3 16.5V8.5h4.5l1.8 2.6h3.4l5.6 2.2c1.6.6 2.7 1.7 2.7 3.2z', f: '#ff6b6b' },
    { d: R(2.6, 16.5, 18.8, 3.2, 1.4), f: '#fff' },
    { d: 'M9.6 11.2l-1.3 1.8M12.4 11.4l-1.2 1.8', k: 1, w: 1.6 },
  ];

  const ICONS = {
    coin: [{ d: C(12, 12, 9), f: '#ffd43b' }, { d: C(12, 12, 5.2), f: '#fab005' }],
    trophy: [
      { d: 'M7 7H4.2v1.6a3.6 3.6 0 0 0 3.6 3.6M17 7h2.8v1.6a3.6 3.6 0 0 1-3.6 3.6', k: 1, w: 2 },
      { d: 'M6.5 3.5h11v5.2a5.5 5.5 0 0 1-11 0z', f: '#ffd43b' },
      { d: R(10.2, 13.8, 3.6, 3.4, 0.6), f: '#fab005' },
      { d: R(6.8, 17, 10.4, 3.6, 1.2), f: '#fab005' },
    ],
    star: [{ d: starPath(12, 12.8, 9.8, 4.5), f: '#ffd43b' }],
    lock: [
      { d: 'M8 10.5V7.8a4 4 0 0 1 8 0v2.7', k: 1, w: 2.6 },
      { d: R(4.8, 10.2, 14.4, 10.3, 2.6), f: '#ffd43b' },
      { d: C(12, 14.6, 1.5), f: INK },
    ],
    trash: [
      { d: 'M9.5 5.5V3.8h5v1.7', k: 1, w: 2 },
      { d: 'M6.2 7.6h11.6l-1.1 12.9H7.3z', f: '#69db7c' },
      { d: R(4.2, 5.2, 15.6, 2.8, 1.2), f: '#40c057' },
      { d: 'M10 10.8v6.6M14 10.8v6.6', k: 1, w: 1.7 },
    ],
    arrow: [{ d: 'M3.5 9.3h9.3V5.2l7.7 6.8-7.7 6.8v-4.1H3.5z', f: '#ffd43b' }],
    up: [{ d: 'M12 3.2l8 8.3h-4.8v9.3H8.8v-9.3H4z', f: '#51cf66' }],
    shoe,
    speed: [
      { d: 'M1.5 5.5h4M1 9h3', l: '#4dabf7', w: 1.8 },
      { d: 'M5 16.5V8.5h4l1.6 2.4h3l5 2c1.5.6 2.4 1.6 2.4 3z', f: '#ff6b6b' },
      { d: R(4.6, 16.5, 17, 3.2, 1.4), f: '#fff' },
    ],
    boxes: [
      { d: R(3, 12.5, 8.6, 8, 1.2), f: '#ffa94d' },
      { d: R(12.4, 12.5, 8.6, 8, 1.2), f: '#ffa94d' },
      { d: R(7.7, 4, 8.6, 8.5, 1.2), f: '#ffc078' },
      { d: 'M7.3 12.5v2.4M16.7 12.5v2.4M12 4v2.4', k: 1, w: 1.6 },
    ],
    gear: [{ d: gearPath(12, 12, 10, 7.4, 8), f: '#adb5bd' }, { d: C(12, 12, 3.2), f: '#fff' }],
    close: [{ d: 'M6.5 6.5l11 11M17.5 6.5l-11 11', l: '#fa5252', w: 3.4 }],
    cross: [{ d: 'M6.5 6.5l11 11M17.5 6.5l-11 11', l: '#fa5252', w: 3.4 }],
    check: [{ d: 'M5 12.8l4.4 4.4L19 7.4', l: '#51cf66', w: 3.4 }],
    play: [{ d: 'M8 4.5c0-.8.9-1.3 1.6-.9l10 6.9c.6.4.6 1.3 0 1.7l-10 6.9c-.7.5-1.6 0-1.6-.9z', f: '#51cf66' }],
    plus: [{ d: 'M12 5v14M5 12h14', l: '#51cf66', w: 3.6 }],
    dumbbell: [
      { d: 'M6.5 12h11', l: '#ced4da', w: 2.6 },
      { d: R(2.2, 8.2, 3, 7.6, 1.2), f: '#5c7cfa' },
      { d: R(4.6, 6.2, 3.4, 11.6, 1.4), f: '#748ffc' },
      { d: R(16, 6.2, 3.4, 11.6, 1.4), f: '#748ffc' },
      { d: R(18.8, 8.2, 3, 7.6, 1.2), f: '#5c7cfa' },
    ],
    football: [
      { d: C(12, 12, 9.2), f: '#fff' },
      { d: poly([0, 1, 2, 3, 4].map((i) => [12 + Math.cos(-Math.PI / 2 + i * 1.2566) * 3.6, 12.2 + Math.sin(-Math.PI / 2 + i * 1.2566) * 3.6])), f: INK },
      { d: 'M12 8.4V3.4M15.5 11.3l4.6-1.6M14.2 15.5l2.9 3.9M9.8 15.5l-2.9 3.9M8.5 11.3l-4.6-1.6', k: 1, w: 1.6 },
    ],
    wave: [
      { d: 'M2.5 9.5c2.4-2.6 4.8-2.6 7.2 0s4.8 2.6 7.2 0c1.4-1.5 3-2.2 4.6-1.6', l: '#74c0fc', w: 2.4 },
      { d: 'M2.5 15c2.4-2.6 4.8-2.6 7.2 0s4.8 2.6 7.2 0c1.4-1.5 3-2.2 4.6-1.5v7H2.5z', f: '#339af0' },
    ],
    glove: [
      { d: R(7.5, 16.5, 9.6, 4.8, 1.4), f: '#fff' },
      { d: 'M7 6.4C7 4.2 8.8 3 11 3h3.6c2.6 0 4.7 2.1 4.7 4.7v5.5c0 2.3-1.9 4.2-4.2 4.2H9.6C8.2 17.4 7 16.2 7 14.8z', f: '#fa5252' },
      { d: 'M7.2 9.4c-2-.6-3.4.9-3 2.6.3 1.4 1.6 2.3 3 2.4', f: '#e03131' },
      { d: 'M10.5 7.2c1.7-.6 3.7-.6 5.4.2', k: 1, w: 1.5 },
    ],
    stadium: [
      { d: 'M2.5 9.5c3-3.6 16-3.6 19 0v7.5c-3 3-16 3-19 0z', f: '#20c997' },
      { d: 'M6.2 13.2c1.6-1.6 10-1.6 11.6 0 .2 1.6-11.8 1.6-11.6 0z', f: '#8ce99a' },
      { d: 'M5 5.5v-2.4l2.6 1.1zM19 5.5v-2.4l2.6 1.1z', f: '#fa5252' },
    ],
    drop: [{ d: 'M12 3.2c3.8 4.6 6.4 7.7 6.4 11a6.4 6.4 0 0 1-12.8 0c0-3.3 2.6-6.4 6.4-11z', f: '#4dabf7' }, { d: 'M9.3 14.5a2.8 2.8 0 0 0 2 2.6', k: 1, w: 1.5 }],
    board: [{ d: R(6.2, 2.8, 11.6, 18.4, 5.4), f: '#ff922b' }, { d: R(9.2, 5.6, 5.6, 2.8, 1.4), f: '#fff' }],
    shake: [
      { d: 'M12.5 6.5l2.2-4', k: 1, w: 2 },
      { d: 'M7.2 9h9.6l-1.3 11.5H8.5z', f: '#f783ac' },
      { d: R(5.6, 6, 12.8, 3.3, 1.4), f: '#fff' },
    ],
    hourglass: [
      { d: 'M8 4.3v2.6c0 2.6 4 3.6 4 5.1s-4 2.5-4 5.1v2.6h8v-2.6c0-2.6-4-3.6-4-5.1s4-2.5 4-5.1V4.3z', f: '#ffe066' },
      { d: 'M6.3 3.6h11.4M6.3 20.4h11.4', l: '#ff922b', w: 2.4 },
    ],
    stopwatch: [
      { d: R(10.2, 1.8, 3.6, 2.8, 0.8), f: '#ff922b' },
      { d: C(12, 13.4, 8), f: '#fff' },
      { d: 'M12 13.4V9.2M12 13.4l2.8 1.8', k: 1, w: 2 },
    ],
    tag: [{ d: 'M3.4 12.2V5.2c0-1 .8-1.8 1.8-1.8h7l8.4 8.4-9.2 9.2z', f: '#51cf66' }, { d: C(8, 8, 1.7), f: '#fff' }],
    medalGold: medal('#fcc419', '#fff3bf'),
    medalSilver: medal('#ced4da', '#f8f9fa'),
    medalBronze: medal('#e8590c', '#ffc078'),
    crown: [
      { d: 'M3.4 7.6l4.6 4.3 4-6.4 4 6.4 4.6-4.3-1.7 11.3H5.1z', f: '#ffd43b' },
      { d: R(5, 16.8, 14, 3.4, 1), f: '#fab005' },
      { d: C(12, 5, 1.4), f: '#ff6b6b' },
    ],
    soundOn: [
      { d: 'M3.5 9.3h3.8l5-4.3v14l-5-4.3H3.5z', f: '#fff' },
      { d: 'M15.4 9.2a4 4 0 0 1 0 5.6M18 6.6a7.6 7.6 0 0 1 0 10.8', l: '#4dabf7', w: 2 },
    ],
    soundOff: [
      { d: 'M3.5 9.3h3.8l5-4.3v14l-5-4.3H3.5z', f: '#fff' },
      { d: 'M15.5 9.5l5 5M20.5 9.5l-5 5', l: '#fa5252', w: 2.2 },
    ],
    jersey: [
      { d: 'M8.6 3.4L3.6 6l-1.4 4.8 3.6 1.4v8.3h12.4v-8.3l3.6-1.4L20.4 6l-5-2.6c-.6 1.6-1.8 2.4-3.4 2.4S9.2 5 8.6 3.4z', f: '#ffa94d' },
      { d: 'M5.8 12.2h12.4', l: '#fff', w: 1.8 },
    ],
    bolt: [{ d: 'M13.8 2.2L5.2 13.6h5.6l-1.6 8.2 8.8-11.6h-5.6z', f: '#ffd43b' }],
    fin: [{ d: 'M3 17.6c4.4-.8 7.6-6 8.8-13.4 3.2 4 6.2 9.4 9.2 13.4z', f: '#dee2e6' }, { d: 'M3 20.6c2.6-1.6 5-1.6 7.2 0s4.6 1.6 7.2 0c1.2-.8 2.4-1.2 3.6-1.2', l: '#74c0fc', w: 1.8 }],
    paw: [
      { d: 'M7.4 16.4c0-3 2.2-5 4.6-5s4.6 2 4.6 5c0 2.2-1.6 3.6-4.6 3.6s-4.6-1.4-4.6-3.6z', f: '#fff3bf' },
      { d: C(5.4, 10.8, 2), f: '#fff3bf' },
      { d: C(9.2, 6.6, 2.1), f: '#fff3bf' },
      { d: C(14.8, 6.6, 2.1), f: '#fff3bf' },
      { d: C(18.6, 10.8, 2), f: '#fff3bf' },
    ],
    sparkle: [
      { d: 'M10 2.5c.9 4.6 2.4 6.1 7 7-4.6.9-6.1 2.4-7 7-.9-4.6-2.4-6.1-7-7 4.6-.9 6.1-2.4 7-7z', f: '#ffe066' },
      { d: 'M18 13.5c.4 2.1 1.1 2.8 3.2 3.2-2.1.4-2.8 1.1-3.2 3.2-.4-2.1-1.1-2.8-3.2-3.2 2.1-.4 2.8-1.1 3.2-3.2z', f: '#fff3bf' },
    ],
    chart: [
      { d: R(3.5, 13, 4.2, 7.5, 1), f: '#74c0fc' },
      { d: R(9.9, 9, 4.2, 11.5, 1), f: '#4dabf7' },
      { d: R(16.3, 4.5, 4.2, 16, 1), f: '#339af0' },
    ],
    cap: [
      { d: 'M12.5 14.2h8c.9 0 1.6.6 1.6 1.4s-.7 1.4-1.6 1.4H12.5z', f: '#0ca678' },
      { d: 'M3.5 15.4a8.4 8.4 0 0 1 16.8-1.2H12.5v1.2z', f: '#20c997' },
      { d: C(11.9, 6.2, 1.3), f: '#0ca678' },
    ],
    bell: [
      { d: C(12, 5.2, 1.5), f: '#fab005' },
      { d: 'M4.6 17a7.4 7.4 0 0 1 14.8 0z', f: '#ffd43b' },
      { d: R(3, 17, 18, 3.2, 1.2), f: '#adb5bd' },
    ],
    hand: [
      { d: 'M7.6 21c-2-1.6-3.6-4-3.6-6.2l-.2-3.3c0-1 1.4-1.3 1.8-.4L7 13.6V5.4c0-1.1 1.8-1.1 1.8 0v5.3V3.8c0-1.1 1.9-1.1 1.9 0v6.9V4.6c0-1.1 1.9-1.1 1.9 0v6.3V6.6c0-1.1 1.8-1.1 1.8 0v8c0 3-1.2 5-3 6.4z', f: '#ffd6b0' },
    ],
    swipe: [
      { d: 'M12 3.5v10.5', l: '#4dabf7', w: 2.4 },
      { d: 'M7.4 10.6L12 15.2l4.6-4.6', l: '#4dabf7', w: 2.4 },
      { d: R(6, 17.2, 12, 3.4, 1.7), f: '#fff' },
    ],
    target: [{ d: C(12, 12, 9), f: '#ff6b6b' }, { d: C(12, 12, 5.6), f: '#fff' }, { d: C(12, 12, 2.4), f: '#ff6b6b' }],
    baton: [
      { d: R(3, 9.5, 18, 5, 2.5), f: '#fab005' },
      { d: R(3, 9.5, 3.6, 5, 1.6), f: '#fa5252' },
      { d: R(17.4, 9.5, 3.6, 5, 1.6), f: '#fa5252' },
    ],
    // scouting, team, daily
    scout: [ // binoculars
      { d: R(3, 9, 7.6, 11, 3.2), f: '#4dabf7' },
      { d: R(13.4, 9, 7.6, 11, 3.2), f: '#4dabf7' },
      { d: R(9.6, 10.5, 4.8, 4.5, 1.2), f: '#1864ab' },
      { d: R(4.2, 4.4, 5.2, 5.6, 1.4), f: '#1864ab' },
      { d: R(14.6, 4.4, 5.2, 5.6, 1.4), f: '#1864ab' },
      { d: C(6.8, 16.2, 2.1), f: '#e7f5ff' },
      { d: C(17.2, 16.2, 2.1), f: '#e7f5ff' },
    ],
    team: [
      { d: C(16.2, 7.6, 3.2), f: '#ffc078' },
      { d: 'M10.4 20.5c.3-4.4 2.6-7 5.8-7s5.5 2.6 5.8 7z', f: '#4dabf7' },
      { d: C(8.4, 8, 3.6), f: '#ffd8a8' },
      { d: 'M2 20.8c.3-4.8 2.9-7.6 6.4-7.6s6.1 2.8 6.4 7.6z', f: '#ff922b' },
    ],
    calendar: [
      { d: R(3, 4.5, 18, 16.5, 2.6), f: '#fff' },
      { d: 'M3.4 7.4c0-1.6 1.1-2.6 2.6-2.6h12c1.5 0 2.6 1 2.6 2.6v2.4H3.4z', f: '#fa5252' },
      { d: 'M8 2.8v3.6M16 2.8v3.6', k: 1, w: 2.2 },
      { d: 'M7.5 15l3 3 6-6', l: '#40c057', w: 2.4 },
    ],
    chest: [
      { d: 'M3 11.5h18v8.2a1.6 1.6 0 0 1-1.6 1.6H4.6A1.6 1.6 0 0 1 3 19.7z', f: '#c0712c' },
      { d: 'M3 11.5V9.2c0-3 2.2-5 5-5h8c2.8 0 5 2 5 5v2.3z', f: '#e8913f' },
      { d: 'M3.2 11.5h17.6M8.4 4.4v16.8M15.6 4.4v16.8', k: 1, w: 1.4 },
      { d: R(9.8, 9.6, 4.4, 5, 1.2), f: '#ffd43b' },
    ],
    music: [
      { d: 'M9 17.5V5.2l11-2.4v12.4', k: 1, w: 2.2 },
      { d: C(6.6, 17.6, 2.9), f: '#cc5de8' },
      { d: C(17.6, 15.3, 2.9), f: '#cc5de8' },
      { d: 'M9 8.4l11-2.4', k: 1, w: 2.2 },
    ],
    musicOff: [
      { d: 'M9 17.5V5.2l11-2.4v12.4', k: 1, w: 2.2 },
      { d: C(6.6, 17.6, 2.9), f: '#adb5bd' },
      { d: C(17.6, 15.3, 2.9), f: '#adb5bd' },
      { d: 'M3.5 3.5l17 17', l: '#fa5252', w: 2.4 },
    ],
    pin: [
      { d: 'M12 21.5s-6.8-6.6-6.8-11.6a6.8 6.8 0 0 1 13.6 0c0 5-6.8 11.6-6.8 11.6z', f: '#ff6b6b' },
      { d: C(12, 9.9, 2.6), f: '#fff' },
    ],
    map: [
      { d: 'M2.8 5.8l6-2.3 6.4 2.3 6-2.3v14.7l-6 2.3-6.4-2.3-6 2.3z', f: '#c3fae8' },
      { d: 'M8.8 3.6v14.6M15.2 5.8v14.6', k: 1, w: 1.6 },
      { d: 'M4.6 13c2-1.6 3.4.4 5.6-1.2s3.8-.6 5.4-2.2 3-.2 3.8-1', l: '#fa5252', w: 1.6 },
    ],
    flag: [
      { d: 'M5 2.5v19', k: 1, w: 2.2 },
      { d: 'M5.6 3.6h14.2v10H5.6z', f: '#fff' },
      { d: 'M5.6 3.6h4.8v10H5.6z', f: '#4dabf7' },
      { d: 'M15 3.6h4.8v10H15z', f: '#fa5252' },
    ],
    ticket: [
      { d: 'M2.8 7.2h18.4v3a2 2 0 0 0 0 3.6v3H2.8v-3a2 2 0 0 0 0-3.6z', f: '#ffd43b' },
      { d: 'M15.4 7.6v9', k: 1, w: 1.4 },
      { d: starPath(9, 12, 2.8, 1.25), f: '#fff' },
    ],
    heart: [{ d: 'M12 20.5S3 14.8 3 8.9A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 9 1.9c0 5.9-9 11.6-9 11.6z', f: '#ff6b6b' }, { d: 'M6.6 8.4a2.2 2.2 0 0 1 2-1.8', l: '#fff', w: 1.2 }],
    battery: [
      { d: R(2.5, 7, 17, 10, 2.4), f: '#fff' },
      { d: R(19.5, 10, 2.4, 4, 1), f: INK },
      { d: R(4.6, 9.1, 9, 5.8, 1.2), f: '#51cf66' },
      { d: 'M12.6 8.2l-2.6 4h3l-2.4 3.8', l: '#ffd43b', w: 1.4 },
    ],
    bed: [
      { d: R(2.5, 11, 19, 5.5, 1.6), f: '#4dabf7' },
      { d: R(3.8, 8.4, 6, 3.4, 1.6), f: '#fff' },
      { d: R(9.6, 9.4, 11, 2.6, 1.2), f: '#a5d8ff' },
      { d: 'M3.2 16.5v3.4M20.8 16.5v3.4M3.2 4.5v12', k: 1, w: 2.2 },
    ],
    spa: [
      { d: 'M3 13h18v2.6c0 3.2-2.6 5.4-5.8 5.4H8.8C5.6 21 3 18.8 3 15.6z', f: '#66d9e8' },
      { d: 'M3 13h18', k: 1, w: 2 },
      { d: 'M8 10.6c-1.4-1.6 1.4-2.6 0-4.6M12 10.6c-1.4-1.6 1.4-2.6 0-4.6M16 10.6c-1.4-1.6 1.4-2.6 0-4.6', l: '#e7f5ff', w: 1.6 },
    ],
    // league ladder + rewards
    diamond: [
      { d: 'M6.6 4h10.8l4.4 5.4L12 21 2.2 9.4z', f: '#99e9f2' },
      { d: 'M2.6 9.4h18.8M8.6 9.4L12 20.4l3.4-11M6.8 4.2l1.8 5.2 3.4-5.2 3.4 5.2 1.8-5.2', k: 1, w: 1.4 },
      { d: 'M5.2 8.6l2-3.3', l: '#fff', w: 1 },
    ],
    globe: [
      { d: C(12, 12, 9.2), f: '#4dabf7' },
      { d: 'M6.2 6.8c2 .4 2.6 1.8 2 3.4-.5 1.4.8 2.2 2 2.6 1.4.5 1 2.4-.2 3.4M14.8 3.4c-.6 1.6.2 2.6 1.8 2.8 1.4.2 2.6 1.2 2.2 3M15.4 20.4c-.4-1.8.4-3 1.8-3.4', l: '#69db7c', w: 2.2 },
    ],
    euro: [
      { d: C(12, 12, 9.4), f: '#3b5bdb' },
      ...Array.from({ length: 8 }, (_, i) => {
        const a = (i / 8) * Math.PI * 2;
        return { d: starPath(12 + Math.cos(a) * 5.8, 12 + Math.sin(a) * 5.8, 2.1, 0.95), f: '#ffd43b' };
      }),
    ],
    banner: [
      { d: 'M5 2.5v19', k: 1, w: 2.2 },
      { d: 'M5.6 3.5h13.4l-3.2 5 3.2 5H5.6z', f: '#ff6b6b' },
      { d: starPath(11.6, 8.5, 2.8, 1.25), f: '#fff' },
    ],
    statue: [
      { d: C(12, 5.4, 2.8), f: '#ffd43b' },
      { d: 'M8.2 15.5l.8-6.2c.2-1 1-1.6 2-1.6h2c1 0 1.8.6 2 1.6l.8 6.2z', f: '#ffd43b' },
      { d: 'M9 9.6L5.8 5.2M15 9.6l3.2-4.4', l: '#ffd43b', w: 2 },
      { d: R(5.5, 15.5, 13, 5.5, 1.2), f: '#adb5bd' },
    ],
    trophyCase: [
      { d: R(3.5, 2.8, 17, 18.4, 2), f: '#e7f5ff' },
      { d: 'M3.8 12h16.4', k: 1, w: 1.6 },
      { d: 'M8.2 5.2h3.6v2a1.8 1.8 0 0 1-3.6 0zM12.6 14.2h3.6v2a1.8 1.8 0 0 1-3.6 0z', f: '#ffd43b' },
      { d: 'M10 8.8v1.6M14.4 17.8v1.6', k: 1, w: 1.4 },
      { d: 'M15.5 5l1.6-1.6', l: '#fff', w: 1 },
    ],
    swords: [
      { d: 'M4.5 4.5l10 10M19.5 4.5l-10 10', l: '#dee2e6', w: 2.6 },
      { d: 'M12.4 16.4l3.2-3.2M11.6 16.4L8.4 13.2', k: 1, w: 2.4 },
      { d: 'M15.8 17.6l2.6 2.6M8.2 17.6l-2.6 2.6', l: '#e8590c', w: 2.6 },
    ],
    // v7: basketball, station gear, entrances, coaches
    basketball: [
      { d: C(12, 12, 9.2), f: '#ff922b' },
      { d: 'M2.8 12h18.4M12 2.8v18.4M5.6 5.3c3 3.6 3 9.8 0 13.4M18.4 5.3c-3 3.6-3 9.8 0 13.4', k: 1, w: 1.5 },
    ],
    hoop: [
      { d: R(4, 2.5, 16, 10, 2), f: '#fff' },
      { d: R(9, 6, 6, 4.5, 1), f: '#fff' },
      { d: 'M6 13.5h12', l: '#fa5252', w: 2.4 },
      { d: 'M7 14l1.6 6.5M17 14l-1.6 6.5M10.5 14l.5 6.5M13.5 14l-.5 6.5M8.6 20.5h6.8', k: 1, w: 1.2 },
    ],
    towel: [
      { d: R(3.5, 4, 17, 16, 2.5), f: '#fff' },
      { d: 'M3.5 15h17', l: '#4dabf7', w: 2.6 },
      { d: 'M3.5 8.5h17', k: 1, w: 1.2 },
    ],
    wraps: [
      { d: R(3, 7, 9, 10, 4.5), f: '#f8f9fa' },
      { d: R(12, 7, 9, 10, 4.5), f: '#f8f9fa' },
      { d: 'M5 10.5h5M5 13.5h5M14 10.5h5M14 13.5h5', l: '#fa5252', w: 1.4 },
    ],
    cone: [
      { d: poly([[12, 2.5], [18.5, 19], [5.5, 19]]), f: '#ff922b' },
      { d: 'M8.3 12h7.4', l: '#fff', w: 2.4 },
      { d: R(3, 18.5, 18, 3, 1.4), f: '#ff922b' },
    ],
    plate: [
      { d: C(12, 12, 9.2), f: '#495057' },
      { d: C(12, 12, 5), f: '#868e96' },
      { d: C(12, 12, 1.8), f: '#dee2e6' },
    ],
    swimcap: [
      { d: 'M3.5 16c0-6.2 3.8-10.5 8.5-10.5s8.5 4.3 8.5 10.5z', f: '#e64980' },
      { d: 'M12 6v4', k: 1, w: 1.4 },
      { d: R(3, 15.5, 18, 3.2, 1.5), f: '#f783ac' },
    ],
    mitt: [
      { d: 'M5 10.5c0-4 3.2-6.5 7-6.5s7 2.5 7 6.5v3.5c0 3.5-3 6-7 6s-7-2.5-7-6z', f: '#212529' },
      { d: C(12, 11, 3.4), f: '#fa5252' },
    ],
    gate: [
      { d: 'M3 21V9.5C3 5.4 7 3 12 3s9 2.4 9 6.5V21h-4.5v-9a4.5 4.5 0 0 0-9 0v9z', f: '#ffd43b' },
      { d: 'M3 21h18', k: 1, w: 1.6 },
    ],
    whistle: [
      { d: 'M3.5 12.5a5.5 5.5 0 1 0 11 0V10h6V6.5h-11a6 6 0 0 0-6 6z', f: '#ced4da' },
      { d: C(9, 12.5, 1.8), f: INK },
    ],
  };
  // the same icon, recoloured (e.g. a greyed-out star)
  const tinted = (parts, tint) => (tint ? parts.map((p) => (p.f && p.f !== INK ? Object.assign({}, p, { f: tint }) : p)) : parts);

  // ---------- SVG (DOM) ----------
  const svgCache = {};
  function svg(name, cls = '', tint) {
    const key = name + '|' + cls + '|' + (tint || '');
    if (svgCache[key]) return svgCache[key];
    const parts = tinted(ICONS[name] || ICONS.star, tint);
    let body = '';
    for (const p of parts) {
      if (p.f) body += `<path d="${p.d}" fill="${p.f}" stroke="${INK}" stroke-width="${OUT}"/>`;
      else if (p.l) body += `<path d="${p.d}" fill="none" stroke="${INK}" stroke-width="${p.w + OUT * 1.3}"/><path d="${p.d}" fill="none" stroke="${p.l}" stroke-width="${p.w}"/>`;
      else body += `<path d="${p.d}" fill="none" stroke="${INK}" stroke-width="${p.w}"/>`;
    }
    return (svgCache[key] = `<svg class="i ${cls}" viewBox="-1 -1 26 26" aria-hidden="true" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`);
  }
  // a row of stars: n gold, the rest grey
  const stars = (n, max = 5, cls = '') => Array.from({ length: max }, (_, i) => svg('star', cls, i < n ? null : '#dee2e6')).join('');

  // ---------- canvas ----------
  const pathCache = {};
  const P2 = (d) => pathCache[d] || (pathCache[d] = new Path2D(d));
  function draw(g, name, x, y, size, tint) {
    const parts = tinted(ICONS[name] || ICONS.star, tint);
    g.save();
    g.translate(x - size / 2, y - size / 2);
    const s = size / 26; g.scale(s, s); g.translate(1, 1);
    g.lineCap = 'round'; g.lineJoin = 'round';
    for (const p of parts) {
      const path = P2(p.d);
      if (p.f) { g.fillStyle = p.f; g.fill(path); g.strokeStyle = INK; g.lineWidth = OUT; g.stroke(path); }
      else if (p.l) { g.strokeStyle = INK; g.lineWidth = p.w + OUT * 1.3; g.stroke(path); g.strokeStyle = p.l; g.lineWidth = p.w; g.stroke(path); }
      else { g.strokeStyle = INK; g.lineWidth = p.w; g.stroke(path); }
    }
    g.restore();
  }
  // fill every <i data-i="name"> placeholder in static HTML
  function mount(root = document) {
    root.querySelectorAll('[data-i]').forEach((el) => { el.innerHTML = svg(el.dataset.i); });
  }

  AT.Icon = { ICONS, svg, stars, draw, mount, INK };
})();
